<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Check if user ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid user ID";
    header("Location: admin-dashboard.php");
    exit();
}

$user_id = $_GET['id'];

// Don't allow admin to delete themselves
if ($user_id == $_SESSION['user_id']) {
    $_SESSION['error_message'] = "You cannot delete your own account";
    header("Location: admin-dashboard.php");
    exit();
}

// Get user data first to handle profile image deletion
$stmt = $conn->prepare("SELECT profile_image FROM Users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error_message'] = "User not found";
    header("Location: admin-dashboard.php");
    exit();
}

$user_data = $result->fetch_assoc();

// Delete the user
$stmt = $conn->prepare("DELETE FROM Users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    // Delete profile image if exists
    if (!empty($user_data['profile_image']) && file_exists($user_data['profile_image'])) {
        unlink($user_data['profile_image']);
    }
    
    $_SESSION['success_message'] = "User deleted successfully";
} else {
    $_SESSION['error_message'] = "Error deleting user: " . $conn->error;
}

header("Location: admin-dashboard.php");
exit();
?>