<?php
// This file is intended to be run as a scheduled task (cron job) to send
// automated deadline reminder emails without requiring manual intervention

// Include the necessary files
require_once 'db_connection.php';
require_once 'email_system.php';

// Create email notification system instance
$emailSystem = new EmailNotificationSystem($conn);

// Initialize counters
$assignment_reminders_sent = 0;
$quiz_reminders_sent = 0;
$errors = [];

// Send assignment deadline reminders
try {
    $assignment_reminders_sent = $emailSystem->sendDeadlineReminders();
} catch (Exception $e) {
    $errors[] = "Error sending assignment reminders: " . $e->getMessage();
}

// Send quiz reminders
try {
    $quiz_reminders_sent = $emailSystem->sendQuizReminders();
} catch (Exception $e) {
    $errors[] = "Error sending quiz reminders: " . $e->getMessage();
}

// Calculate total
$total_sent = $assignment_reminders_sent + $quiz_reminders_sent;

// Log this run to the system
$log_dir = __DIR__ . '/logs/system/';
if (!is_dir($log_dir)) {
    mkdir($log_dir, 0755, true);
}

$log_file = $log_dir . date('Y-m-d') . '_cron_deadline_check.txt';
$log_content = date('Y-m-d H:i:s') . " | CRON | Assignment Reminders: {$assignment_reminders_sent} | " .
               "Quiz Reminders: {$quiz_reminders_sent} | Total: {$total_sent}\n";

if (!empty($errors)) {
    $log_content .= "Errors: " . implode(", ", $errors) . "\n";
}

file_put_contents($log_file, $log_content, FILE_APPEND);

// Output result for cron logs
echo "Deadline reminder cron completed.\n";
echo "Assignment Reminders: {$assignment_reminders_sent}\n";
echo "Quiz Reminders: {$quiz_reminders_sent}\n";
echo "Total: {$total_sent}\n";

if (!empty($errors)) {
    echo "Errors: " . implode(", ", $errors) . "\n";
}
?>