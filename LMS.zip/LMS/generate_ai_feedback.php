<?php
/**
 * Generates AI feedback for students using Hugging Face API
 */

$HUGGINGFACE_TOKEN = "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"; // Your token
$MODEL_ID = "tiiuae/falcon-7b-instruct"; 
$CACHE_ENABLED = true;
$CACHE_EXPIRY = 86400; // Cache lifetime in seconds (24 hours)

// Cache directory
define('CACHE_DIR', __DIR__ . '/cache');

/**
 * Generate feedback for a student's overall performance
 * 
 * @param array $data Student performance data
 * @return array Response with feedback text
 */
function generateOverallFeedback($data) {
    global $HUGGINGFACE_TOKEN, $MODEL_ID, $CACHE_ENABLED, $CACHE_EXPIRY;
    
    // Create a unique cache key based on student data
    $cache_key = md5(json_encode($data) . $MODEL_ID);
    
    // Check cache if enabled
    if ($CACHE_ENABLED) {
        $cached_response = getCachedResponse($cache_key);
        if ($cached_response !== false) {
            // Clean the cached response before returning
            $cleaned_response = cleanFeedbackText($cached_response);
            
            return [
                'feedback' => $cleaned_response, 
                'cached' => true,
                'topics_covered' => implode(", ", array_unique(array_merge($data['strong_areas'], $data['weak_areas']))),
                'resources_recommended' => generateResourcesRecommendation($data)
            ];
        }
    }
    
    // Prepare the prompt for the API
    $prompt = constructFeedbackPrompt($data);
    
    // Call Hugging Face API and clean the response
    $response = callHuggingFaceAPI($prompt, $MODEL_ID, $HUGGINGFACE_TOKEN);
    
    // Clean the response to remove unwanted text patterns
    $cleaned_response = cleanFeedbackText($response);
    
    // Cache the cleaned response if enabled
    if ($CACHE_ENABLED && !empty($cleaned_response)) {
        cacheResponse($cache_key, $cleaned_response, $CACHE_EXPIRY);
    }
    
    return [
        'feedback' => $cleaned_response, 
        'cached' => false,
        'topics_covered' => implode(", ", array_unique(array_merge($data['strong_areas'], $data['weak_areas']))),
        'resources_recommended' => generateResourcesRecommendation($data)
    ];
}

/**
 * Cleans feedback text to remove unwanted patterns and ensure optimistic tone
 * 
 * @param string $text The feedback text to clean
 * @return string Cleaned feedback text
 */
function cleanFeedbackText($text) {
    // Remove any system instructions
    $text = preg_replace('/^You are an educational assistant.*?positive closing\.?\s*/s', '', $text);
    
    // Remove data labels from the prompt
    $text = preg_replace('/^Student:.*?\n/m', '', $text);
    $text = preg_replace('/^Course:.*?\n/m', '', $text);
    $text = preg_replace('/^Overall Score:.*?\n/m', '', $text);
    $text = preg_replace('/^Score:.*?\n/m', '', $text);
    $text = preg_replace('/^Grade:.*?\n/m', '', $text);
    $text = preg_replace('/^Strong Areas:.*?\n/m', '', $text);
    $text = preg_replace('/^Strengths:.*?\n/m', '', $text);
    $text = preg_replace('/^Areas for Improvement:.*?\n/m', '', $text);
    $text = preg_replace('/^Weaknesses:.*?\n/m', '', $text);
    $text = preg_replace('/^\d+\.\s.*?\n/m', '', $text);
    
    // Remove explicit section headings
    $text = preg_replace('/\bEncouragement:[ \t]*/i', '', $text);
    $text = preg_replace('/\bConstructive Feedback:[ \t]*/i', '', $text);
    $text = preg_replace('/\bFeedback:[ \t]*/i', '', $text);
    
    // Fix formatting issues with line breaks
    $text = preg_replace('/\.\s*\n/m', '. ', $text);
    $text = preg_replace('/\n{3,}/', "\n\n", $text);
    
    return trim($text);
}

/**
 * Constructs the prompt for the AI based on student data
 * 
 * @param array $data Student performance data
 * @return string Formatted prompt
 */
function constructFeedbackPrompt($data) {
    $student_name = $data['student_name'];
    $score = $data['score'];
    $grade = $data['grade'];
    $course_title = isset($data['course_title']) ? $data['course_title'] : "Overall Courses";
    
    // Format strong areas as comma-separated list
    $strong_areas = !empty($data['strong_areas']) 
        ? implode(", ", array_unique($data['strong_areas'])) 
        : "None identified yet";
    
    // Format weak areas as comma-separated list
    $weak_areas = !empty($data['weak_areas']) 
        ? implode(", ", array_unique($data['weak_areas'])) 
        : "None identified yet";
    
    $prompt = <<<EOT
You are an educational assistant providing feedback to a student. Give encouraging, constructive feedback in 3-4 paragraphs.

Student: $student_name
Course: $course_title

Grade: $grade
Strong Areas: $strong_areas
Areas for Improvement: $weak_areas

Provide personalized academic feedback with:
1. A positive opening that acknowledges strengths
2. Specific advice for improvement areas
3. Encouragement and a positive closing

Important: Make your feedback optimistic and supportive. Don't use explicit headings like "Encouragement:" or "Constructive Feedback:" in your response.
EOT;

    return $prompt;
}

/**
 * Generates a recommendation of resources based on student data
 * 
 * @param array $data Student performance data
 * @return string Comma-separated resources recommendations
 */
function generateResourcesRecommendation($data) {
    $weak_areas = $data['weak_areas'];
    $resources = [];
    
    // If no weak areas, provide general resources
    if (empty($weak_areas)) {
        return "General course materials, Online tutorials, Practice exercises";
    }
    
    // Generate resource recommendations based on weak areas
    foreach ($weak_areas as $area) {
        switch (strtolower(trim($area))) {
            case 'mathematics':
            case 'math':
            case 'algebra':
            case 'calculus':
                $resources[] = "Khan Academy Math Videos";
                $resources[] = "Mathematics Practice Worksheets";
                break;
                
            case 'programming':
            case 'coding':
            case 'computer science':
                $resources[] = "Codecademy Tutorials";
                $resources[] = "Programming Practice Exercises";
                $resources[] = "Code Review Sessions";
                break;
                
            case 'writing':
            case 'essays':
            case 'grammar':
                $resources[] = "Writing Center Appointments";
                $resources[] = "Grammar Review Modules";
                $resources[] = "Essay Structure Guides";
                break;
                
            case 'science':
            case 'biology':
            case 'chemistry':
            case 'physics':
                $resources[] = "Science Concept Videos";
                $resources[] = "Lab Practice Sessions";
                $resources[] = "Study Group for Science";
                break;
                
            case 'webdevelopment':
            case 'webdevelopment1':
            case 'webdevelopment2':
            case 'webdevelopment3':
            case 'webdevelopment4':
                $resources[] = "Web Development Tutorial Videos";
                $resources[] = "Coding Practice Exercises";
                $resources[] = "Front-end Framework Documentation";
                $resources[] = "Web Development Project Examples";
                break;
                
            default:
                $resources[] = "Additional Practice Materials for " . ucfirst($area);
                $resources[] = "Tutoring Sessions";
                $resources[] = "Supplementary Reading Materials";
        }
    }
    
    // Ensure we don't have duplicates and return as comma-separated list
    return implode(", ", array_unique($resources));
}

/**
 * Makes the API call to Hugging Face
 * 
 * @param string $prompt The text prompt to send
 * @param string $model_id The model ID to use
 * @param string $token API token
 * @return string The generated text
 */
function callHuggingFaceAPI($prompt, $model_id, $token) {
    $api_url = "https://api-inference.huggingface.co/models/" . $model_id;
    
    $data = [
        'inputs' => $prompt,
        'parameters' => [
            'max_new_tokens' => 250,
            'temperature' => 0.7,
            'top_p' => 0.9,
            'do_sample' => true
        ]
    ];
    
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => [
                'Authorization: Bearer ' . $token,
                'Content-Type: application/json'
            ],
            'content' => json_encode($data),
            'timeout' => 30
        ]
    ];
    
    $context = stream_context_create($options);
    
    try {
        $response = file_get_contents($api_url, false, $context);
        
        if ($response === false) {
            error_log("Error calling Hugging Face API");
            return "I'm sorry, I couldn't generate feedback at this time. Please try again later.";
        }
        
        $result = json_decode($response, true);
        
        // Extract the generated text
        if (isset($result[0]['generated_text'])) {
            // Remove the prompt from the response to get only the generated text
            $generated_text = str_replace($prompt, '', $result[0]['generated_text']);
            return trim($generated_text);
        } else {
            error_log("Unexpected response format from Hugging Face API: " . $response);
            return "I'm sorry, I couldn't generate feedback at this time. Please try again later.";
        }
    } catch (Exception $e) {
        error_log("Exception when calling Hugging Face API: " . $e->getMessage());
        return "I'm sorry, I couldn't generate feedback at this time. Please try again later.";
    }
}

/**
 * Get a cached response if available and not expired
 * 
 * @param string $key Cache key
 * @return string|false Cached content or false if not found/expired
 */
function getCachedResponse($key) {
    $cache_file = CACHE_DIR . '/' . $key . '.cache';
    
    // Make sure cache directory exists
    if (!is_dir(CACHE_DIR)) {
        mkdir(CACHE_DIR, 0755, true);
    }
    
    if (file_exists($cache_file)) {
        $cache_data = unserialize(file_get_contents($cache_file));
        
        if ($cache_data['expires'] > time()) {
            return $cache_data['content'];
        }
    }
    
    return false;
}

/**
 * Cache a response
 * 
 * @param string $key Cache key
 * @param string $content Content to cache
 * @param int $expiry Expiry time in seconds
 * @return bool Success
 */
function cacheResponse($key, $content, $expiry) {
    $cache_file = CACHE_DIR . '/' . $key . '.cache';
    
    // Make sure cache directory exists
    if (!is_dir(CACHE_DIR)) {
        mkdir(CACHE_DIR, 0755, true);
    }
    
    $cache_data = [
        'content' => $content,
        'expires' => time() + $expiry
    ];
    
    return file_put_contents($cache_file, serialize($cache_data)) !== false;
}

/**
 * Generate feedback for a specific quiz result
 * 
 * @param array $data Quiz result data
 * @return array Response with feedback text
 */
function generateQuizFeedback($data) {
    // Similar to generateOverallFeedback but specifically for quizzes
    return generateOverallFeedback($data); // For simplicity, using the same function
}

/**
 * Generate feedback for a specific assignment submission
 * 
 * @param array $data Assignment submission data
 * @return array Response with feedback text
 */
function generateAssignmentFeedback($data) {
    // Similar to generateOverallFeedback but specifically for assignments
    return generateOverallFeedback($data); // For simplicity, using the same function
}

// Add a function to clear cache if needed
function clearFeedbackCache($student_id = null) {
    if (!is_dir(CACHE_DIR)) {
        mkdir(CACHE_DIR, 0755, true);
        return true;
    }
    
    if ($student_id !== null) {
        // If we have a student ID, we need to find cache files related to this student
        // Since we don't store the student ID in the cache filename directly,
        // we'll need to check all cache files
        
        // For now, clear all cache to be safe
        $files = glob(CACHE_DIR . '/*.cache');
        foreach ($files as $file) {
            unlink($file);
        }
    } else {
        // Clear all cache files
        $files = glob(CACHE_DIR . '/*.cache');
        foreach ($files as $file) {
            unlink($file);
        }
    }
    
    // Log cache clearing for debugging
    error_log("Cleared feedback cache" . ($student_id ? " for student $student_id" : ""));
    
    return true;
}
?>