<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';
require_once 'email_utils.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {
    header("Location: login.php");
    exit();
}

// Get instructor data
$instructor_id = $_SESSION['user_id'];
$instructor_name = $_SESSION['name'];

$success_message = '';
$error_message = '';

if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// Check if assignment_id is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid assignment ID";
    header("Location: instructor-dashboard.php");
    exit();
}

$assignment_id = $_GET['id'];

// Process form submission for grading assignments
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['grade_assignment'])) {
    $submission_id = $_POST['submission_id'];
    $grade = floatval($_POST['grade']);
    $feedback = trim($_POST['feedback']);
    
    // Ensure grade is between 0-100
    $grade = max(0, min(100, $grade));
    
    // Update the submission with the grade and feedback
    $stmt = $conn->prepare("
        UPDATE Submissions
        SET grade = ?, ai_feedback = ?
        WHERE submission_id = ?
    ");
    $stmt->bind_param("dsi", $grade, $feedback, $submission_id);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        $success_message = "Assignment has been graded successfully.";
        
        // Get the student ID and assignment information for the email
        $get_assignment_info = $conn->prepare("
            SELECT s.student_id, a.title, a.course_id 
            FROM Submissions s
            JOIN Assignments a ON s.assignment_id = a.assignment_id
            WHERE s.submission_id = ?
        ");
        $get_assignment_info->bind_param("i", $submission_id);
        $get_assignment_info->execute();
        $assignment_info_result = $get_assignment_info->get_result();
        
        if ($assignment_info_result->num_rows > 0) {
            $assignment_info = $assignment_info_result->fetch_assoc();
            
            // Send email notification
            try {
                EmailUtils::sendFeedbackNotification(
                    $assignment_info['student_id'],
                    $assignment_info['course_id'],
                    $assignment_info['title'],
                    'assignment'
                );
                
                // Add to the success message
                $success_message .= " An email notification has been sent to the student.";
                
                // Mark feedback for regeneration
                require_once 'feedback_utils.php';
                markFeedbackForRegeneration($assignment_info['student_id']);
            } catch (Exception $e) {
                error_log("Failed to send feedback notification email: " . $e->getMessage());
            }
        }
    } else {
        $error_message = "Error saving grade: " . $stmt->error;
    }
    
    // Store messages in session for display after redirect
    if (!empty($success_message)) {
        $_SESSION['success_message'] = $success_message;
    }
    if (!empty($error_message)) {
        $_SESSION['error_message'] = $error_message;
    }
    
    // Check if we need to regenerate feedback
    if (isset($_SESSION['regenerate_feedback']) && $_SESSION['regenerate_feedback']) {
        // Redirect to feedback.php with regenerate=1 parameter
        $student_id = $_SESSION['feedback_student_id'];
        
        // Clear the regeneration flags
        unset($_SESSION['regenerate_feedback']);
        unset($_SESSION['feedback_student_id']);
        
        // Redirect to feedback.php to regenerate the feedback
        header("Location: feedback.php?regenerate=1&student_id=$student_id");
        exit();
    } else {
        // Normal redirect back to the grading page
        header("Location: grade_assignment.php?id=$assignment_id&submission_id=$submission_id");
        exit();
    }
}

// Get assignment information
$stmt = $conn->prepare("
    SELECT a.assignment_id, a.title, a.description, a.due_date, a.topic, a.grading_criteria,
           c.title as course_title, c.course_id
    FROM Assignments a
    JOIN Courses c ON a.course_id = c.course_id
    WHERE a.assignment_id = ?
");
$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$assignment_result = $stmt->get_result();

if ($assignment_result->num_rows === 0) {
    $_SESSION['error_message'] = "Assignment not found";
    header("Location: instructor-dashboard.php");
    exit();
}

$assignment = $assignment_result->fetch_assoc();

// Initialize search variables
$selected_student = isset($_GET['student_id']) ? $_GET['student_id'] : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Base query for student submissions
$query = "
    SELECT s.submission_id, u.user_id, u.name as student_name, s.date_submitted, 
           s.submission_url, s.grade, s.ai_feedback as feedback, s.date_submitted as graded_at
    FROM Submissions s
    JOIN Users u ON s.student_id = u.user_id
    WHERE s.assignment_id = ?
";

// Add search filters if they are set
$params = [$assignment_id];
$types = "i";

if (!empty($selected_student)) {
    $query .= " AND u.user_id = ?";
    $params[] = $selected_student;
    $types .= "i";
}

if (!empty($date_from)) {
    $query .= " AND s.date_submitted >= ?";
    $params[] = $date_from . " 00:00:00";
    $types .= "s";
}

if (!empty($date_to)) {
    $query .= " AND s.date_submitted <= ?";
    $params[] = $date_to . " 23:59:59";
    $types .= "s";
}

$query .= " ORDER BY s.date_submitted DESC";

// Get student submissions for this assignment with filters
$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$student_submissions = $stmt->get_result();
$submission_count = $student_submissions->num_rows;

// Get all students who have made submissions for the dropdown
$stmt = $conn->prepare("
    SELECT DISTINCT u.user_id, u.name as student_name
    FROM Submissions s
    JOIN Users u ON s.student_id = u.user_id
    WHERE s.assignment_id = ?
    ORDER BY u.name ASC
");
$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$student_list = $stmt->get_result();

// Get specific submission if submission_id is provided
$submission_data = null;
if (isset($_GET['submission_id']) && is_numeric($_GET['submission_id'])) {
    $submission_id = $_GET['submission_id'];
    
    $stmt = $conn->prepare("
        SELECT s.submission_id, u.user_id, u.name as student_name, s.date_submitted, 
               s.submission_url, s.grade, s.ai_feedback as feedback, s.date_submitted as graded_at
        FROM Submissions s
        JOIN Users u ON s.student_id = u.user_id
        WHERE s.submission_id = ?
    ");
    $stmt->bind_param("i", $submission_id);
    $stmt->execute();
    $submission_result = $stmt->get_result();
    
    if ($submission_result->num_rows > 0) {
        $submission_data = $submission_result->fetch_assoc();
    }
}

// Function to get file extension for displaying appropriate icons
function getFileIcon($filePath) {
    $extension = pathinfo($filePath, PATHINFO_EXTENSION);
    
    switch(strtolower($extension)) {
        case 'pdf':
            return 'fa-file-pdf';
        case 'doc':
        case 'docx':
            return 'fa-file-word';
        case 'xls':
        case 'xlsx':
            return 'fa-file-excel';
        case 'ppt':
        case 'pptx':
            return 'fa-file-powerpoint';
        case 'jpg':
        case 'jpeg':
        case 'png':
        case 'gif':
            return 'fa-file-image';
        case 'zip':
        case 'rar':
            return 'fa-file-archive';
        case 'txt':
            return 'fa-file-alt';
        default:
            return 'fa-file';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Grade Assignment - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Grade Assignment</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
        }
        
        #page-breadcrumb {
            background: #2A95BE;
            padding: 4px 0;
            color: white;
            margin-bottom: 40px;
        }
        .vertical-center {
            display: flex;
            align-items: center;
            min-height: 100px;
        }
        .sun {
            background-image: url('images/bg1.jpg');
            background-size: cover;
        }
        .grading-container {
            margin-top: 30px;
        }
        .assignment-info {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .student-card {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .student-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        .submission-content {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            margin-top: 15px;
        }
        .file-attachment {
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }
        .file-icon {
            font-size: 24px;
            margin-right: 10px;
            color: #007bff;
        }
        .grading-section {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 15px;
            border: 1px solid #dee2e6;
        }
        .mt-3 {
            margin-top: 15px;
        }
        .action-buttons {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }
        .graded {
            border-left: 4px solid #28a745;
        }
        .ungraded {
            border-left: 4px solid #dc3545;
        }
        .student-list {
            max-height: 500px;
            overflow-y: auto;
            margin-bottom: 20px;
        }
        .status-badge {
            display: inline-block;
            padding: 3px 7px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-graded {
            background-color: #d4edda;
            color: #155724;
        }
        .status-ungraded {
            background-color: #f8d7da;
            color: #721c24;
        }
        .status-late {
            background-color: #fff3cd;
            color: #856404;
        }
        .submission-text {
            background-color: white;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-top: 10px;
        }
        .search-filter {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .mb-2 {
            margin-bottom: 10px;
        }
        .mr-2 {
            margin-right: 10px;
        }
        .ml-2 {
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="instructor-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <section id="page-breadcrumb">
        <div class="vertical-center sun">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Grade Assignment</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p class="mt-3"><a href="instructor-dashboard.php#assignments" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back to Dashboard</a></p>
                
                <?php if(!empty($success_message)): ?>
                    <div class="alert alert-success">
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>

                <?php if(!empty($error_message)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                
                <div class="assignment-info">
                    <h3><?php echo htmlspecialchars($assignment['title']); ?></h3>
                    <p><strong>Course:</strong> <?php echo htmlspecialchars($assignment['course_title']); ?></p>
                    <p><strong>Topic:</strong> <?php echo htmlspecialchars($assignment['topic']); ?></p>
                    <p><strong>Due Date:</strong> <?php echo date('M d, Y', strtotime($assignment['due_date'])); ?></p>
                    
                    <?php if(!empty($assignment['description'])): ?>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">Assignment Description</h4>
                            </div>
                            <div class="panel-body">
                                <?php echo nl2br(htmlspecialchars($assignment['description'])); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(!empty($assignment['grading_criteria'])): ?>
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h4 class="panel-title">Grading Criteria</h4>
                            </div>
                            <div class="panel-body">
                                <?php echo nl2br(htmlspecialchars($assignment['grading_criteria'])); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($submission_count == 0): ?>
                        <div class="alert alert-info">
                            <p>No students have submitted this assignment yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php if($submission_count > 0 || $student_list->num_rows > 0): ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">Student Submissions</h4>
                                </div>
                                
                                <!-- Search Filter Form -->
                                <div class="panel-body">
                                    <div class="search-filter">
                                        <h5><i class="fa fa-filter"></i> Filter Submissions</h5>
                                        <!-- Important: Using JavaScript to handle form submission instead of standard form action -->
                                        <form id="searchForm" onsubmit="filterSubmissions(event)">
                                            <input type="hidden" name="id" value="<?php echo $assignment_id; ?>">
                                            
                                            <div class="form-group mb-2">
                                                <label for="student_id">Student:</label>
                                                <select name="student_id" id="student_id" class="form-control">
                                                    <option value="">All Students</option>
                                                    <?php 
                                                    while($student = $student_list->fetch_assoc()): 
                                                        $selected = ($selected_student == $student['user_id']) ? 'selected' : '';
                                                    ?>
                                                        <option value="<?php echo $student['user_id']; ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($student['student_name']); ?>
                                                        </option>
                                                    <?php endwhile; ?>
                                                </select>
                                            </div>
                                            
                                            <div class="form-group mb-2">
                                                <label for="date_from">Submitted From:</label>
                                                <input type="date" name="date_from" id="date_from" class="form-control" 
                                                       value="<?php echo $date_from; ?>">
                                            </div>
                                            
                                            <div class="form-group mb-2">
                                                <label for="date_to">Submitted To:</label>
                                                <input type="date" name="date_to" id="date_to" class="form-control" 
                                                       value="<?php echo $date_to; ?>">
                                            </div>
                                            
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fa fa-search"></i> Search
                                                </button>
                                                
                                                <button type="button" id="clearFilters" class="btn btn-default ml-2">
                                                    <i class="fa fa-eraser"></i> Clear Filters
                                                </button>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="student-list">
                                        <div class="list-group">
                                            <?php
                                            if ($submission_count > 0) {
                                                $student_submissions->data_seek(0); // Reset pointer
                                                while($submission = $student_submissions->fetch_assoc()): 
                                                    $is_late = strtotime($submission['date_submitted']) > strtotime($assignment['due_date']);
                                            ?>
                                                <a href="grade_assignment.php?id=<?php echo $assignment_id; ?>&submission_id=<?php echo $submission['submission_id']; ?><?php echo !empty($selected_student) ? '&student_id=' . $selected_student : ''; ?><?php echo !empty($date_from) ? '&date_from=' . $date_from : ''; ?><?php echo !empty($date_to) ? '&date_to=' . $date_to : ''; ?>" 
                                                   class="list-group-item <?php echo (isset($submission_id) && $submission_id == $submission['submission_id']) ? 'active' : ''; ?>">
                                                    <h4 class="list-group-item-heading"><?php echo htmlspecialchars($submission['student_name']); ?></h4>
                                                    <p class="list-group-item-text">
                                                        Submitted: <?php echo date('M d, Y H:i', strtotime($submission['date_submitted'])); ?>
                                                    </p>
                                                    <?php if($submission['grade'] !== null): ?>
                                                        <span class="status-badge status-graded">Graded: <?php echo $submission['grade']; ?>%</span>
                                                    <?php else: ?>
                                                        <span class="status-badge status-ungraded">Not Graded</span>
                                                    <?php endif; ?>
                                                    
                                                    <?php if($is_late): ?>
                                                        <span class="status-badge status-late">Late</span>
                                                    <?php endif; ?>
                                                </a>
                                            <?php 
                                                endwhile;
                                            } else {
                                            ?>
                                                <div class="alert alert-info">
                                                    <p>No submissions match your filter criteria.</p>
                                                </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-8">
                            <?php if($submission_data): ?>
                                <div class="student-card <?php echo ($submission_data['grade'] !== null) ? 'graded' : 'ungraded'; ?>">
                                    <div class="student-header">
                                        <h4>
                                            <?php echo htmlspecialchars($submission_data['student_name']); ?>
                                            <?php if($submission_data['grade'] !== null): ?>
                                                <span class="label label-success">Graded</span>
                                            <?php else: ?>
                                                <span class="label label-warning">Not Graded</span>
                                            <?php endif; ?>
                                        </h4>
                                        <div>
                                            <p><strong>Submitted:</strong> <?php echo date('M d, Y H:i', strtotime($submission_data['date_submitted'])); ?></p>
                                            <?php 
                                            $is_late = strtotime($submission_data['date_submitted']) > strtotime($assignment['due_date']);
                                            if($is_late): 
                                            ?>
                                                <p class="text-warning"><strong>Status:</strong> Late Submission</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="submission-content">
                                        <h4>Submission Details</h4>
                                        
                                        <?php if(!empty($submission_data['submission_url'])): ?>
                                            <div class="file-attachment">
                                                <i class="fas <?php echo getFileIcon($submission_data['submission_url']); ?> file-icon"></i>
                                                <div>
                                                    <p class="mb-1"><strong>Attached File:</strong> 
                                                        <?php echo basename($submission_data['submission_url']); ?>
                                                    </p>
                                                    <a href="<?php echo $submission_data['submission_url']; ?>" class="btn btn-sm btn-primary" target="_blank">
                                                        <i class="fa fa-download"></i> Download
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if(!empty($submission_data['submission_text'])): ?>
                                            <div>
                                                <h5><strong>Text Submission:</strong></h5>
                                                <div class="submission-text">
                                                    <?php echo nl2br(htmlspecialchars($submission_data['submission_text'])); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if(empty($submission_data['submission_url']) && empty($submission_data['submission_text'])): ?>
                                            <div class="alert alert-warning">
                                                <p>No content was submitted (empty submission).</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="grading-section">
                                        <h4>Grade Submission</h4>
                                        
                                        <?php if($submission_data['grade'] === null): ?>
                                            <form name="grade_assignment" action="grade_assignment.php?id=<?php echo $assignment_id; ?>&submission_id=<?php echo $submission_data['submission_id']; ?><?php echo !empty($selected_student) ? '&student_id=' . $selected_student : ''; ?><?php echo !empty($date_from) ? '&date_from=' . $date_from : ''; ?><?php echo !empty($date_to) ? '&date_to=' . $date_to : ''; ?>" method="post">
                                                <input type="hidden" name="submission_id" value="<?php echo $submission_data['submission_id']; ?>">
                                                
                                                <div class="form-group">
                                                    <label for="grade">Score:</label>
                                                    <div class="input-group">
                                                        <input type="number" class="form-control" id="grade" name="grade" min="0" max="100" step="1" required>
                                                        <span class="input-group-addon">%</span>
                                                    </div>
                                                    <small class="text-muted">Enter a value between 0-100</small>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label for="feedback">Feedback:</label>
                                                    <textarea class="form-control" id="feedback" name="feedback" rows="5"></textarea>
                                                </div>
                                                
                                                <button type="submit" name="grade_assignment" class="btn btn-primary">
                                                    <i class="fa fa-save"></i> Save Grade
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <div class="alert alert-success">
                                                <p><strong>Grade:</strong> <?php echo $submission_data['grade']; ?>%</p>
                                                <p><strong>Status:</strong> <?php echo ($submission_data['grade'] >= 60) ? 'Pass' : 'Fail'; ?> (60% threshold)</p>
                                                <p><strong>Graded On:</strong> <?php echo date('M d, Y H:i', strtotime($submission_data['graded_at'])); ?></p>
                                                
                                                <?php if(!empty($submission_data['feedback'])): ?>
                                                    <div class="panel panel-default mt-3">
                                                        <div class="panel-heading">
                                                            <h5 class="panel-title">Instructor Feedback</h5>
                                                        </div>
                                                        <div class="panel-body">
                                                            <?php echo nl2br(htmlspecialchars($submission_data['feedback'])); ?>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                                
                                                <div class="mt-3">
                                                    <p>To edit this grade, please contact the system administrator.</p>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <p>Select a student from the list to view and grade their submission.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Score input validation
            const gradeInput = document.getElementById('grade');
            if (gradeInput) {
                gradeInput.addEventListener('input', function() {
                    // Remove any non-numeric characters
                    this.value = this.value.replace(/[^0-9]/g, '');
                    
                    // Ensure value is between 0-100
                    const val = parseInt(this.value, 10);
                    if (isNaN(val)) {
                        this.value = '';
                    } else if (val < 0) {
                        this.value = '0';
                    } else if (val > 100) {
                        this.value = '100';
                    }
                });
            }
            
            // Form submission validation
            const form = document.querySelector('form[name="grade_assignment"]');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const grade = document.getElementById('grade');
                    if (grade && (grade.value === '' || isNaN(parseInt(grade.value)))) {
                        e.preventDefault();
                        alert('Please provide a valid score.');
                        return false;
                    }
                    
                    return confirm('Are you sure you want to submit this grade? This action cannot be undone.');
                });
            }
            
            // Clear filter button handler
            document.getElementById('clearFilters').addEventListener('click', function() {
                document.getElementById('student_id').value = '';
                document.getElementById('date_from').value = '';
                document.getElementById('date_to').value = '';
                
                // Submit the form with cleared filters
                filterSubmissions(new Event('submit'));
            });
        });
        
        // Function to handle the filter form submission
        function filterSubmissions(event) {
            event.preventDefault(); // Prevent the form from submitting normally
            
            // Get the form values
            const assignmentId = <?php echo $assignment_id; ?>;
            const studentId = document.getElementById('student_id').value;
            const dateFrom = document.getElementById('date_from').value;
            const dateTo = document.getElementById('date_to').value;
            
            // Build the URL with query parameters
            let url = `grade_assignment.php?id=${assignmentId}`;
            
            if (studentId) {
                url += `&student_id=${studentId}`;
            }
            
            if (dateFrom) {
                url += `&date_from=${dateFrom}`;
            }
            
            if (dateTo) {
                url += `&date_to=${dateTo}`;
            }
            
            // Redirect to the new URL (filtering results)
            window.location.href = url;
        }
    </script>
</body>
</html>'