<?php
// email_utils.php - Utility functions for sending email notifications

require_once 'email_system.php';

class EmailUtils {
    /**
     * Send feedback notification to a student when a grade or quiz result is available
     * 
     * @param int $student_id - Student user ID
     * @param int $course_id - Course ID
     * @param string $title - Title of the assignment or quiz
     * @param string $type - Type of work ('assignment' or 'quiz')
     * @return bool - Success or failure
     */
    public static function sendFeedbackNotification($student_id, $course_id, $title, $type = 'assignment') {
        global $conn;
        
        // Get DB connection if it's not available
        if (!isset($conn) || !$conn) {
            require_once 'db_connection.php';
        }
        
        // Create email notification system
        $emailSystem = new EmailNotificationSystem($conn);
        
        // Get student details
        $stmt = $conn->prepare("
            SELECT name, email FROM Users WHERE user_id = ?
        ");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $student = $result->fetch_assoc();
        
        // Get course details
        $stmt = $conn->prepare("
            SELECT title FROM Courses WHERE course_id = ?
        ");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
        $course_result = $stmt->get_result();
        
        if ($course_result->num_rows === 0) {
            return false;
        }
        
        $course = $course_result->fetch_assoc();
        
        // Prepare email content
        $subject = "Feedback Available - " . $title;
        
        $message = "
            <h3>Hello " . htmlspecialchars($student['name']) . ",</h3>
            <p>Your " . ($type == 'quiz' ? 'quiz submission' : 'assignment') . " for <strong>" . 
            htmlspecialchars($title) . "</strong> in the course <strong>" . 
            htmlspecialchars($course['title']) . "</strong> has been graded.</p>
            
            <p>You can now view your grade and feedback by logging into your account.</p>
            
            <p><a href='http://localhost/lms/" . 
            ($type == 'quiz' ? "view_quiz_results.php?id=" : "view_submission.php?id=") . 
            "' class='button'>View Feedback</a></p>
            
            <p>Thank you for your hard work!</p>
        ";
        
        // Send the email
        return $emailSystem->sendEmail(
            $student['email'],
            $subject,
            $message,
            $student_id,
            'Grade Update'
        );
    }
    
    /**
     * Send a deadline reminder email to a student
     * 
     * @param int $student_id - Student user ID
     * @param int $course_id - Course ID
     * @param string $title - Title of the assignment or quiz
     * @param string $due_date - Due date in Y-m-d format
     * @param string $type - Type of work ('assignment' or 'quiz')
     * @param int $item_id - Assignment or quiz ID
     * @return bool - Success or failure
     */
    public static function sendDeadlineReminder($student_id, $course_id, $title, $due_date, $type = 'assignment', $item_id = 0) {
        global $conn;
        
        // Get DB connection if it's not available
        if (!isset($conn) || !$conn) {
            require_once 'db_connection.php';
        }
        
        // Create email notification system
        $emailSystem = new EmailNotificationSystem($conn);
        
        // Get student details
        $stmt = $conn->prepare("
            SELECT name, email FROM Users WHERE user_id = ?
        ");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $student = $result->fetch_assoc();
        
        // Get course details
        $stmt = $conn->prepare("
            SELECT title FROM Courses WHERE course_id = ?
        ");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
        $course_result = $stmt->get_result();
        
        if ($course_result->num_rows === 0) {
            return false;
        }
        
        $course = $course_result->fetch_assoc();
        
        // Format due date
        $formatted_due_date = date('l, F j, Y', strtotime($due_date));
        
        // Prepare email content
        $subject = "Deadline Reminder: " . $title . " due in 3 days";
        
        $message = "
            <h3>Hello " . htmlspecialchars($student['name']) . ",</h3>
            <p>This is a friendly reminder that your " . ($type == 'quiz' ? 'quiz' : 'assignment') . " 
               <strong>" . htmlspecialchars($title) . "</strong> for the course 
               <strong>" . htmlspecialchars($course['title']) . "</strong> 
               is due in 3 days on <strong>" . $formatted_due_date . "</strong>.</p>
            
            <p>Please make sure to submit your work before the deadline.</p>
            
            <p><a href='http://localhost/lms/" . 
            ($type == 'quiz' ? "take_quiz.php?id=" . $item_id : "submit_assignment.php?id=" . $item_id) . 
            "' class='button'>" . ($type == 'quiz' ? 'Take Quiz Now' : 'Submit Assignment') . "</a></p>
        ";
        
        // Send the email
        return $emailSystem->sendEmail(
            $student['email'],
            $subject,
            $message,
            $student_id,
            'Deadline Reminder'
        );
    }
}
?>