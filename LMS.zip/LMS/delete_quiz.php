<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {
    header("Location: login.php");
    exit();
}

// Verify that a quiz ID was provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "No quiz ID provided for deletion.";
    
    // Get the base URL without any anchors or query parameters
    $base_url = 'instructor_dashboard.php';
    if (isset($_SERVER['HTTP_REFERER'])) {
        // Extract the base URL from the referrer by removing anything after # or ?
        $ref_url = $_SERVER['HTTP_REFERER'];
        $base_url = preg_replace('/([\?#].*)$/', '', $ref_url);
        
        // If we're left with just a directory path, append instructor_dashboard.php
        if (substr($base_url, -1) === '/') {
            $base_url .= 'instructor_dashboard.php';
        }
    }
    
    // Always add the quizzes anchor to ensure we redirect to the quiz section
    $redirect_url = $base_url . '#quizzes';
    
    header("Location: $redirect_url");
    exit();
}

$quiz_id = $_GET['id'];

// Begin transaction to ensure data consistency
$conn->begin_transaction();

try {
    // First, check if the quiz exists and is associated with the instructor's courses
    $stmt = $conn->prepare("
        SELECT q.quiz_id 
        FROM Quizzes q
        JOIN Courses c ON q.course_id = c.course_id
        WHERE q.quiz_id = ?
    ");
    
    $stmt->bind_param("i", $quiz_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        throw new Exception("Quiz not found or you don't have permission to delete it.");
    }
    
    // Delete related records first to maintain referential integrity
    
    // 1. Delete student quiz answers
    $stmt = $conn->prepare("
        DELETE sqa FROM StudentQuizAnswers sqa
        JOIN StudentQuizzes sq ON sqa.student_quiz_id = sq.student_quiz_id
        WHERE sq.quiz_id = ?
    ");
    $stmt->bind_param("i", $quiz_id);
    $stmt->execute();
    
    // 2. Delete student quiz attempts
    $stmt = $conn->prepare("DELETE FROM StudentQuizzes WHERE quiz_id = ?");
    $stmt->bind_param("i", $quiz_id);
    $stmt->execute();
    
    // 3. Delete questions related to this quiz
    $stmt = $conn->prepare("DELETE FROM Questions WHERE quiz_id = ?");
    $stmt->bind_param("i", $quiz_id);
    $stmt->execute();
    
    // 4. Finally delete the quiz itself
    $stmt = $conn->prepare("DELETE FROM Quizzes WHERE quiz_id = ?");
    $stmt->bind_param("i", $quiz_id);
    $stmt->execute();
    
    // If we got this far, commit the transaction
    $conn->commit();
    
    $_SESSION['success_message'] = "Quiz was successfully deleted.";
    
    // Get the base URL without any anchors or query parameters
    $base_url = 'instructor_dashboard.php';
    if (isset($_SERVER['HTTP_REFERER'])) {
        // Extract the base URL from the referrer by removing anything after # or ?
        $ref_url = $_SERVER['HTTP_REFERER'];
        $base_url = preg_replace('/([\?#].*)$/', '', $ref_url);
        
        // If we're left with just a directory path, append instructor_dashboard.php
        if (substr($base_url, -1) === '/') {
            $base_url .= 'instructor_dashboard.php';
        }
    }
    
    // Always add the quizzes anchor to ensure we redirect to the quiz section
    $redirect_url = $base_url . '#quizzes';
    
    header("Location: $redirect_url");
    exit();
} catch (Exception $e) {
    // Something went wrong, rollback the transaction
    $conn->rollback();
    
    $_SESSION['error_message'] = "Error deleting quiz: " . $e->getMessage();
    
    // Get the base URL without any anchors or query parameters
    $base_url = 'instructor_dashboard.php';
    if (isset($_SERVER['HTTP_REFERER'])) {
        // Extract the base URL from the referrer by removing anything after # or ?
        $ref_url = $_SERVER['HTTP_REFERER'];
        $base_url = preg_replace('/([\?#].*)$/', '', $ref_url);
        
        // If we're left with just a directory path, append instructor_dashboard.php
        if (substr($base_url, -1) === '/') {
            $base_url .= 'instructor_dashboard.php';
        }
    }
    
    // Always add the quizzes anchor to ensure we redirect to the quiz section
    $redirect_url = $base_url . '#quizzes';
    
    header("Location: $redirect_url");
    exit();
}
?>