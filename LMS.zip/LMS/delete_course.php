<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Check if course ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid course ID";
    header("Location: admin-dashboard.php");
    exit();
}

$course_id = $_GET['id'];

// Get course data first to confirm it exists
$stmt = $conn->prepare("SELECT title FROM Courses WHERE course_id = ?");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error_message'] = "Course not found";
    header("Location: admin-dashboard.php");
    exit();
}

$course_title = $result->fetch_assoc()['title'];

try {
    // Start transaction
    $conn->begin_transaction();
    
    // Check if this course is a prerequisite for other courses
    $stmt = $conn->prepare("SELECT course_id, title FROM Courses WHERE prereq_course_id = ?");
    $stmt->bind_param("i", $course_id);
    $stmt->execute();
    $prereq_result = $stmt->get_result();
    
    if ($prereq_result->num_rows > 0) {
        // Update dependent courses to remove the prerequisite
        $stmt = $conn->prepare("UPDATE Courses SET prereq_course_id = NULL WHERE prereq_course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
    }
    
    // Delete related records in other tables (these would be based on your actual schema)
    // Here are some examples, adjust as necessary:
    
    // Delete course materials
    if (isset($conn->query("SHOW TABLES LIKE 'CourseMaterials'")->num_rows) && 
        $conn->query("SHOW TABLES LIKE 'CourseMaterials'")->num_rows > 0) {
        $stmt = $conn->prepare("DELETE FROM CourseMaterials WHERE course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
    }
    
    // Delete assignments
    if (isset($conn->query("SHOW TABLES LIKE 'Assignments'")->num_rows) && 
        $conn->query("SHOW TABLES LIKE 'Assignments'")->num_rows > 0) {
        $stmt = $conn->prepare("DELETE FROM Assignments WHERE course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
    }
    
    // Delete quizzes
    if (isset($conn->query("SHOW TABLES LIKE 'Quizzes'")->num_rows) && 
        $conn->query("SHOW TABLES LIKE 'Quizzes'")->num_rows > 0) {
        $stmt = $conn->prepare("DELETE FROM Quizzes WHERE course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
    }
    
    // Delete enrollments
    if (isset($conn->query("SHOW TABLES LIKE 'Enrollments'")->num_rows) && 
        $conn->query("SHOW TABLES LIKE 'Enrollments'")->num_rows > 0) {
        $stmt = $conn->prepare("DELETE FROM Enrollments WHERE course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
    }
    
    // Delete attendance records
    if (isset($conn->query("SHOW TABLES LIKE 'Attendance'")->num_rows) && 
        $conn->query("SHOW TABLES LIKE 'Attendance'")->num_rows > 0) {
        $stmt = $conn->prepare("DELETE FROM Attendance WHERE course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
    }
    
    // Delete student feedback
    if (isset($conn->query("SHOW TABLES LIKE 'StudentFeedback'")->num_rows) && 
        $conn->query("SHOW TABLES LIKE 'StudentFeedback'")->num_rows > 0) {
        $stmt = $conn->prepare("DELETE FROM StudentFeedback WHERE course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
    }
    
    // Delete instructor assignments (if you have a separate table for this)
    // $stmt = $conn->prepare("DELETE FROM CourseInstructors WHERE course_id = ?");
    // $stmt->bind_param("i", $course_id);
    // $stmt->execute();
    
    // Finally, delete the course itself
    $stmt = $conn->prepare("DELETE FROM Courses WHERE course_id = ?");
    $stmt->bind_param("i", $course_id);
    
    if ($stmt->execute()) {
        // Commit transaction
        $conn->commit();
        $_SESSION['success_message'] = "Course '" . htmlspecialchars($course_title) . "' has been deleted successfully.";
    } else {
        throw new Exception($conn->error);
    }
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    $_SESSION['error_message'] = "Error deleting course: " . $e->getMessage();
}

header("Location: admin-dashboard.php");
exit();
?>