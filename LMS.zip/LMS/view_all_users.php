<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Get admin data
$admin_id = $_SESSION['user_id'];
$admin_name = $_SESSION['name'];

// Set default sorting and filtering
$sort_field = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
$sort_order = isset($_GET['order']) ? $_GET['order'] : 'DESC';
$filter_role = isset($_GET['role']) ? $_GET['role'] : '';
$search_term = isset($_GET['search']) ? $_GET['search'] : '';
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$items_per_page = 15;
$offset = ($page - 1) * $items_per_page;

// Build the query
$query = "SELECT user_id, name, email, role, active, DATE_FORMAT(created_at, '%d/%m/%Y') as created_date,
                 DATE_FORMAT(last_login, '%d/%m/%Y %H:%i') as last_login_date
          FROM Users WHERE 1=1";
$count_query = "SELECT COUNT(*) as total FROM Users WHERE 1=1";

// Add filter conditions
if (!empty($filter_role)) {
    $query .= " AND role = '$filter_role'";
    $count_query .= " AND role = '$filter_role'";
}

if (!empty($search_term)) {
    $query .= " AND (name LIKE '%$search_term%' OR email LIKE '%$search_term%')";
    $count_query .= " AND (name LIKE '%$search_term%' OR email LIKE '%$search_term%')";
}

// Add sorting
$query .= " ORDER BY $sort_field $sort_order";

// Add pagination
$query .= " LIMIT $offset, $items_per_page";

// Execute queries
$users_result = $conn->query($query);
$count_result = $conn->query($count_query);
$total_users = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_users / $items_per_page);

// Get number of users by role for statistics
$role_stats_query = "SELECT role, COUNT(*) as count FROM Users GROUP BY role";
$role_stats_result = $conn->query($role_stats_query);
$role_stats = [];

while ($row = $role_stats_result->fetch_assoc()) {
    $role_stats[$row['role']] = $row['count'];
}

// Check for messages
$success_message = '';
$error_message = '';

if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="User Management - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>All Users</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .page-container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            width: 95%;
        }
        .page-title {
            margin-bottom: 30px;
            color: #333;
            text-align: center;
        }
        .filters-bar {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .action-buttons {
            margin-bottom: 20px;
        }
        .stats-container {
            display: flex;
            justify-content: space-around;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        .stat-box {
            text-align: center;
            padding: 15px;
            border-radius: 10px;
            background-color: #f8f9fa;
            box-shadow: 0px 2px 4px rgba(0,0,0,0.1);
            width: 200px;
            margin-bottom: 15px;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #007bff;
        }
        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
        }
        .active-label {
            color: #28a745;
            font-weight: bold;
        }
        .inactive-label {
            color: #dc3545;
            font-weight: bold;
        }
        .role-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 3px;
            font-size: 12px;
            text-transform: uppercase;
        }
        .role-admin {
            background-color: #dc3545;
            color: white;
        }
        .role-instructor {
            background-color: #fd7e14;
            color: white;
        }
        .role-student {
            background-color: #28a745;
            color: white;
        }
        .sort-link {
            color: #007bff;
            text-decoration: none;
        }
        .sort-link:hover {
            text-decoration: underline;
        }
        .sort-active {
            font-weight: bold;
        }
        .sort-icon {
            margin-left: 5px;
        }
        .pagination-container {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li class="active"><a href="admin-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="page-container">
        <h2 class="page-title">All Users</h2>
        
        <?php if(!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if(!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <div class="stats-container">
            <div class="stat-box">
                <div class="stat-number"><?php echo $total_users; ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            
            <div class="stat-box">
                <div class="stat-number"><?php echo isset($role_stats['Admin']) ? $role_stats['Admin'] : 0; ?></div>
                <div class="stat-label">Administrators</div>
            </div>
            
            <div class="stat-box">
                <div class="stat-number"><?php echo isset($role_stats['Instructor']) ? $role_stats['Instructor'] : 0; ?></div>
                <div class="stat-label">Instructors</div>
            </div>
            
            <div class="stat-box">
                <div class="stat-number"><?php echo isset($role_stats['Student']) ? $role_stats['Student'] : 0; ?></div>
                <div class="stat-label">Students</div>
            </div>
        </div>
        
        <div class="filters-bar">
            <form method="GET" action="view_all_users.php" class="form-inline">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="search" class="mr-2">Search:</label>
                            <input type="text" class="form-control" id="search" name="search" placeholder="Name or Email" value="<?php echo htmlspecialchars($search_term); ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="role" class="mr-2">Filter by Role:</label>
                            <select class="form-control" id="role" name="role">
                                <option value="">All Roles</option>
                                <option value="Admin" <?php echo ($filter_role == 'Admin') ? 'selected' : ''; ?>>Admin</option>
                                <option value="Instructor" <?php echo ($filter_role == 'Instructor') ? 'selected' : ''; ?>>Instructor</option>
                                <option value="Student" <?php echo ($filter_role == 'Student') ? 'selected' : ''; ?>>Student</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="sort" class="mr-2">Sort by:</label>
                            <select class="form-control" id="sort" name="sort">
                                <option value="created_at" <?php echo ($sort_field == 'created_at') ? 'selected' : ''; ?>>Registration Date</option>
                                <option value="name" <?php echo ($sort_field == 'name') ? 'selected' : ''; ?>>Name</option>
                                <option value="email" <?php echo ($sort_field == 'email') ? 'selected' : ''; ?>>Email</option>
                                <option value="last_login" <?php echo ($sort_field == 'last_login') ? 'selected' : ''; ?>>Last Login</option>
                            </select>
                            <select class="form-control" id="order" name="order">
                                <option value="ASC" <?php echo ($sort_order == 'ASC') ? 'selected' : ''; ?>>Ascending</option>
                                <option value="DESC" <?php echo ($sort_order == 'DESC') ? 'selected' : ''; ?>>Descending</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Apply Filters
                        </button>
                        <a href="view_all_users.php" class="btn btn-secondary">
                            <i class="fas fa-sync"></i> Reset
                        </a>
                    </div>
                </div>
            </form>
        </div>
        
        <div class="action-buttons">
            <a href="add_user.php" class="btn btn-success">
                <i class="fas fa-user-plus"></i> Add New User
            </a>
            <a href="admin-dashboard.php" class="btn btn-primary">
                <i class="fas fa-tachometer-alt"></i> Back to Dashboard
            </a>
        </div>
        
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Registration Date</th>
                        <th>Last Login</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($users_result->num_rows > 0): ?>
                        <?php while ($user = $users_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $user['user_id']; ?></td>
                                <td><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <span class="role-badge role-<?php echo strtolower($user['role']); ?>">
                                        <?php echo $user['role']; ?>
                                    </span>
                                </td>
                                <td><?php echo $user['active'] ? '<span class="active-label">Active</span>' : '<span class="inactive-label">Inactive</span>'; ?></td>
                                <td><?php echo htmlspecialchars($user['created_date']); ?></td>
                                <td><?php echo $user['last_login_date'] ? htmlspecialchars($user['last_login_date']) : 'Never'; ?></td>
                                <td>
                                    <a href="edit_user.php?id=<?php echo $user['user_id']; ?>" class="btn btn-warning btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <?php if ($user['user_id'] != $_SESSION['user_id']): ?>
                                        <button class="btn btn-danger btn-sm" onclick="confirmDeleteUser(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars(addslashes($user['name'])); ?>')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center">No users found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($total_pages > 1): ?>
            <div class="pagination-container">
                <ul class="pagination">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>&sort=<?php echo $sort_field; ?>&order=<?php echo $sort_order; ?>&role=<?php echo $filter_role; ?>&search=<?php echo urlencode($search_term); ?>">
                                Previous
                            </a>
                        </li>
                    <?php endif; ?>
                    
                    <?php
                    $start_page = max(1, $page - 2);
                    $end_page = min($total_pages, $page + 2);
                    
                    if ($start_page > 1) {
                        echo '<li class="page-item"><a class="page-link" href="?page=1&sort=' . $sort_field . '&order=' . $sort_order . '&role=' . $filter_role . '&search=' . urlencode($search_term) . '">1</a></li>';
                        if ($start_page > 2) {
                            echo '<li class="page-item disabled"><a class="page-link">...</a></li>';
                        }
                    }
                    
                    for ($i = $start_page; $i <= $end_page; $i++) {
                        echo '<li class="page-item ' . (($i == $page) ? 'active' : '') . '">';
                        echo '<a class="page-link" href="?page=' . $i . '&sort=' . $sort_field . '&order=' . $sort_order . '&role=' . $filter_role . '&search=' . urlencode($search_term) . '">' . $i . '</a>';
                        echo '</li>';
                    }
                    
                    if ($end_page < $total_pages) {
                        if ($end_page < $total_pages - 1) {
                            echo '<li class="page-item disabled"><a class="page-link">...</a></li>';
                        }
                        echo '<li class="page-item"><a class="page-link" href="?page=' . $total_pages . '&sort=' . $sort_field . '&order=' . $sort_order . '&role=' . $filter_role . '&search=' . urlencode($search_term) . '">' . $total_pages . '</a></li>';
                    }
                    ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>&sort=<?php echo $sort_field; ?>&order=<?php echo $sort_order; ?>&role=<?php echo $filter_role; ?>&search=<?php echo urlencode($search_term); ?>">
                                Next
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        function confirmDeleteUser(userId, userName) {
            if (confirm("Are you sure you want to delete user '" + userName + "'? This action cannot be undone.")) {
                window.location.href = "delete_user.php?id=" + userId;
            }
        }
    </script>
</body>
</html>