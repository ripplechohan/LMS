<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Student') {
    header("Location: login.php");
    exit();
}

// Get student data
$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['name'];

// Check if submission_id is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid submission ID";
    header("Location: student-dashboard.php");
    exit();
}

$submission_id = $_GET['id'];

// Get submission details
$stmt = $conn->prepare("
    SELECT s.submission_id, s.student_id, s.assignment_id, s.date_submitted, 
           s.submission_url, s.grade, s.ai_feedback,
           a.title as assignment_title, a.description as assignment_description, a.due_date,
           c.title as course_title, c.course_id
    FROM Submissions s
    JOIN Assignments a ON s.assignment_id = a.assignment_id
    JOIN Courses c ON a.course_id = c.course_id
    WHERE s.submission_id = ? AND s.student_id = ?
");
$stmt->bind_param("ii", $submission_id, $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error_message'] = "Submission not found or you don't have permission to view it";
    header("Location: student-dashboard.php");
    exit();
}

$submission = $result->fetch_assoc();

// Function to get file extension for displaying appropriate icons
function getFileIcon($filePath) {
    $extension = pathinfo($filePath, PATHINFO_EXTENSION);
    
    switch(strtolower($extension)) {
        case 'pdf':
            return 'fa-file-pdf';
        case 'doc':
        case 'docx':
            return 'fa-file-word';
        case 'xls':
        case 'xlsx':
            return 'fa-file-excel';
        case 'ppt':
        case 'pptx':
            return 'fa-file-powerpoint';
        case 'jpg':
        case 'jpeg':
        case 'png':
        case 'gif':
            return 'fa-file-image';
        case 'zip':
        case 'rar':
            return 'fa-file-archive';
        case 'txt':
            return 'fa-file-alt';
        default:
            return 'fa-file';
    }
}

// Determine grade letter and color
$grade_class = '';
$grade_letter = '';
                                                
if ($submission['grade'] >= 90) {
    $grade_class = 'text-success';
    $grade_letter = 'A';
} elseif ($submission['grade'] >= 80) {
    $grade_class = 'text-info';
    $grade_letter = 'B';
} elseif ($submission['grade'] >= 70) {
    $grade_class = 'text-primary';
    $grade_letter = 'C';
} elseif ($submission['grade'] >= 60) {
    $grade_class = 'text-warning';
    $grade_letter = 'D';
} else {
    $grade_class = 'text-danger';
    $grade_letter = 'F';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Assignment Feedback - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Assignment Feedback</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
        }
        
        #page-breadcrumb {
            background: #2A95BE;
            padding: 4px 0;
            color: white;
            margin-bottom: 40px;
        }
        .vertical-center {
            display: flex;
            align-items: center;
            min-height: 100px;
        }
        .sun {
            background-image: url('images/bg1.jpg');
            background-size: cover;
        }
        .feedback-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-bottom: 40px;
        }
        .assignment-info {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .submission-info {
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .feedback-section {
            background-color: #f0f8ff;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #007bff;
            margin-bottom: 20px;
        }
        .grade-section {
            text-align: center;
            padding: 30px 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .grade-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background-color: #fff;
            border: 10px solid #28a745;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            font-weight: bold;
        }
        .file-attachment {
            background-color: #f5f5f5;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }
        .file-icon {
            font-size: 24px;
            margin-right: 10px;
            color: #007bff;
        }
        .mt-4 {
            margin-top: 20px;
        }
        .mb-4 {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="student-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <section id="page-breadcrumb">
        <div class="vertical-center sun">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Assignment Feedback</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p><a href="student-dashboard.php#assignments" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back to Dashboard</a></p>
                
                <div class="feedback-container">
                    <div class="assignment-info">
                        <div class="row">
                            <div class="col-md-8">
                                <h3><?php echo htmlspecialchars($submission['assignment_title']); ?></h3>
                                <p><strong>Course:</strong> <?php echo htmlspecialchars($submission['course_title']); ?></p>
                                <p><strong>Due Date:</strong> <?php echo date('M d, Y', strtotime($submission['due_date'])); ?></p>
                            </div>
                            <div class="col-md-4 text-right">
                                <a href="access-course.php?id=<?php echo $submission['course_id']; ?>" class="btn btn-primary">
                                    <i class="fa fa-book"></i> Go to Course
                                </a>
                            </div>
                        </div>
                        
                        <?php if (!empty($submission['assignment_description'])): ?>
                            <div class="panel panel-default mt-4">
                                <div class="panel-heading">
                                    <h4 class="panel-title">Assignment Description</h4>
                                </div>
                                <div class="panel-body">
                                    <?php echo nl2br(htmlspecialchars($submission['assignment_description'])); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-8">
                            <div class="submission-info">
                                <h4>Your Submission</h4>
                                <p><strong>Submitted On:</strong> <?php echo date('M d, Y H:i', strtotime($submission['date_submitted'])); ?></p>
                                
                                <?php if (!empty($submission['submission_url'])): ?>
                                    <div class="file-attachment">
                                        <i class="fas <?php echo getFileIcon($submission['submission_url']); ?> file-icon"></i>
                                        <div>
                                            <p class="mb-1"><strong>Attached File:</strong> 
                                                <?php echo basename($submission['submission_url']); ?>
                                            </p>
                                            <a href="<?php echo $submission['submission_url']; ?>" class="btn btn-sm btn-primary" target="_blank">
                                                <i class="fa fa-download"></i> Download
                                            </a>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-warning">
                                        <p>No file was attached to this submission.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="feedback-section">
                                <h4><i class="fas fa-comment-alt"></i> Instructor Feedback</h4>
                                <?php if (!empty($submission['ai_feedback'])): ?>
                                    <div class="well">
                                        <?php echo nl2br(htmlspecialchars($submission['ai_feedback'])); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        <p>No detailed feedback provided by the instructor.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="grade-section">
                                <h4>Your Grade</h4>
                                <?php if ($submission['grade'] !== null): ?>
                                    <div class="grade-circle" style="border-color: 
                                        <?php 
                                        if ($submission['grade'] >= 90) echo '#28a745';
                                        elseif ($submission['grade'] >= 80) echo '#17a2b8';
                                        elseif ($submission['grade'] >= 70) echo '#007bff';
                                        elseif ($submission['grade'] >= 60) echo '#ffc107';
                                        else echo '#dc3545';
                                        ?>">
                                        <?php echo $grade_letter; ?>
                                    </div>
                                    <h3 class="<?php echo $grade_class; ?>"><?php echo $submission['grade']; ?>%</h3>
                                    <p>
                                        <?php 
                                        if ($submission['grade'] >= 90) echo 'Excellent work!';
                                        elseif ($submission['grade'] >= 80) echo 'Good job!';
                                        elseif ($submission['grade'] >= 70) echo 'Satisfactory work.';
                                        elseif ($submission['grade'] >= 60) echo 'Needs improvement.';
                                        else echo 'Significant improvement needed.';
                                        ?>
                                    </p>
                                <?php else: ?>
                                    <div class="alert alert-warning">
                                        <p>This assignment has not been graded yet.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">Submission Status</h4>
                                </div>
                                <div class="panel-body">
                                    <?php 
                                    $status = "Submitted";
                                    $statusClass = "text-primary";
                                    
                                    if ($submission['grade'] !== null) {
                                        $status = "Graded";
                                        $statusClass = "text-success";
                                    }
                                    
                                    $onTime = strtotime($submission['date_submitted']) <= strtotime($submission['due_date']);
                                    ?>
                                    <p><strong>Status:</strong> <span class="<?php echo $statusClass; ?>"><?php echo $status; ?></span></p>
                                    <p><strong>Submission Timing:</strong> 
                                        <?php if ($onTime): ?>
                                            <span class="text-success">On Time</span>
                                        <?php else: ?>
                                            <span class="text-danger">Late</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="student-dashboard.php#assignments" class="btn btn-default">
                            <i class="fa fa-arrow-left"></i> Back to Assignments
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>