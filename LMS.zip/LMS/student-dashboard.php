<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';
include 'feedback_utils.php';

// Limit the number of redirects
if (isset($_SESSION['redirect_count']) && $_SESSION['redirect_count'] > 3) {
    // If too many redirects, destroy the session and send to login
    session_destroy();
    header("Location: login.php");
    exit();
}

// Increment redirect count
$_SESSION['redirect_count'] = isset($_SESSION['redirect_count']) ? 
    $_SESSION['redirect_count'] + 1 : 1;

$force_refresh = false;

// Check if feedback needs regeneration using our utility function
// Right after the redirect count increment
// Add this check before the feedback regeneration logic
if (isset($_GET['skip_feedback_check'])) {
    // Skip the feedback regeneration check if this flag is set
    $force_refresh = false;
} else if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'Student') {
    $student_id = $_SESSION['user_id'];
    
    // Add more robust logging
    error_log("Checking feedback regeneration for student ID: " . $student_id);
    
    if (checkFeedbackNeedsRegeneration($student_id)) {
        $force_refresh = true;
        
        // Log detailed information
        error_log("Feedback regeneration needed for student ID: " . $student_id);
        
        // Redirect to feedback.php with regenerate flag
        header("Location: feedback.php?regenerate=1");
        exit();
    }
}

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Student') {
    // Reset redirect count
    unset($_SESSION['redirect_count']);
    
    header("Location: login.php");
    exit();
}

// Reset redirect count if we've successfully reached this point
unset($_SESSION['redirect_count']);

// Get student data
$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['name'];

// Update the enrolled courses query to exclude dropped courses
$stmt = $conn->prepare("
    SELECT c.course_id, c.title, e.progress_percentage 
    FROM Enrollments e 
    JOIN Courses c ON e.course_id = c.course_id 
    WHERE e.student_id = ? AND e.status = 'Enrolled'
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$enrolled_courses = $stmt->get_result();

// Calculate overall progress
$total_progress = 0;
$course_count = 0;
if ($enrolled_courses->num_rows > 0) {
    while ($course = $enrolled_courses->fetch_assoc()) {
        $total_progress += $course['progress_percentage'];
        $course_count++;
    }
    $overall_progress = $course_count > 0 ? round($total_progress / $course_count) : 0;
    // Reset result pointer to beginning
    $enrolled_courses->data_seek(0);
} else {
    $overall_progress = 0;
}




// Fetch upcoming assignments
$stmt = $conn->prepare("
    SELECT a.assignment_id, a.title, a.due_date, c.title as course_title 
    FROM Assignments a
    JOIN Courses c ON a.course_id = c.course_id
    JOIN Enrollments e ON c.course_id = e.course_id
    WHERE e.student_id = ? AND a.due_date >= CURDATE() AND e.status = 'Enrolled'
    ORDER BY a.due_date ASC
    LIMIT 5
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$upcoming_assignments = $stmt->get_result();

// Fetch submitted assignments
$stmt = $conn->prepare("
    SELECT s.submission_id, a.assignment_id, a.title as assignment_title, s.date_submitted, s.grade, c.title as course_title, c.course_id
    FROM Submissions s
    JOIN Assignments a ON s.assignment_id = a.assignment_id
    JOIN Courses c ON a.course_id = c.course_id
    WHERE s.student_id = ?
    ORDER BY s.date_submitted DESC
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$submitted_assignments = $stmt->get_result();

// Create an array of submitted assignment IDs for easy lookup
$submitted_assignment_ids = [];
while ($submission = $submitted_assignments->fetch_assoc()) {
    $submitted_assignment_ids[$submission['assignment_id']] = true;
}
// Reset the result pointer
$submitted_assignments->data_seek(0);

// Fetch available quizzes (published only)
$stmt = $conn->prepare("
    SELECT q.quiz_id, q.title, c.title as course_title, q.created_at
    FROM Quizzes q
    JOIN Courses c ON q.course_id = c.course_id
    JOIN Enrollments e ON c.course_id = e.course_id
    WHERE e.student_id = ? AND q.is_published = 1 AND e.status = 'Enrolled'
    ORDER BY q.created_at DESC
    LIMIT 5
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$available_quizzes = $stmt->get_result();

// Fetch completed quizzes
$stmt = $conn->prepare("
    SELECT sq.student_quiz_id, sq.quiz_id, q.title, sq.score, sq.total_questions, 
           sq.completed_at, c.title as course_title, c.course_id, sq.is_completed
    FROM StudentQuizzes sq
    JOIN Quizzes q ON sq.quiz_id = q.quiz_id
    JOIN Courses c ON q.course_id = c.course_id
    WHERE sq.student_id = ? AND (sq.is_completed = 1 OR (sq.is_completed = 0 AND sq.completed_at IS NOT NULL))
    ORDER BY sq.completed_at DESC
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$completed_quizzes = $stmt->get_result();

// Create an array of completed quiz IDs for easy lookup
$completed_quiz_ids = [];
while ($completed = $completed_quizzes->fetch_assoc()) {
    $completed_quiz_ids[$completed['quiz_id']] = $completed;
}
// Reset the result pointer
$completed_quizzes->data_seek(0);

$dropped_courses_list = [];
$dropped_stmt = $conn->prepare("
    SELECT e.course_id, e.enrollment_date as status_change_date
    FROM Enrollments e
    WHERE e.student_id = ? AND e.status = 'Dropped'
");
$dropped_stmt->bind_param("i", $student_id);
$dropped_stmt->execute();
$dropped_result = $dropped_stmt->get_result();
while ($dropped = $dropped_result->fetch_assoc()) {
    $dropped_courses_list[$dropped['course_id']] = [
        'dropped_date' => $dropped['status_change_date']
    ];
}
// Organize grades by course
$grades_by_course = [];

// Add assignment grades to the course array
while ($assignment = $submitted_assignments->fetch_assoc()) {
    $course_id = $assignment['course_id'];
    $course_title = $assignment['course_title'];
    
    if (!isset($grades_by_course[$course_id])) {
        $grades_by_course[$course_id] = [
            'title' => $course_title,
            'assignments' => [],
            'quizzes' => []
        ];
    }
    
    $grades_by_course[$course_id]['assignments'][] = [
        'title' => $assignment['assignment_title'],
        'date' => $assignment['date_submitted'],
        'grade' => $assignment['grade']
    ];
}

// Reset pointer
$submitted_assignments->data_seek(0);

// Add quiz grades to the course array
// Add quiz grades to the course array
while ($quiz = $completed_quizzes->fetch_assoc()) {
    $course_id = $quiz['course_id'];
    $course_title = $quiz['course_title'];
    
    if (!isset($grades_by_course[$course_id])) {
        $grades_by_course[$course_id] = [
            'title' => $course_title,
            'assignments' => [],
            'quizzes' => [],
            'is_dropped' => isset($dropped_courses_list[$course_id]),
            'dropped_date' => isset($dropped_courses_list[$course_id]) ? $dropped_courses_list[$course_id]['dropped_date'] : null
        ];
    }
    
    $percentage = ($quiz['total_questions'] > 0) ? 
        round($quiz['score'] * 100) : 0;
    
    $actual_score = $quiz['score'] * $quiz['total_questions'];
    
    $grades_by_course[$course_id]['quizzes'][] = [
        'title' => $quiz['title'],
        'date' => $quiz['completed_at'],
        'score' => number_format($actual_score, 2),
        'total' => $quiz['total_questions'],
        'percentage' => $percentage
    ];
}

// Reset pointer
$completed_quizzes->data_seek(0);

foreach ($grades_by_course as $course_id => &$course_data) {
    // Check if this course is in the dropped_courses_list
    $course_data['is_dropped'] = isset($dropped_courses_list[$course_id]);
    $course_data['dropped_date'] = isset($dropped_courses_list[$course_id]) ? 
        $dropped_courses_list[$course_id]['dropped_date'] : null;
}
unset($course_data); // Break the reference

// Check for success message
$success_message = '';
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Student Dashboard - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Student Dashboard</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
        }
        #dashboard {
            padding: 50px 0;
        }
        .dashboard-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        .dashboard-box {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            width: 80%;
            text-align: center;
            margin: 0 auto;
        }
        .nav-tabs {
            display: flex;
            justify-content: center;
            border-bottom: 2px solid #ddd;
            width: 80%;
            margin: 0 auto 20px;
        }
        .nav-tabs a {
            padding: 10px 20px;
            text-decoration: none;
            color: black;
            border: 1px solid transparent;
            margin: 5px;
            border-radius: 5px;
        }
        .nav-tabs a.active {
            background-color: #007bff;
            color: white;
        }
        table {
            width: 100%;
            text-align: left; 
        }
        th, td {
            padding: 10px; 
        }
        th {
            text-align: left; 
        }
        .btn {
            margin-top: 10px; 
        }
        .progress {
            height: 20px;
            margin-bottom: 20px;
        }
        @media (max-width: 768px) {
            .dashboard-box, .nav-tabs {
                width: 95%;
            }
        }
        .welcome-message {
            margin-bottom: 20px;
            font-weight: bold;
            color: #333;
        }
        .badge-success {
            background-color: #28a745;
        }
        .badge-warning {
            background-color: #ffc107;
            color: #212529;
        }
        .ml-2 {
            margin-left: 0.5rem;
        }
        .alert {
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .btn-completed {
            background-color: #6c757d;
            color: white;
            cursor: default;
        }
        .btn-completed:hover {
            background-color: #6c757d;
            color: white;
        }
        .course-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 20px;
            overflow: hidden;
        }
        .course-header {
            background-color: #f5f5f5;
            padding: 15px;
            cursor: pointer;
            border-bottom: 1px solid #ddd;
        }
        .course-content {
            padding: 15px;
            display: none;
        }
        .grade-table {
            margin-bottom: 15px;
            width: 100%;
        }
        .grade-table th {
            background-color: #f8f9fa;
        }
        .grade-a {
            color: #28a745;
            font-weight: bold;
        }
        .grade-b {
            color: #17a2b8;
            font-weight: bold;
        }
        .grade-c {
            color: #ffc107;
            font-weight: bold;
        }
        .grade-d {
            color: #fd7e14;
            font-weight: bold;
        }
        .grade-f {
            color: #dc3545;
            font-weight: bold;
        }
        .no-grades {
            text-align: center;
            padding: 10px;
            font-style: italic;
            color: #6c757d;
        }
        .course-status-dropped {
    display: inline-block;
    margin-left: 10px;
    padding: 2px 8px;
    background-color: #f44336;
    color: white;
    font-size: 12px;
    border-radius: 4px;
    font-weight: normal;
}

.dropped-course-notice {
    background-color: #ffebee;
    border-left: 4px solid #f44336;
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 4px;
}

.dropped-date, .dropped-reason {
    color: #757575;
    font-size: 14px;
    margin: 5px 0;
}

.progress-summary {
    margin-bottom: 30px;
}

.summary-card, .course-stat-card {
    background-color: #f8f9fa;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    text-align: center;
}

.summary-card h5, .course-stat-card h6 {
    margin-bottom: 10px;
    color: #495057;
}

.stat-value {
    font-size: 24px;
    font-weight: bold;
    color: #212529;
}

.progress-chart-container {
    background-color: white;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 30px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.course-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.course-progress-indicator {
    flex: 0 0 200px;
}

.course-progress-indicator .progress {
    height: 10px;
    background-color: #e9ecef;
}

.deadline-list {
    list-style: none;
    padding: 0;
}

.deadline-list li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid #dee2e6;
}

.deadline-date {
    flex: 0 0 100px;
    font-weight: bold;
}

.deadline-title {
    flex: 1;
    padding: 0 15px;
}

.deadline-type {
    flex: 0 0 100px;
    text-align: center;
    background-color: #e9ecef;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 12px;
}

.deadline-countdown {
    flex: 0 0 100px;
    text-align: right;
    font-weight: bold;
}

.deadline-urgent {
    color: #dc3545;
}

.deadline-warning {
    color: #fd7e14;
}

.deadline-normal {
    color: #28a745;
}

.improvement-positive {
    color: #28a745;
    font-weight: bold;
}

.improvement-negative {
    color: #dc3545;
    font-weight: bold;
}

.improvement-neutral {
    color: #6c757d;
}

.upcoming-deadlines {
    margin-bottom: 20px;
}

.course-stats {
    margin-bottom: 20px;
}

.grade-a { color: #28a745; font-weight: bold; }
.grade-b { color: #17a2b8; font-weight: bold; }
.grade-c { color: #ffc107; font-weight: bold; }
.grade-d { color: #fd7e14; font-weight: bold; }
.grade-f { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <section id="dashboard">
        <div class="container">
            <h2 class="text-center">Student Dashboard</h2>
            <p class="text-center welcome-message">Welcome, <?php echo htmlspecialchars($student_name); ?>!</p>
            
            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <div class="nav-tabs">
                <a href="#overview" class="tab-link active" onclick="showTab(event, 'overview')">Overview</a>
                <a href="#courses" class="tab-link" onclick="showTab(event, 'courses')">Course Access</a>
                <a href="#assignments" class="tab-link" onclick="showTab(event, 'assignments')">Assignments</a>
                <a href="#quizzes" class="tab-link" onclick="showTab(event, 'quizzes')">Quizzes</a>
                <a href="#progress" class="tab-link" onclick="showTab(event, 'progress')">Progress Tracking</a>
                <a href="#feedback" class="tab-link" onclick="showTab(event, 'feedback')">Feedback</a>
            </div>

            <div id="overview" class="dashboard-box tab-content">
    <h3>Overview</h3>
    <h4>Enrolled Courses</h4>
    <table class="table">
        <thead>
            <tr>
                <th>Course</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($enrolled_courses->num_rows > 0): ?>
                <?php while($course = $enrolled_courses->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($course['title']); ?></td>
                        <td><a href="access-course.php?id=<?php echo $course['course_id']; ?>" class="btn btn-primary">Access Course</a></td>
                    </tr>
                <?php endwhile; ?>
                <?php $enrolled_courses->data_seek(0); // Reset the result pointer ?>
            <?php else: ?>
                <tr>
                    <td colspan="2" class="text-center">No active course enrollments</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <h4>Dropped Courses</h4>
    <table class="table">
        <thead>
            <tr>
                <th>Course</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Get dropped courses
            $stmt = $conn->prepare("
                SELECT c.course_id, c.title
                FROM Enrollments e 
                JOIN Courses c ON e.course_id = c.course_id 
                WHERE e.student_id = ? AND e.status = 'Dropped'
            ");
            $stmt->bind_param("i", $student_id);
            $stmt->execute();
            $dropped_courses = $stmt->get_result();
            
            if ($dropped_courses->num_rows > 0):
                while($course = $dropped_courses->fetch_assoc()):
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($course['title']); ?></td>
                    <td><span class="label label-default">Dropped</span></td>
                </tr>
            <?php 
                endwhile;
            else:
            ?>
                <tr>
                    <td colspan="2" class="text-center">No dropped courses</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <h4>Upcoming Assignments</h4>
    <ul class="list-group">
        <?php if ($upcoming_assignments->num_rows > 0): ?>
            <?php while($assignment = $upcoming_assignments->fetch_assoc()): ?>
                <li class="list-group-item">
                    <?php echo htmlspecialchars($assignment['title']); ?> 
                    (<?php echo htmlspecialchars($assignment['course_title']); ?>) - 
                    Due in <?php echo ceil((strtotime($assignment['due_date']) - time()) / (60 * 60 * 24)); ?> days
                </li>
            <?php endwhile; ?>
            <?php $upcoming_assignments->data_seek(0); // Reset the result pointer ?>
        <?php else: ?>
            <li class="list-group-item">No upcoming assignments</li>
        <?php endif; ?>
    </ul>
    
    <h4>Available Quizzes</h4>
    <ul class="list-group">
        <?php if ($available_quizzes->num_rows > 0): ?>
            <?php while($quiz = $available_quizzes->fetch_assoc()): ?>
                <li class="list-group-item">
                    <?php echo htmlspecialchars($quiz['title']); ?> 
                    (<?php echo htmlspecialchars($quiz['course_title']); ?>) - 
                    Created on <?php echo date('d/m/Y', strtotime($quiz['created_at'])); ?>
                    <?php if (isset($completed_quiz_ids[$quiz['quiz_id']])): ?>
                        <span class="badge badge-success">Completed</span>
                    <?php endif; ?>
                </li>
            <?php endwhile; ?>
            <?php $available_quizzes->data_seek(0); // Reset the result pointer ?>
        <?php else: ?>
            <li class="list-group-item">No quizzes available</li>
        <?php endif; ?>
    </ul>
</div>

            <div id="courses" class="dashboard-box tab-content" style="display:none;">
    <h3>Course Access</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Course</th>
                           
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($enrolled_courses->num_rows > 0): ?>
                            <?php while($course = $enrolled_courses->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($course['title']); ?></td>
                                    
                                    <td><a href="access-course.php?id=<?php echo $course['course_id']; ?>" class="btn btn-primary">Access Course</a></td>
                                </tr>
                            <?php endwhile; ?>
                            <?php $enrolled_courses->data_seek(0); // Reset the result pointer ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-center">No courses enrolled</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Replacement for the assignments section in student_dashboard.php -->
<div id="assignments" class="dashboard-box tab-content" style="display:none;">
    <h3>Assignments</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Assignment</th>
                <th>Course</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Create a set to track unique assignments
            $unique_assignments = [];

            // Process upcoming assignments first
            if ($upcoming_assignments->num_rows > 0) {
                while($assignment = $upcoming_assignments->fetch_assoc()) {
                    // Check if this assignment has been submitted
                    $is_submitted = isset($submitted_assignment_ids[$assignment['assignment_id']]);
                    
                    // Initialize or update the assignment in unique_assignments
                    if (!isset($unique_assignments[$assignment['assignment_id']])) {
                        $unique_assignments[$assignment['assignment_id']] = [
                            'title' => $assignment['title'],
                            'course_title' => $assignment['course_title'],
                            'is_submitted' => $is_submitted,
                            'assignment_id' => $assignment['assignment_id']
                        ];
                    }
                }
                // Reset the result pointer
                $upcoming_assignments->data_seek(0);
            }

            // Process submitted assignments
            if ($submitted_assignments->num_rows > 0) {
                while($submission = $submitted_assignments->fetch_assoc()) {
                    // Ensure the assignment is in unique_assignments
                    if (!isset($unique_assignments[$submission['assignment_id']])) {
                        $unique_assignments[$submission['assignment_id']] = [];
                    }

                    // Update or add submission details
                    $unique_assignments[$submission['assignment_id']] = array_merge(
                        $unique_assignments[$submission['assignment_id']],
                        [
                            'title' => $submission['assignment_title'],
                            'course_title' => $submission['course_title'],
                            'is_submitted' => true,
                            'submission_id' => $submission['submission_id'],
                            'grade' => $submission['grade']
                        ]
                    );
                }
                // Reset the result pointer
                $submitted_assignments->data_seek(0);
            }

            // Sort assignments to show upcoming first, then submitted
            uksort($unique_assignments, function($a, $b) use ($unique_assignments) {
                $a_data = $unique_assignments[$a];
                $b_data = $unique_assignments[$b];

                // Prioritize assignments with no submission
                if (isset($a_data['is_submitted']) !== isset($b_data['is_submitted'])) {
                    return $a_data['is_submitted'] ? 1 : -1;
                }

                // If both have same submission status, keep original order
                return 0;
            });

            // Display unique assignments
            if (!empty($unique_assignments)) {
                foreach ($unique_assignments as $assignment_id => $assignment) {
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($assignment['title']); ?></td>
                        <td><?php echo htmlspecialchars($assignment['course_title']); ?></td>
                        <td>
                            <?php 
                            // Determine status
                            if (isset($assignment['grade']) && $assignment['grade'] !== null) {
                                // Assignment is graded
                                echo 'Graded - ' . $assignment['grade'] . '%';
                            } elseif (isset($assignment['is_submitted']) && $assignment['is_submitted']) {
                                // Assignment is submitted but not graded
                                echo 'Submitted - Pending Grade';
                            } else {
                                // Assignment is not submitted
                                echo 'Not Submitted';
                            }
                            ?>
                        </td>
                        <td>
                            <?php 
                            if (isset($assignment['grade']) && $assignment['grade'] !== null) {
                                // Graded assignment
                                ?>
                                <a href="view_feedback.php?id=<?php echo $assignment['submission_id']; ?>" class="btn btn-info">View Feedback</a>
                                <?php
                            } elseif (isset($assignment['is_submitted']) && $assignment['is_submitted']) {
                                // Submitted but not graded
                                ?>
                                <button class="btn btn-secondary" disabled>Awaiting Feedback</button>
                                <?php
                            } else {
                                // Not submitted
                                ?>
                                <a href="submission.php?id=<?php echo $assignment_id; ?>" class="btn btn-primary">Submit Assignment</a>
                                <?php
                            }
                            ?>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                ?>
                <tr>
                    <td colspan="4" class="text-center">No assignments found</td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>
</div>

            <div id="quizzes" class="dashboard-box tab-content" style="display:none;">
                <h3>Quizzes</h3>
                
                <h4>Available Quizzes</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Quiz</th>
                            <th>Course</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($available_quizzes->num_rows > 0): ?>
                            <?php while($quiz = $available_quizzes->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($quiz['title']); ?></td>
                                    <td><?php echo htmlspecialchars($quiz['course_title']); ?></td>
                                    <td>
                                        <?php if (isset($completed_quiz_ids[$quiz['quiz_id']])): ?>
                                            <button class="btn btn-completed" disabled>Completed</button>
                                        <?php else: ?>
                                            <a href="attempt_quiz.php?id=<?php echo $quiz['quiz_id']; ?>" class="btn btn-primary">Attempt Quiz</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-center">No available quizzes</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                <h4>Completed Quizzes</h4>
<table class="table">
    <thead>
        <tr>
            <th>Quiz</th>
            <th>Course</th>
            <th>Score</th>
            <th>Completed On</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($completed_quizzes->num_rows > 0): ?>
            <?php while($quiz = $completed_quizzes->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($quiz['title']); ?></td>
                    <td><?php echo htmlspecialchars($quiz['course_title']); ?></td>
                    <td>
    <?php if ($quiz['is_completed'] == 1): ?>
        <?php 
            // Get total possible points for this quiz
            $stmt = $conn->prepare("
                SELECT SUM(point_value) as total_points 
                FROM Questions 
                WHERE quiz_id = ?
            ");
            $stmt->bind_param("i", $quiz['quiz_id']);
            $stmt->execute();
            $points_result = $stmt->get_result();
            $points_data = $points_result->fetch_assoc();
            $total_possible_points = $points_data && $points_data['total_points'] ? $points_data['total_points'] : $quiz['total_questions'];
            
            $percentage = round($quiz['score'] * 100);
            $points_earned = round($quiz['score'] * $total_possible_points, 1);
            
            echo $points_earned . '/' . $total_possible_points . ' points (' . $percentage . '%)';
        ?>
    <?php else: ?>
        <span class="badge badge-warning">Grade Pending</span>
    <?php endif; ?>
</td>
                    <td><?php echo date('d/m/Y', strtotime($quiz['completed_at'])); ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" class="text-center">No completed quizzes</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
            </div>
            

            <div id="progress" class="dashboard-box tab-content" style="display:none;">
    <h3>Progress Tracking</h3>
    
    <h4>Course Progress Overview</h4>
    
    <!-- Progress Summary Stats -->
    <div class="progress-summary">
        <div class="row">
            <div class="col-md-4">
                <div class="summary-card">
                    <h5>Overall GPA</h5>
                    <div class="stat-value">
                        <?php 
                            $total_grade_points = 0;
                            $total_courses = 0;
                            
                            foreach ($grades_by_course as $course_id => $course_data) {
                                if (!isset($course_data['is_dropped']) || !$course_data['is_dropped']) {
                                    $course_avg = 0;
                                    $item_count = 0;
                                    
                                    if (!empty($course_data['assignments'])) {
                                        foreach ($course_data['assignments'] as $assignment) {
                                            if ($assignment['grade'] !== null) {
                                                $course_avg += $assignment['grade'];
                                                $item_count++;
                                            }
                                        }
                                    }
                                    
                                    if (!empty($course_data['quizzes'])) {
                                        foreach ($course_data['quizzes'] as $quiz) {
                                            $course_avg += $quiz['percentage'];
                                            $item_count++;
                                        }
                                    }
                                    
                                    if ($item_count > 0) {
                                        $course_avg = $course_avg / $item_count;
                                        $total_grade_points += $course_avg;
                                        $total_courses++;
                                    }
                                }
                            }
                            
                            $overall_gpa = $total_courses > 0 ? round($total_grade_points / $total_courses / 25, 2) : 0;
                            echo $overall_gpa;
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="summary-card">
                    <h5>Courses In Progress</h5>
                    <div class="stat-value">
                        <?php 
                            $active_courses = 0;
                            foreach ($grades_by_course as $course_data) {
                                if (!isset($course_data['is_dropped']) || !$course_data['is_dropped']) {
                                    $active_courses++;
                                }
                            }
                            echo $active_courses;
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="summary-card">
                    <h5>Completion Rate</h5>
                    <div class="stat-value">
                        <?php 
                            $total_items = 0;
                            $completed_items = 0;
                            
                            foreach ($grades_by_course as $course_data) {
                                if (!isset($course_data['is_dropped']) || !$course_data['is_dropped']) {
                                    if (!empty($course_data['assignments'])) {
                                        foreach ($course_data['assignments'] as $assignment) {
                                            $total_items++;
                                            if ($assignment['grade'] !== null) {
                                                $completed_items++;
                                            }
                                        }
                                    }
                                    
                                    if (!empty($course_data['quizzes'])) {
                                        $total_items += count($course_data['quizzes']);
                                        $completed_items += count($course_data['quizzes']);
                                    }
                                }
                            }
                            
                            $completion_rate = $total_items > 0 ? round(($completed_items / $total_items) * 100) : 0;
                            echo $completion_rate . '%';
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Progress Over Time Chart -->
   
<!-- This is what you need to ADD in its place - a complete implementation -->
<!-- Add this after the Progress Summary Stats section -->

<?php
// Generate chart data for the student's performance
$chart_data = [
    'labels' => [],
    'datasets' => []
];

// Get all courses the student is enrolled in
$course_colors = [];
$course_datasets = [];

// Initialize datasets for each course
foreach ($grades_by_course as $course_id => $course_data) {
    if (!isset($course_data['is_dropped']) || !$course_data['is_dropped']) {
        $course_datasets[$course_id] = [
            'label' => $course_data['title'],
            'data' => [],
            'fill' => false,
            'tension' => 0.1
        ];
    }
}

// Add a dataset for overall performance
$overall_dataset = [
    'label' => 'Overall Performance',
    'data' => [],
    'fill' => false,
    'tension' => 0.1,
    'borderWidth' => 3,
    'borderDash' => [5, 5]
];

// Collect all dates from assignments and quizzes
$all_dates = [];
$all_grades = [];

// Process assignments
foreach ($grades_by_course as $course_id => $course_data) {
    if (!isset($course_data['is_dropped']) || !$course_data['is_dropped']) {
        if (!empty($course_data['assignments'])) {
            foreach ($course_data['assignments'] as $assignment) {
                if ($assignment['grade'] !== null) {
                    $date = date('Y-m-d', strtotime($assignment['date']));
                    $all_dates[$date] = $date;
                    $all_grades[$date][$course_id][] = [
                        'grade' => $assignment['grade'],
                        'title' => $assignment['title'],
                        'type' => 'Assignment'
                    ];
                }
            }
        }
        
        // Process quizzes
        if (!empty($course_data['quizzes'])) {
            foreach ($course_data['quizzes'] as $quiz) {
                $date = date('Y-m-d', strtotime($quiz['date']));
                $all_dates[$date] = $date;
                $all_grades[$date][$course_id][] = [
                    'grade' => $quiz['percentage'],
                    'title' => $quiz['title'],
                    'type' => 'Quiz'
                ];
            }
        }
    }
}

// Sort dates chronologically
ksort($all_dates);

// Initialize cumulative sums and counts
$cumulative_sum_by_course = [];
$cumulative_count_by_course = [];
$overall_sum = 0;
$overall_count = 0;

// For each date, calculate the average grade for each course
foreach ($all_dates as $date) {
    // Format date for display
    $display_date = date('M d', strtotime($date));
    $chart_data['labels'][] = $display_date;
    
    // Process each course's grades for this date
    foreach ($course_datasets as $course_id => $dataset) {
        // Initialize if needed
        if (!isset($cumulative_sum_by_course[$course_id])) {
            $cumulative_sum_by_course[$course_id] = 0;
            $cumulative_count_by_course[$course_id] = 0;
        }
        
        // If there are grades for this course on this date
        if (isset($all_grades[$date][$course_id])) {
            $daily_sum = 0;
            $daily_count = 0;
            
            foreach ($all_grades[$date][$course_id] as $grade_info) {
                $daily_sum += $grade_info['grade'];
                $daily_count++;
                
                // Add to overall totals
                $overall_sum += $grade_info['grade'];
                $overall_count++;
            }
            
            // Add to course cumulative totals
            $cumulative_sum_by_course[$course_id] += $daily_sum;
            $cumulative_count_by_course[$course_id] += $daily_count;
        }
        
        // Calculate cumulative average for the course
        $cumulative_avg = $cumulative_count_by_course[$course_id] > 0 ? 
            round($cumulative_sum_by_course[$course_id] / $cumulative_count_by_course[$course_id]) : null;
            
        // Add the cumulative average to the dataset
        $course_datasets[$course_id]['data'][] = $cumulative_avg;
    }
    
    // Calculate overall cumulative average
    $overall_avg = $overall_count > 0 ? round($overall_sum / $overall_count) : null;
    $overall_dataset['data'][] = $overall_avg;
}

// Add all course datasets to the chart data
foreach ($course_datasets as $course_id => $dataset) {
    // Only add courses that have data
    if (count(array_filter($dataset['data'], function($value) { return $value !== null; })) > 0) {
        $chart_data['datasets'][] = $dataset;
    }
}

// Add overall dataset if there's data
if (count(array_filter($overall_dataset['data'], function($value) { return $value !== null; })) > 0) {
    $chart_data['datasets'][] = $overall_dataset;
}

// Convert to JSON for JavaScript
$chart_data_json = json_encode($chart_data);
?>

<div class="progress-chart-container">
    <div class="chart-header d-flex justify-content-between align-items-center mb-3">
        <h5><i class="fas fa-chart-line mr-2"></i>Performance Trend</h5>
        <div class="btn-group chart-type-toggle">
            <button type="button" class="btn btn-sm btn-outline-primary active" id="view-cumulative">Cumulative</button>
            <button type="button" class="btn btn-sm btn-outline-primary" id="view-individual">Individual Grades</button>
        </div>
    </div>
    <div class="chart-container" style="position: relative; height: 300px;">
        <canvas id="progressChart"></canvas>
    </div>
    <div class="chart-legend mt-3 text-center">
        <small class="text-muted">This chart shows your cumulative performance over time. Toggle between views to see your progress.</small>
    </div>
</div>
</parameter>
</invoke>
    
    <?php if (!empty($grades_by_course)): ?>
        <?php foreach ($grades_by_course as $course_id => $course_data): ?>
            <div class="course-card">
                <div class="course-header" onclick="toggleCourseGrades(<?php echo $course_id; ?>)">
                    <h5>
                        <i class="fa fa-chevron-right" id="course-grades-icon-<?php echo $course_id; ?>"></i>
                        <?php echo htmlspecialchars($course_data['title']); ?>
                        <?php if (isset($course_data['is_dropped']) && $course_data['is_dropped']): ?>
                            <span class="course-status-dropped">Dropped</span>
                        <?php endif; ?>
                    </h5>
                    <?php if (!isset($course_data['is_dropped']) || !$course_data['is_dropped']): ?>
                    <div class="course-progress-indicator">
                        <?php 
                            $completed_items = 0;
                            $total_items = 0;
                            
                            if (!empty($course_data['assignments'])) {
                                foreach ($course_data['assignments'] as $assignment) {
                                    $total_items++;
                                    if ($assignment['grade'] !== null) {
                                        $completed_items++;
                                    }
                                }
                            }
                            
                            if (!empty($course_data['quizzes'])) {
                                $total_items += count($course_data['quizzes']);
                                $completed_items += count($course_data['quizzes']);
                            }
                            
                            $progress_percentage = $total_items > 0 ? round(($completed_items / $total_items) * 100) : 0;
                        ?>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width: <?php echo $progress_percentage; ?>%;" 
                                 aria-valuenow="<?php echo $progress_percentage; ?>" aria-valuemin="0" aria-valuemax="100">
                                <?php echo $progress_percentage; ?>%
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="course-content" id="course-grades-content-<?php echo $course_id; ?>">
                    <?php if (!isset($course_data['is_dropped']) || !$course_data['is_dropped']): ?>
                        <!-- Course Deadline Calendar -->
                        <?php if (!empty($course_data['upcoming_deadlines'])): ?>
                            <div class="upcoming-deadlines">
                                <h6>Upcoming Deadlines</h6>
                                <ul class="deadline-list">
                                    <?php foreach ($course_data['upcoming_deadlines'] as $deadline): ?>
                                        <li>
                                            <span class="deadline-date"><?php echo date('d/m/Y', strtotime($deadline['due_date'])); ?></span>
                                            <span class="deadline-title"><?php echo htmlspecialchars($deadline['title']); ?></span>
                                            <span class="deadline-type"><?php echo htmlspecialchars($deadline['type']); ?></span>
                                            <?php
                                                $days_remaining = ceil((strtotime($deadline['due_date']) - time()) / (60 * 60 * 24));
                                                $deadline_class = 'deadline-normal';
                                                if ($days_remaining <= 3) {
                                                    $deadline_class = 'deadline-urgent';
                                                } elseif ($days_remaining <= 7) {
                                                    $deadline_class = 'deadline-warning';
                                                }
                                            ?>
                                            <span class="deadline-countdown <?php echo $deadline_class; ?>">
                                                <?php echo $days_remaining; ?> days left
                                            </span>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Course Specific Progress Stats -->
                        <div class="course-stats">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="course-stat-card">
                                        <h6>Current Grade</h6>
                                        <?php 
                                            $course_avg = 0;
                                            $item_count = 0;
                                            
                                            if (!empty($course_data['assignments'])) {
                                                foreach ($course_data['assignments'] as $assignment) {
                                                    if ($assignment['grade'] !== null) {
                                                        $course_avg += $assignment['grade'];
                                                        $item_count++;
                                                    }
                                                }
                                            }
                                            
                                            if (!empty($course_data['quizzes'])) {
                                                foreach ($course_data['quizzes'] as $quiz) {
                                                    $course_avg += $quiz['percentage'];
                                                    $item_count++;
                                                }
                                            }
                                            
                                            if ($item_count > 0) {
                                                $course_avg = round($course_avg / $item_count, 1);
                                                
                                                $grade_class = '';
                                                $grade_letter = '';
                                                
                                                if ($course_avg >= 90) {
                                                    $grade_class = 'grade-a';
                                                    $grade_letter = 'A';
                                                } elseif ($course_avg >= 80) {
                                                    $grade_class = 'grade-b';
                                                    $grade_letter = 'B';
                                                } elseif ($course_avg >= 70) {
                                                    $grade_class = 'grade-c';
                                                    $grade_letter = 'C';
                                                } elseif ($course_avg >= 60) {
                                                    $grade_class = 'grade-d';
                                                    $grade_letter = 'D';
                                                } else {
                                                    $grade_class = 'grade-f';
                                                    $grade_letter = 'F';
                                                }
                                            
                                                echo '<span class="' . $grade_class . '">' . $course_avg . '% (' . $grade_letter . ')</span>';
                                            } else {
                                                echo '<span>No grades yet</span>';
                                            }
                                        ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="course-stat-card">
                                        <h6>Completion</h6>
                                        <?php echo $progress_percentage; ?>%
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" style="width: <?php echo $progress_percentage; ?>%;" 
                                                aria-valuenow="<?php echo $progress_percentage; ?>" aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="course-stat-card">
                                        <h6>Time to Completion</h6>
                                        <?php 
                                            if (!empty($course_data['end_date'])) {
                                                $days_left = ceil((strtotime($course_data['end_date']) - time()) / (60 * 60 * 24));
                                                echo $days_left . ' days left';
                                            } else {
                                                echo 'Ongoing';
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if (!empty($course_data['assignments'])): ?>
                            <h6>Assignments</h6>
                            <table class="grade-table table table-striped">
                                <thead>
                                    <tr>
                                        <th>Assignment</th>
                                        <th>Submission Date</th>
                                        <th>Grade</th>
                                        <th>Improvement</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $prev_grade = null;
                                        foreach ($course_data['assignments'] as $assignment): 
                                    ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($assignment['title']); ?></td>
                                            <td><?php echo date('d/m/Y', strtotime($assignment['date'])); ?></td>
                                            <td>
                                                <?php if ($assignment['grade'] !== null): ?>
                                                    <?php 
                                                        $grade_class = '';
                                                        $grade_letter = '';
                                                        
                                                        if ($assignment['grade'] >= 90) {
                                                            $grade_class = 'grade-a';
                                                            $grade_letter = 'A';
                                                        } elseif ($assignment['grade'] >= 80) {
                                                            $grade_class = 'grade-b';
                                                            $grade_letter = 'B';
                                                        } elseif ($assignment['grade'] >= 70) {
                                                            $grade_class = 'grade-c';
                                                            $grade_letter = 'C';
                                                        } elseif ($assignment['grade'] >= 60) {
                                                            $grade_class = 'grade-d';
                                                            $grade_letter = 'D';
                                                        } else {
                                                            $grade_class = 'grade-f';
                                                            $grade_letter = 'F';
                                                        }
                                                    ?>
                                                    <span class="<?php echo $grade_class; ?>">
                                                        <?php echo $assignment['grade']; ?>% (<?php echo $grade_letter; ?>)
                                                    </span>
                                                <?php else: ?>
                                                    Pending
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php 
                                                    if ($assignment['grade'] !== null && $prev_grade !== null) {
                                                        $improvement = $assignment['grade'] - $prev_grade;
                                                        if ($improvement > 0) {
                                                            echo '<span class="improvement-positive">+' . $improvement . '%</span>';
                                                        } elseif ($improvement < 0) {
                                                            echo '<span class="improvement-negative">' . $improvement . '%</span>';
                                                        } else {
                                                            echo '<span class="improvement-neutral">No change</span>';
                                                        }
                                                    } else {
                                                        echo '—';
                                                    }
                                                    
                                                    if ($assignment['grade'] !== null) {
                                                        $prev_grade = $assignment['grade'];
                                                    }
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <p class="no-grades">No completed assignments for this course</p>
                        <?php endif; ?>
                        
                        <?php if (!empty($course_data['quizzes'])): ?>
                            <h6>Quizzes</h6>
                            <table class="grade-table table table-striped">
                                <thead>
                                    <tr>
                                        <th>Quiz</th>
                                        <th>Completion Date</th>
                                        <th>Score</th>
                                        <th>Grade</th>
                                        <th>Improvement</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $prev_quiz_percentage = null;
                                        foreach ($course_data['quizzes'] as $quiz): 
                                    ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($quiz['title']); ?></td>
                                            <td><?php echo date('d/m/Y', strtotime($quiz['date'])); ?></td>
                                            <td>
                                                <?php
                                                    // Get total possible points for this quiz
                                                    $stmt = $conn->prepare("
                                                        SELECT q.quiz_id, SUM(q2.point_value) as total_points 
                                                        FROM Quizzes q
                                                        JOIN Questions q2 ON q.quiz_id = q2.quiz_id
                                                        WHERE q.title = ?
                                                        GROUP BY q.quiz_id
                                                    ");
                                                    $stmt->bind_param("s", $quiz['title']);
                                                    $stmt->execute();
                                                    $points_result = $stmt->get_result();
                                                    $points_data = $points_result->fetch_assoc();
                                                    $total_possible_points = $points_data && $points_data['total_points'] ? $points_data['total_points'] : $quiz['total'];
                                                    
                                                    // Calculate points earned
                                                    $points_earned = round(($quiz['percentage'] / 100) * $total_possible_points, 1);
                                                    
                                                    echo $points_earned . '/' . $total_possible_points . ' points';
                                                ?>
                                            </td>
                                            <td>
                                                <?php 
                                                    $grade_class = '';
                                                    $grade_letter = '';
                                                    
                                                    if ($quiz['percentage'] >= 90) {
                                                        $grade_class = 'grade-a';
                                                        $grade_letter = 'A';
                                                    } elseif ($quiz['percentage'] >= 80) {
                                                        $grade_class = 'grade-b';
                                                        $grade_letter = 'B';
                                                    } elseif ($quiz['percentage'] >= 70) {
                                                        $grade_class = 'grade-c';
                                                        $grade_letter = 'C';
                                                    } elseif ($quiz['percentage'] >= 60) {
                                                        $grade_class = 'grade-d';
                                                        $grade_letter = 'D';
                                                    } else {
                                                        $grade_class = 'grade-f';
                                                        $grade_letter = 'F';
                                                    }
                                                ?>
                                                <span class="<?php echo $grade_class; ?>">
                                                    <?php echo $quiz['percentage']; ?>% (<?php echo $grade_letter; ?>)
                                                </span>
                                            </td>
                                            <td>
                                                <?php 
                                                    if ($prev_quiz_percentage !== null) {
                                                        $improvement = $quiz['percentage'] - $prev_quiz_percentage;
                                                        if ($improvement > 0) {
                                                            echo '<span class="improvement-positive">+' . $improvement . '%</span>';
                                                        } elseif ($improvement < 0) {
                                                            echo '<span class="improvement-negative">' . $improvement . '%</span>';
                                                        } else {
                                                            echo '<span class="improvement-neutral">No change</span>';
                                                        }
                                                    } else {
                                                        echo '—';
                                                    }
                                                    
                                                    $prev_quiz_percentage = $quiz['percentage'];
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <p class="no-grades">No completed quizzes for this course</p>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="dropped-course-notice">
                            <p><i class="fa fa-info-circle"></i> This course has been dropped. No further progress will be tracked.</p>
                            <p class="dropped-date">Dropped on: <?php echo date('d/m/Y', strtotime($course_data['dropped_date'])); ?></p>
                            <?php if (!empty($course_data['dropped_reason'])): ?>
                                <p class="dropped-reason">Reason: <?php echo htmlspecialchars($course_data['dropped_reason']); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="text-center">No grades available yet. Complete assignments and quizzes to see your grades here.</p>
    <?php endif; ?>
</div>
<?php
// First, check if the student is enrolled in any courses
$enrollment_check = $conn->prepare("
    SELECT COUNT(*) as course_count 
    FROM Enrollments 
    WHERE student_id = ? AND status = 'Enrolled'
");
$enrollment_check->bind_param("i", $student_id);
$enrollment_check->execute();
$enrollment_result = $enrollment_check->get_result();
$enrollment_data = $enrollment_result->fetch_assoc();
$is_enrolled = ($enrollment_data['course_count'] > 0);

// If not enrolled, set a feedback error message
if (!$is_enrolled) {
    $_SESSION['feedback_error'] = "Please enroll in a course to receive personalized feedback.";
    // Skip the rest of the feedback generation logic
} else {
    // Only run this code if the student is enrolled in at least one course
    
    // Calculate total score and possible total
    $total_score = 0;
    $total_possible = 0;

    // Add up assignment scores
    $assign_stmt = $conn->prepare("
        SELECT a.title, a.topic, s.grade, s.assignment_id
        FROM Submissions s
        JOIN Assignments a ON s.assignment_id = a.assignment_id
        WHERE s.student_id = ? AND s.grade IS NOT NULL
    ");
    $assign_stmt->bind_param("i", $student_id);
    $assign_stmt->execute();
    $assignments_result = $assign_stmt->get_result();

    $strong_areas = [];
    $weak_areas = [];

    while ($assignment = $assignments_result->fetch_assoc()) {
        $total_score += $assignment['grade'];
        $total_possible += 100; // Assuming assignments are out of 100
        
        // Track strong and weak areas
        if ($assignment['grade'] >= 70) {
            if (!empty($assignment['topic'])) {
                $strong_areas[] = $assignment['topic'];
            }
        } else {
            if (!empty($assignment['topic'])) {
                $weak_areas[] = $assignment['topic'];
            }
        }
    }

    // Add up quiz scores
    $quiz_stmt = $conn->prepare("
        SELECT q.title, q.topic, sq.score, sq.total_questions, sq.quiz_id
        FROM StudentQuizzes sq
        JOIN Quizzes q ON sq.quiz_id = q.quiz_id
        WHERE sq.student_id = ? AND sq.is_completed = 1
    ");
    $quiz_stmt->bind_param("i", $student_id);
    $quiz_stmt->execute();
    $quizzes_result = $quiz_stmt->get_result();

    while ($quiz = $quizzes_result->fetch_assoc()) {
        $quiz_score = ($quiz['total_questions'] > 0) ? 
            ($quiz['score'] / $quiz['total_questions']) * 100 : 0;
        
        $total_score += $quiz_score;
        $total_possible += 100; // Normalizing to 100
        
        // Track strong and weak areas
        if ($quiz_score >= 70) {
            if (!empty($quiz['topic'])) {
                $strong_areas[] = $quiz['topic'];
            }
        } else {
            if (!empty($quiz['topic'])) {
                $weak_areas[] = $quiz['topic'];
            }
        }
    }

    // Calculate overall percentage
    $overall_percentage = ($total_possible > 0) ? round(($total_score / $total_possible) * 100) : 0;

    // Determine grade letter
    $grade_letter = '';
    if ($overall_percentage >= 90) {
        $grade_letter = 'A';
    } elseif ($overall_percentage >= 80) {
        $grade_letter = 'B';
    } elseif ($overall_percentage >= 70) {
        $grade_letter = 'C';
    } elseif ($overall_percentage >= 60) {
        $grade_letter = 'D';
    } else {
        $grade_letter = 'F';
    }

    // Check if we need to regenerate feedback
    $regenerate = isset($_GET['regenerate']) && $_GET['regenerate'] == 1;

    // Check if we have a recent feedback in the database
    $ai_feedback = '';
    $topics_covered = '';
    $resources_recommended = '';
    if (!$regenerate) {
        $feedback_stmt = $conn->prepare("
            SELECT 
                ai_feedback, 
                date_feedback, 
                topics_covered, 
                resources_recommended,
                course_id
            FROM StudentFeedback 
            WHERE student_id = ? 
            ORDER BY date_feedback DESC 
            LIMIT 1
        ");
        $feedback_stmt->bind_param("i", $student_id);
        $feedback_stmt->execute();
        $feedback_result = $feedback_stmt->get_result();
        
        if ($feedback_result->num_rows > 0) {
            $feedback_row = $feedback_result->fetch_assoc();
            $ai_feedback = $feedback_row['ai_feedback'];
            $feedback_date = date('M d, Y', strtotime($feedback_row['date_feedback']));
            $topics_covered = $feedback_row['topics_covered'];
            $resources_recommended = $feedback_row['resources_recommended'];
            $course_id = $feedback_row['course_id'];
            
            // Get course title
            $course_title = "Overall Courses";
            $course_query = $conn->prepare("
                SELECT title FROM Courses WHERE course_id = ?
            ");
            $course_query->bind_param("i", $course_id);
            $course_query->execute();
            $course_result = $course_query->get_result();
            if ($course_result->num_rows > 0) {
                $course_row = $course_result->fetch_assoc();
                $course_title = $course_row['title'];
            }
        }
    }

    $strong_topics = [];
$weak_topics = [];
$topic_details = [];

// Get assignments with topics and performance data
$detailed_assign_stmt = $conn->prepare("
    SELECT a.title, a.topic, a.topic_id, s.grade, s.assignment_id,
           ct.topic_name
    FROM Submissions s
    JOIN Assignments a ON s.assignment_id = a.assignment_id
    LEFT JOIN CourseTopics ct ON a.topic_id = ct.topic_id
    WHERE s.student_id = ? AND s.grade IS NOT NULL
");
$detailed_assign_stmt->bind_param("i", $student_id);
$detailed_assign_stmt->execute();
$detailed_assignments = $detailed_assign_stmt->get_result();

while ($assignment = $detailed_assignments->fetch_assoc()) {
    // Get topic name - use CourseTopics name if available, otherwise fallback to topic field
    $topic_name = !empty($assignment['topic_name']) ? $assignment['topic_name'] : $assignment['topic'];
    
    // Skip if topic name is empty or just a number
    if (empty($topic_name) || (is_numeric($topic_name) && strlen($topic_name) < 3)) {
        $topic_name = "General Topic"; // Default name if topic is missing or just a number
    }
    
    // Create a key for this topic
    $topic_key = !empty($assignment['topic_id']) ? 'id_' . $assignment['topic_id'] : 'name_' . $topic_name;
    
    // Initialize topic in our tracking array if it doesn't exist
    if (!isset($topic_details[$topic_key])) {
        $topic_details[$topic_key] = [
            'name' => $topic_name,
            'topic_id' => $assignment['topic_id'],
            'assignments' => [],
            'quizzes' => [],
            'total_score' => 0,
            'count' => 0,
            'average' => 0
        ];
    }
    
    // Add this assignment to the topic
    $topic_details[$topic_key]['assignments'][] = [
        'title' => $assignment['title'],
        'score' => $assignment['grade']
    ];
    
    // Update the topic's running totals
    $topic_details[$topic_key]['total_score'] += $assignment['grade'];
    $topic_details[$topic_key]['count']++;
}

// Similarly for quizzes
$detailed_quiz_stmt = $conn->prepare("
    SELECT q.title, q.topic, q.topic_id, sq.score, sq.total_questions, sq.quiz_id,
           ct.topic_name
    FROM StudentQuizzes sq
    JOIN Quizzes q ON sq.quiz_id = q.quiz_id
    LEFT JOIN CourseTopics ct ON q.topic_id = ct.topic_id
    WHERE sq.student_id = ? AND sq.is_completed = 1
");
$detailed_quiz_stmt->bind_param("i", $student_id);
$detailed_quiz_stmt->execute();
$detailed_quizzes = $detailed_quiz_stmt->get_result();

while ($quiz = $detailed_quizzes->fetch_assoc()) {
    // Calculate quiz score as percentage
    $quiz_score = 0;
    if ($quiz['total_questions'] > 0) {
        // Check if score is stored as decimal or needs conversion
        if (is_numeric($quiz['score']) && $quiz['score'] <= 1.0) {
            // Score is already stored as decimal (0-1)
            $quiz_score = $quiz['score'] * 100;
        } else {
            // Score might be stored as raw points
            $quiz_score = ($quiz['score'] / $quiz['total_questions']) * 100;
        }
    }
    
    // Get topic name - use CourseTopics name if available, otherwise fallback to topic field
    $topic_name = !empty($quiz['topic_name']) ? $quiz['topic_name'] : $quiz['topic'];
    
    // Skip if topic name is empty or just a number
    if (empty($topic_name) || (is_numeric($topic_name) && strlen($topic_name) < 3)) {
        $topic_name = "Quiz Topic"; // Default name if topic is missing or just a number
    }
    
    // Create a key for this topic
    $topic_key = !empty($quiz['topic_id']) ? 'id_' . $quiz['topic_id'] : 'name_' . $topic_name;
    
    // Initialize topic in our tracking array if it doesn't exist
    if (!isset($topic_details[$topic_key])) {
        $topic_details[$topic_key] = [
            'name' => $topic_name,
            'topic_id' => $quiz['topic_id'],
            'assignments' => [],
            'quizzes' => [],
            'total_score' => 0,
            'count' => 0,
            'average' => 0
        ];
    }
    
    // Add this quiz to the topic
    $topic_details[$topic_key]['quizzes'][] = [
        'title' => $quiz['title'],
        'score' => round($quiz_score)
    ];
    
    // Update the topic's running totals
    $topic_details[$topic_key]['total_score'] += round($quiz_score);
    $topic_details[$topic_key]['count']++;
}

// Calculate averages for each topic and categorize as strong or weak
foreach ($topic_details as $key => &$topic) {
    if ($topic['count'] > 0) {
        $topic['average'] = round($topic['total_score'] / $topic['count']);
        
        // Categorize as strong (>=70%) or weak (<70%)
        if ($topic['average'] >= 70) {
            $strong_topics[$key] = $topic;
        } else {
            $weak_topics[$key] = $topic;
        }
    }
}
unset($topic); // Break the reference

// Get recommended resources for weak topics
$recommended_resources = [];

if (!empty($weak_topics)) {
    // Get the courses the student is enrolled in
    $enrolled_courses_stmt = $conn->prepare("
        SELECT course_id FROM Enrollments WHERE student_id = ? AND status = 'Enrolled'
    ");
    $enrolled_courses_stmt->bind_param("i", $student_id);
    $enrolled_courses_stmt->execute();
    $enrolled_courses_result = $enrolled_courses_stmt->get_result();
    
    $enrolled_course_ids = [];
    while ($course = $enrolled_courses_result->fetch_assoc()) {
        $enrolled_course_ids[] = $course['course_id'];
    }
    
    if (!empty($enrolled_course_ids)) {
        $query_parts = [];
        $params = [];
        $types = "";
        
        // Add all enrolled course IDs to the parameters
        foreach ($enrolled_course_ids as $course_id) {
            $types .= "i";
            $params[] = $course_id;
        }
        
        $course_placeholders = implode(',', array_fill(0, count($enrolled_course_ids), '?'));
        
        // Base query to find materials from enrolled courses
        $base_query = "
            SELECT cm.material_id, cm.title, cm.type, cm.file_path, cm.topic_id, cm.topic,
                   c.title as course_title, c.course_id, ct.topic_name
            FROM CourseMaterials cm
            JOIN Courses c ON cm.course_id = c.course_id
            LEFT JOIN CourseTopics ct ON cm.topic_id = ct.topic_id
            WHERE cm.course_id IN ($course_placeholders)
        ";
        
        // Add topic_id conditions for weak topics that have IDs
        $topic_id_conditions = [];
        foreach ($weak_topics as $topic) {
            if (!empty($topic['topic_id'])) {
                $topic_id_conditions[] = "cm.topic_id = ?";
                $types .= "i";
                $params[] = $topic['topic_id'];
            }
        }
        
        if (!empty($topic_id_conditions)) {
            $query_parts[] = "(" . implode(" OR ", $topic_id_conditions) . ")";
        }
        
        // Add topic name conditions for weak topics without IDs
        $topic_name_conditions = [];
        foreach ($weak_topics as $topic) {
            if (!empty($topic['name']) && $topic['name'] != 'General Topic' && $topic['name'] != 'Quiz Topic') {
                $topic_name_conditions[] = "cm.topic LIKE ? OR ct.topic_name LIKE ?";
                $types .= "ss";
                $params[] = "%" . $topic['name'] . "%";
                $params[] = "%" . $topic['name'] . "%";
            }
        }
        
        if (!empty($topic_name_conditions)) {
            $query_parts[] = "(" . implode(" OR ", $topic_name_conditions) . ")";
        }
        
        // Complete the query with any conditions
        $full_query = $base_query;
        if (!empty($query_parts)) {
            $full_query .= " AND (" . implode(" OR ", $query_parts) . ")";
        }
        
        // Add ordering and limit
        $full_query .= " ORDER BY cm.upload_date DESC LIMIT 20";
        
        $resource_query = $conn->prepare($full_query);
        
        if (!empty($params)) {
            $resource_query->bind_param($types, ...$params);
        }
        
        $resource_query->execute();
        $resource_result = $resource_query->get_result();
        
        while ($resource = $resource_result->fetch_assoc()) {
            // Get the topic name for display
            $display_topic = !empty($resource['topic_name']) ? $resource['topic_name'] : $resource['topic'];
            
            // Skip if topic name is empty or just a number
            if (empty($display_topic) || (is_numeric($display_topic) && strlen($display_topic) < 3)) {
                $display_topic = "Study Material"; // Default name if topic is missing or just a number
            }
            
            $recommended_resources[] = [
                'material_id' => $resource['material_id'],
                'title' => $resource['title'],
                'type' => $resource['type'],
                'file_path' => $resource['file_path'],
                'course_title' => $resource['course_title'],
                'course_id' => $resource['course_id'],
                'topic' => $display_topic,
                'topic_id' => $resource['topic_id']
            ];
        }
        
        // If no resources found with specific topic matches, get general course materials
        if (empty($recommended_resources)) {
            $general_query = "
                SELECT cm.material_id, cm.title, cm.type, cm.file_path, cm.topic_id, cm.topic,
                       c.title as course_title, c.course_id, ct.topic_name
                FROM CourseMaterials cm
                JOIN Courses c ON cm.course_id = c.course_id
                LEFT JOIN CourseTopics ct ON cm.topic_id = ct.topic_id
                WHERE cm.course_id IN ($course_placeholders)
                ORDER BY cm.upload_date DESC LIMIT 10
            ";
            
            $general_resource_query = $conn->prepare($general_query);
            $general_types = str_repeat("i", count($enrolled_course_ids));
            $general_resource_query->bind_param($general_types, ...$enrolled_course_ids);
            $general_resource_query->execute();
            $general_result = $general_resource_query->get_result();
            
            while ($resource = $general_result->fetch_assoc()) {
                // Get the topic name for display
                $display_topic = !empty($resource['topic_name']) ? $resource['topic_name'] : $resource['topic'];
                
                // Skip if topic name is empty or just a number
                if (empty($display_topic) || (is_numeric($display_topic) && strlen($display_topic) < 3)) {
                    $display_topic = "General Course Material"; // Default name if topic is missing or just a number
                }
                
                $recommended_resources[] = [
                    'material_id' => $resource['material_id'],
                    'title' => $resource['title'],
                    'type' => $resource['type'],
                    'file_path' => $resource['file_path'],
                    'course_title' => $resource['course_title'],
                    'course_id' => $resource['course_id'],
                    'topic' => $display_topic,
                    'topic_id' => $resource['topic_id']
                ];
            }
        }
    }
}
}
?>

<div id="feedback" class="dashboard-box tab-content" style="display:none;">
    <?php if (isset($_SESSION['feedback_error'])): ?>
        <div class="alert alert-warning">
            <?php echo $_SESSION['feedback_error']; unset($_SESSION['feedback_error']); ?>
        </div>
    <?php elseif ($is_enrolled): ?>
        <h3 class="text-center">AI Academic Feedback</h3>
        
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Your Personalized Feedback</h4>
                    <small>Generated on: <?php echo isset($feedback_date) ? $feedback_date : date('M d, Y'); ?></small>
                </div>
            </div>
            
            <div class="card-body">
                <div class="overall-score mb-4 text-center">
                    <div class="progress" style="height: 25px;">
                    </div>
                </div>
                
                <div class="feedback-message">
                    <div class="card border-light shadow-sm mb-4">
                        <div class="card-body">
                            <blockquote class="blockquote">
                                <?php 
                                // Display the AI feedback with paragraphs
                                // First, clean up the feedback text again just to be sure
                                $ai_feedback = preg_replace('/Encouragement:\s*/i', '', $ai_feedback);
                                $ai_feedback = preg_replace('/Constructive Feedback:\s*/i', '', $ai_feedback);
                                $ai_feedback = preg_replace('/Feedback:\s*/i', '', $ai_feedback);
                                
                                // Split into paragraphs
                                $paragraphs = explode("\n\n", $ai_feedback);
                                foreach ($paragraphs as $paragraph) {
                                    if (!empty(trim($paragraph))) {
                                        // Add appropriate styling to make it more engaging
                                        echo '<p class="mb-3 lead">' . htmlspecialchars($paragraph) . '</p>';
                                    }
                                }
                                ?>
                                <footer class="blockquote-footer text-right">
                                    <i class="fas fa-robot mr-2"></i>AI Feedback System
                                </footer>
                            </blockquote>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row mb-4">
        <div class="col-lg-6 mb-3 mb-lg-0">
    <div class="card h-100">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="fas fa-thumbs-up mr-2"></i> Strong Areas</h5>
        </div>
        <div class="card-body">
            <?php if (!empty($strong_topics)): ?>
                <ul class="list-group">
                    <?php foreach($strong_topics as $key => $topic): ?>
                        <li class="list-group-item">
                            <div class="d-flex justify-content-between align-items-center">
                                <span><strong><?php echo htmlspecialchars($topic['name']); ?></strong></span>
                                <span class="badge badge-success badge-pill"><?php echo $topic['average']; ?>%</span>
                            </div>
                            <div class="mt-2 small">
                                <strong>Items:</strong>
                                <?php if (!empty($topic['assignments']) || !empty($topic['quizzes'])): ?>
                                    <ul class="list-unstyled ml-2">
                                        <?php 
                                        // Show up to 3 assignments
                                        $items_shown = 0;
                                        foreach ($topic['assignments'] as $assignment) {
                                            if ($items_shown < 3) {
                                                echo '<li><i class="fas fa-file-alt mr-1"></i> ' . 
                                                     htmlspecialchars($assignment['title']) . ' - ' . 
                                                     $assignment['score'] . '%</li>';
                                                $items_shown++;
                                            }
                                        }
                                        
                                        // Show up to 3 quizzes
                                        foreach ($topic['quizzes'] as $quiz) {
                                            if ($items_shown < 3) {
                                                echo '<li><i class="fas fa-question-circle mr-1"></i> ' . 
                                                     htmlspecialchars($quiz['title']) . ' - ' . 
                                                     $quiz['score'] . '%</li>';
                                                $items_shown++;
                                            }
                                        }
                                        
                                        // If there are more items than we showed
                                        $total_items = count($topic['assignments']) + count($topic['quizzes']);
                                        if ($total_items > 3) {
                                            echo '<li class="text-muted">+' . ($total_items - 3) . ' more items</li>';
                                        }
                                        ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted ml-2 mb-0">No specific items identified.</p>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <div class="text-center py-3">
                    <i class="fas fa-award fa-3x text-muted mb-3"></i>
                    <p class="text-muted mb-0">No strong areas identified yet. Keep working on your assignments and quizzes!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Areas for Improvement Section -->
<div class="col-lg-6">
    <div class="card h-100">
        <div class="card-header bg-warning text-dark">
            <h5 class="mb-0"><i class="fas fa-exclamation-circle mr-2"></i> Areas for Improvement</h5>
        </div>
        <div class="card-body">
            <?php if (!empty($weak_topics)): ?>
                <ul class="list-group">
                    <?php foreach($weak_topics as $key => $topic): ?>
                        <li class="list-group-item">
                            <div class="d-flex justify-content-between align-items-center">
                                <span><strong><?php echo htmlspecialchars($topic['name']); ?></strong></span>
                                <span class="badge badge-warning badge-pill"><?php echo $topic['average']; ?>%</span>
                            </div>
                            <div class="mt-2 small">
                                <strong>Items:</strong>
                                <?php if (!empty($topic['assignments']) || !empty($topic['quizzes'])): ?>
                                    <ul class="list-unstyled ml-2">
                                        <?php 
                                        // Show up to 3 assignments
                                        $items_shown = 0;
                                        foreach ($topic['assignments'] as $assignment) {
                                            if ($items_shown < 3) {
                                                echo '<li><i class="fas fa-file-alt mr-1"></i> ' . 
                                                     htmlspecialchars($assignment['title']) . ' - ' . 
                                                     $assignment['score'] . '%</li>';
                                                $items_shown++;
                                            }
                                        }
                                        
                                        // Show up to 3 quizzes
                                        foreach ($topic['quizzes'] as $quiz) {
                                            if ($items_shown < 3) {
                                                echo '<li><i class="fas fa-question-circle mr-1"></i> ' . 
                                                     htmlspecialchars($quiz['title']) . ' - ' . 
                                                     $quiz['score'] . '%</li>';
                                                $items_shown++;
                                            }
                                        }
                                        
                                        // If there are more items than we showed
                                        $total_items = count($topic['assignments']) + count($topic['quizzes']);
                                        if ($total_items > 3) {
                                            echo '<li class="text-muted">+' . ($total_items - 3) . ' more items</li>';
                                        }
                                        ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted ml-2 mb-0">No specific items identified.</p>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <div class="text-center py-3">
                    <i class="fas fa-certificate fa-3x text-muted mb-3"></i>
                    <p class="text-muted mb-0">No weak areas identified. Great job!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Recommended Resources Section -->
<?php if (!empty($recommended_resources)): ?>
<div class="card mt-4">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0"><i class="fas fa-book mr-2"></i> Recommended Resources for Improvement</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="thead-light">
                    <tr>
                        <th style="width: 30%;"><i class="fas fa-file-alt mr-1"></i> Resource</th>
                        <th style="width: 25%;"><i class="fas fa-graduation-cap mr-1"></i> Course</th>
                        <th style="width: 25%;"><i class="fas fa-tag mr-1"></i> Related Topic</th>
                        <th style="width: 10%;"><i class="fas fa-file mr-1"></i> Type</th>
                        <th style="width: 10%;" class="text-center"><i class="fas fa-link mr-1"></i> Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recommended_resources as $resource): ?>
                    <tr>
                        <td class="align-middle font-weight-medium">
                            <?php echo htmlspecialchars($resource['title']); ?>
                        </td>
                        <td class="align-middle">
                            <?php echo htmlspecialchars($resource['course_title']); ?>
                        </td>
                        <td class="align-middle">
                            <?php echo htmlspecialchars($resource['topic']); ?>
                        </td>
                        <td class="align-middle">
                            <?php 
                            $icon_class = 'fa-file-alt';
                            $type_display = $resource['type'];
                            
                            switch (strtolower($resource['type'])) {
                                case 'pdf': 
                                    $icon_class = 'fa-file-pdf'; 
                                    $type_display = 'PDF';
                                    break;
                                case 'video': 
                                    $icon_class = 'fa-file-video';
                                    $type_display = 'Video';
                                    break;
                                case 'presentation': 
                                    $icon_class = 'fa-file-powerpoint';
                                    $type_display = 'PPT';
                                    break;
                                case 'document': 
                                    $icon_class = 'fa-file-word';
                                    $type_display = 'Doc';
                                    break;
                                case 'spreadsheet': 
                                    $icon_class = 'fa-file-excel';
                                    $type_display = 'Excel';
                                    break;
                                case 'audio': 
                                    $icon_class = 'fa-file-audio';
                                    $type_display = 'Audio';
                                    break;
                            }
                            ?>
                            <i class="fas <?php echo $icon_class; ?>" title="<?php echo htmlspecialchars($type_display); ?>"></i> 
                            <?php echo htmlspecialchars($type_display); ?>
                        </td>
                        <td class="text-center">
                        
<a href="download-material.php?id=<?php echo $resource['material_id']; ?>" class="btn btn-sm btn-primary">
    <i class="fas fa-download mr-1"></i> Download
</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="mt-3 text-center">
            <p class="text-muted"><i class="fas fa-info-circle mr-1"></i> These resources are specifically recommended to help you improve in the areas that need attention.</p>
        </div>
    </div>
</div>
<?php elseif (!empty($weak_topics)): ?>
<div class="card mt-4">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0"><i class="fas fa-book mr-2"></i> Recommended Resources</h5>
    </div>
    <div class="card-body text-center">
        <i class="fas fa-search fa-3x text-muted mb-3"></i>
        <p class="mb-0">No specific resources found for your weak areas. Please contact your instructor for additional study materials.</p>
    </div>
</div>
    <</div>
<?php endif; ?>
    </div>
<?php endif; ?>
        </div>
    </section>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        // Function to set which tab should be active
        function setActiveTab(tabName) {
            localStorage.setItem('activeTab', tabName);
        }
        
        function showTab(event, tabId) {
            event.preventDefault();
            let tabs = document.querySelectorAll('.tab-content');
            let links = document.querySelectorAll('.tab-link');
            tabs.forEach(tab => tab.style.display = 'none');
            links.forEach(link => link.classList.remove('active'));
            document.getElementById(tabId).style.display = 'block';
            
            // Find the correct link and add the active class
            const activeLink = document.querySelector(`.tab-link[href="#${tabId}"]`);
            if (activeLink) {
                activeLink.classList.add('active');
            } else {
                event.target.classList.add('active');
            }
            
            // Store the active tab in localStorage
            localStorage.setItem('activeTab', tabId);
        }
        
        function toggleCourseGrades(courseId) {
            const content = document.getElementById('course-grades-content-' + courseId);
            const icon = document.getElementById('course-grades-icon-' + courseId);
            
            if (content.style.display === 'block') {
                content.style.display = 'none';
                icon.className = 'fa fa-chevron-right';
            } else {
                content.style.display = 'block';
                icon.className = 'fa fa-chevron-down';
            }
        }
        
        // When the page loads, check if there's a stored active tab or URL hash
        document.addEventListener('DOMContentLoaded', function() {
            const hash = window.location.hash.substring(1);
            const storedTab = localStorage.getItem('activeTab');
            
            // Priority: URL hash > stored tab > default (overview)
            const tabToShow = hash || storedTab || 'overview';
            
            // Find the tab link and trigger a click to show the tab
            const tabLink = document.querySelector('.tab-link[href="#' + tabToShow + '"]');
            if (tabLink) {
                // Create a synthetic event
                const event = {
                    preventDefault: function() {},
                    target: tabLink
                };
                
                // Call the showTab function
                showTab(event, tabToShow);
            }
        });
    </script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Chart.js
    const chartCanvas = document.getElementById('progressChart');
    if (chartCanvas) {
        const ctx = chartCanvas.getContext('2d');
        
        // Get progress data from PHP with a fallback to empty data
        let progressData;
        try {
            progressData = <?php echo !empty($chart_data_json) ? $chart_data_json : '{"labels":[],"datasets":[]}'; ?>;
            console.log("Chart data:", progressData); // Debug: Check data in console
        } catch (e) {
            console.error("Error parsing chart data:", e);
            progressData = {"labels":[],"datasets":[]};
        }
        
        // Check if there's any actual data in the datasets
        const hasData = progressData.datasets && 
                         progressData.datasets.length > 0 && 
                         progressData.datasets.some(ds => ds.data && ds.data.length > 0);
        
        if (!hasData) {
            // No data available - display a message
            chartCanvas.style.display = 'none';
            const noDataMessage = document.createElement('p');
            noDataMessage.textContent = 'No performance data available yet. Complete more assignments and quizzes to see your progress.';
            noDataMessage.className = 'text-center text-muted mt-4';
            chartCanvas.parentNode.appendChild(noDataMessage);
            return; // Exit early
        }
        
        // Store original data for toggling between views
        const cumulativeData = JSON.parse(JSON.stringify(progressData));
        
        // Generate colors for each course
        progressData.datasets.forEach((dataset, index) => {
            // Special color for overall performance
            if (dataset.label === 'Overall Performance') {
                dataset.borderColor = 'rgba(0, 0, 0, 0.7)';
                dataset.backgroundColor = 'rgba(0, 0, 0, 0.7)';
            } else {
                // Generate unique color based on index
                const hue = (index * 137.5) % 360;
                dataset.borderColor = `hsl(${hue}, 70%, 50%)`;
                dataset.backgroundColor = `hsla(${hue}, 70%, 50%, 0.1)`;
            }
        });
        
        // Create chart
        const progressChart = new Chart(ctx, {
            type: 'line',
            data: progressData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Score (%)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + context.parsed.y + '%';
                            }
                        }
                    },
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    }
                }
            }
        });
        
        // NOTE: For simplicity, we're removing the individual grades toggle for now
        // to make sure the basic chart works first. Once the main chart is working,
        // you can add back the toggle functionality.
        
        // To make the toggle buttons match our simplified implementation:
        document.getElementById('view-cumulative').addEventListener('click', function() {
            this.classList.add('active');
            const individualBtn = document.getElementById('view-individual');
            if (individualBtn) individualBtn.classList.remove('active');
            // Later you can add back the full toggle functionality
        });
        
        if (document.getElementById('view-individual')) {
            document.getElementById('view-individual').addEventListener('click', function() {
                this.classList.add('active');
                document.getElementById('view-cumulative').classList.remove('active');
                // Show a message that this feature is coming soon
                alert('Individual grades view will be available in a future update.');
                // Reset to cumulative view
                setTimeout(() => {
                    document.getElementById('view-cumulative').click();
                }, 100);
            });
        }
    }
});

</script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</body>
</html>