<?php 
session_start(); 

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();

include 'db_connection.php';  

// Check if user is logged in and has the right role 
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {     
    header("Location: login.php");     
    exit(); 
}  

// Get instructor ID 
$instructor_id = $_SESSION['user_id'];  

// Check if form is submitted 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {     
    // Collect form data     
    $course_id = $_POST['course_id'];     
    $title = $_POST['title'];     
    $description = $_POST['description'] ?? null;     
    $due_date = $_POST['due_date'];     
    $topic = $_POST['topic'] ?? null;     
    $grading_criteria = $_POST['grading_criteria'] ?? null;     
    $is_active = isset($_POST['is_active']) ? 1 : 0;          
    
    // Validate required fields     
    if (empty($course_id) || empty($title) || empty($due_date)) {         
        $_SESSION['error_message'] = "Course ID, assignment title, and due date are required.";         
        header("Location: instructor-dashboard.php");         
        exit();     
    }          
    
    try {
        // NEW CODE: Process and validate topic
        $topic_id = null;
        
        // If topic is empty or just a number, find a real topic
        if (empty($topic) || preg_match('/^[0-9]+$/', $topic)) {
            // Try to find a topic for this course
            $topic_stmt = $conn->prepare("
    SELECT topic_id, topic_name 
    FROM CourseTopics 
    WHERE course_id = ? 
    ORDER BY topic_id 
    LIMIT 1
");
            
            $topic_stmt->bind_param("i", $course_id);
            $topic_stmt->execute();
            $topic_result = $topic_stmt->get_result();
            
            if ($topic_result->num_rows > 0) {
                // Use an existing topic from the course
                $topic_row = $topic_result->fetch_assoc();
                $topic_id = $topic_row['topic_id'];
                $topic = $topic_row['topic_name'];
            } else {
                // No topics found for course, create a new one
                $new_topic = "Topic for: " . $title;
                $create_topic = $conn->prepare("
    INSERT INTO CourseTopics (course_id, topic_name)
    VALUES (?, ?)
");
                $create_topic->bind_param("is", $course_id, $new_topic);
                
                if ($create_topic->execute()) {
                    $topic_id = $conn->insert_id;
                    $topic = $new_topic;
                }
            }
        } else {
            // Check if entered topic matches existing one
            $topic_stmt = $conn->prepare("
                SELECT topic_id 
                FROM CourseTopics 
                WHERE course_id = ? AND topic_name = ?
            ");
            
            $topic_stmt->bind_param("is", $course_id, $topic);
            $topic_stmt->execute();
            $topic_result = $topic_stmt->get_result();
            
            if ($topic_result->num_rows > 0) {
                // Topic exists, use its ID
                $topic_row = $topic_result->fetch_assoc();
                $topic_id = $topic_row['topic_id'];
            } else {
                // Topic doesn't exist, create it
                $create_topic = $conn->prepare("
    INSERT INTO CourseTopics (course_id, topic_name)
    VALUES (?, ?)
");
                
                $create_topic->bind_param("isi", $course_id, $topic, $course_id);
                if ($create_topic->execute()) {
                    $topic_id = $conn->insert_id;
                }
            }
        }
        // END NEW CODE   
         
        // Modified: Insert assignment into database with topic_id     
        $stmt = $conn->prepare("             
            INSERT INTO Assignments (                 
                course_id, title, description, due_date,                  
                topic, topic_id, grading_criteria, is_active             
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)         
        ");                  
        
        $stmt->bind_param(             
            "issssisi",              
            $course_id, $title, $description, $due_date,             
            $topic, $topic_id, $grading_criteria, $is_active         
        );                  
        
        if ($stmt->execute()) {
            $assignment_id = $conn->insert_id;
            $_SESSION['success_message'] = "Assignment created successfully!";
            
            // Check if due date is within 3 days - if so, trigger immediate email notification
            $current_date = date('Y-m-d');
            $three_days_from_now = date('Y-m-d', strtotime('+3 days'));
            
            if ($due_date <= $three_days_from_now && $due_date >= $current_date && $is_active) {
                // Include email system and trigger immediate notification
                require_once 'email_system.php';
                $emailSystem = new EmailNotificationSystem($conn);
                
                // Trigger the deadline reminder function
                $sent = $emailSystem->sendDeadlineReminders();
                
                if ($sent > 0) {
                    $_SESSION['success_message'] .= " Deadline reminders were sent to enrolled students.";
                    
                    // Log this action
                    $log_dir = __DIR__ . '/logs/system/';
                    if (!is_dir($log_dir)) {
                        mkdir($log_dir, 0755, true);
                    }
                    
                    $log_file = $log_dir . date('Y-m-d') . '_assignment_creation.txt';
                    $log_content = date('Y-m-d H:i:s') . " | Assignment ID: {$assignment_id} | " .
                                   "Title: {$title} | Due: {$due_date} | Reminders sent: {$sent}\n";
                    file_put_contents($log_file, $log_content, FILE_APPEND);
                }
            }
        } else {             
            $_SESSION['error_message'] = "Error creating assignment: " . $conn->error;         
        }     
    } catch (Exception $e) {         
        $_SESSION['error_message'] = "Database error: " . $e->getMessage();     
    }          
    
    // Redirect back to instructor dashboard     
    header("Location: instructor-dashboard.php");     
    exit(); 
}  

// If someone tries to access this file directly without submitting the form 
header("Location: instructor-dashboard.php"); 
exit(); 
?>