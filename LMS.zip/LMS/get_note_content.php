<?php
session_start();

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {
    echo "Unauthorized access";
    exit();
}

include 'db_connection.php';

// Get material ID
if (!isset($_GET['material_id']) || empty($_GET['material_id'])) {
    echo "No material ID provided";
    exit();
}

$material_id = $_GET['material_id'];
$instructor_id = $_SESSION['user_id'];

// Get material info
$stmt = $conn->prepare("
    SELECT m.file_path, c.instructor_id 
    FROM CourseMaterials m
    JOIN Courses c ON m.course_id = c.course_id
    WHERE m.material_id = ? AND m.type = 'note'
");
$stmt->bind_param("i", $material_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $material = $result->fetch_assoc();
    
    // Check if instructor owns this course
    if ($material['instructor_id'] == $instructor_id) {
        // Read and return file content
        if (file_exists($material['file_path'])) {
            echo file_get_contents($material['file_path']);
        } else {
            echo "File not found";
        }
    } else {
        echo "Unauthorized access";
    }
} else {
    echo "Material not found";
}

$conn->close();
?>