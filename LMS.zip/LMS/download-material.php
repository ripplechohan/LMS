<?php
session_start();

// Include database connection
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if material ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "No material specified";
    header("Location: student-dashboard.php");
    exit();
}

$material_id = $_GET['id'];
$student_id = $_SESSION['user_id'];

// Verify the student has access to this material (enrolled in the course)
$stmt = $conn->prepare("
    SELECT cm.file_path, cm.title, cm.type 
    FROM CourseMaterials cm
    JOIN Courses c ON cm.course_id = c.course_id
    JOIN Enrollments e ON c.course_id = e.course_id
    WHERE cm.material_id = ? AND e.student_id = ? AND e.status IN ('Enrolled', 'Completed')
");

$stmt->bind_param("ii", $material_id, $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error_message'] = "You don't have access to this material";
    header("Location: student-dashboard.php");
    exit();
}

// Get the file details
$material = $result->fetch_assoc();
$file_path = $material['file_path'];
$file_name = basename($file_path);
$file_title = $material['title'];
$file_type = $material['type'];

// Make sure the file exists
if (!file_exists($file_path)) {
    $_SESSION['error_message'] = "File not found";
    header("Location: student-dashboard.php");
    exit();
}

// Set appropriate headers for download
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $file_name . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($file_path));

// Clear output buffer
ob_clean();
flush();

// Read the file and output it to the browser
readfile($file_path);
exit();
?>