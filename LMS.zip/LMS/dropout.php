<?php
session_start();
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Student') {
    header("Location: login.php");
    exit();
}

// Get course ID from URL parameter
$course_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$student_id = $_SESSION['user_id'];

// Validate the course ID
if ($course_id <= 0) {
    header("Location: courses.php?error=invalid_course");
    exit();
}

// Check if the student is already enrolled in this course
$stmt = $conn->prepare("
    SELECT enrollment_id FROM Enrollments 
    WHERE student_id = ? AND course_id = ?
");
$stmt->bind_param("ii", $student_id, $course_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Student is enrolled, update status to Dropped
    $enrollment = $result->fetch_assoc();
    $enrollment_id = $enrollment['enrollment_id'];
    
    $update_stmt = $conn->prepare("
        UPDATE Enrollments 
        SET status = 'Dropped' 
        WHERE enrollment_id = ?
    ");
    $update_stmt->bind_param("i", $enrollment_id);
    
    if ($update_stmt->execute()) {
        // Success
        header("Location: courses.php?dropout=success");
        exit();
    } else {
        // Error
        header("Location: courses.php?dropout=error");
        exit();
    }
} else {
    // Student is not enrolled in this course
    header("Location: courses.php?dropout=not_enrolled");
    exit();
}
?>