<?php
// email_system.php - Using PHPMailer to send actual emails from localhost
// Core file for email notification system

require_once 'db_connection.php';


require_once __DIR__ . '/PHPMailer-6.9.3/src/Exception.php';
require_once __DIR__ . '/PHPMailer-6.9.3/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-6.9.3/src/SMTP.php';

// PHPMailer dependencies
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer autoloader
  // Assumes you've installed PHPMailer via Composer

class EmailNotificationSystem {
    private $conn;
    private $admin_email = 'lms2413g6@gmail.com';
    private $admin_name = 'LMS Admin';
    
    // SMTP Configuration - Update these with your email provider settings
    private $smtp_host = 'smtp.gmail.com';
private $smtp_username = 'lms2413g6@gmail.com';
private $smtp_password = 'svzs tkgp wirm zupc';
 // Generate an app password in your Google account
private $smtp_port = 587;
private $smtp_secure = 'tls';
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    /**
     * Send email notification to a user using PHPMailer
     * 
     * @param string $to_email - Recipient email
     * @param string $subject - Email subject
     * @param string $message - Email body in HTML format
     * @param int $user_id - User ID to log the notification for
     * @param string $type - Type of notification (Grade Update, Deadline Reminder, Course Update)
     * @return bool - Success or failure
     */
    public function sendEmail($to_email, $subject, $message, $user_id, $type) {
        // Create a new PHPMailer instance
        $mail = new PHPMailer(true);
        $error_message = null;
        
        try {
            // Server settings
            // $mail->SMTPDebug = SMTP::DEBUG_SERVER; // Uncomment for debugging
            $mail->isSMTP();
            $mail->Host = $this->smtp_host;
            $mail->SMTPAuth = true;
            $mail->Username = $this->smtp_username;
            $mail->Password = $this->smtp_password;
            $mail->SMTPSecure = $this->smtp_secure;
            $mail->Port = $this->smtp_port;
            
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            // Recipients
            $mail->setFrom($this->admin_email, $this->admin_name);
            $mail->addAddress($to_email);
            $mail->addReplyTo($this->admin_email, $this->admin_name);
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $this->getEmailTemplate($subject, $message);
            $mail->AltBody = strip_tags(str_replace('<br>', "\n", $message)); // Plain text alternative
            
            // Send the email
            $mail_sent = $mail->send();
            $status = 'Sent';
            
        } // In your sendEmail function, modify the catch block:
            catch (Exception $e) {
                $mail_sent = false;
                $status = 'Failed';
                $error_message = $mail->ErrorInfo;
                
                // Add detailed error logging
                $error_log = __DIR__ . '/logs/smtp_errors.txt';
                $error_content = date('Y-m-d H:i:s') . " | Error: " . $e->getMessage() . 
                                 " | Debug: " . print_r($mail, true) . "\n";
                file_put_contents($error_log, $error_content, FILE_APPEND);
            }
        
        // Log notification in database
       // Inside your sendEmail method, add this after sending the email:
if ($mail_sent) {
    // Log to file system
    $log_dir = __DIR__ . '/logs/emails/';
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    
    $log_file = $log_dir . date('Y-m-d') . '_email_log.txt';
    $log_content = date('Y-m-d H:i:s') . " | To: {$to_email} | Subject: {$subject} | Status: Sent\n";
    file_put_contents($log_file, $log_content, FILE_APPEND);
} else {
    // Log failed email
    $log_dir = __DIR__ . '/logs/emails/';
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    
    $log_file = $log_dir . date('Y-m-d') . '_email_log.txt';
    $log_content = date('Y-m-d H:i:s') . " | To: {$to_email} | Subject: {$subject} | Status: Failed | Error: {$error_message}\n";
    file_put_contents($log_file, $log_content, FILE_APPEND);
}
    }
    
    /**
     * Email template with consistent branding
     */
    private function getEmailTemplate($subject, $message) {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>' . $subject . '</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #007bff; padding: 20px; color: white; text-align: center; }
                .content { padding: 20px; background-color: #f9f9f9; }
                .footer { padding: 10px; text-align: center; font-size: 12px; color: #777; }
                .button { display: inline-block; padding: 10px 20px; background-color: #007bff; color: white; 
                         text-decoration: none; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Learning Management System</h2>
                </div>
                <div class="content">
                    ' . $message . '
                </div>
                <div class="footer">
                    <p>This is an automated message from the Learning Management System.</p>
                    <p>Please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>';
    }
    
    /**
     * Send grade update notification to a student
     */
    public function sendGradeNotification($submission_id) {
        // Get submission details
        $stmt = $this->conn->prepare("
            SELECT s.*, a.title AS assignment_title, u.name AS student_name, u.email AS student_email, 
                   c.title AS course_title, u.user_id
            FROM Submissions s
            JOIN Assignments a ON s.assignment_id = a.assignment_id
            JOIN Users u ON s.student_id = u.user_id
            JOIN Courses c ON a.course_id = c.course_id
            WHERE s.submission_id = ?
        ");
        
        $stmt->bind_param("i", $submission_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $submission = $result->fetch_assoc();
        $stmt->close();
        
        // Build email content
        $subject = "Feedback Available - {$submission['assignment_title']}";
        
        $message = "
            <h3>Hello {$submission['student_name']},</h3>
            <p>Your submission for <strong>{$submission['assignment_title']}</strong> in the course 
               <strong>{$submission['course_title']}</strong> has been graded.</p>
            <p>Your grade: <strong>{$submission['grade']}</strong></p>
            
            <h4>Feedback:</h4>
            <p>{$submission['ai_feedback']}</p>
            
            <p>You can view more details by logging into your account and checking your submissions.</p>
            <p><a href='http://localhost/lms/login.php' class='button'>
               View Feedback</a></p>
        ";
        
        // Send the email
        return $this->sendEmail(
            $submission['student_email'],
            $subject,
            $message,
            $submission['user_id'],
            'Grade Update'
        );
    }
    
    /**
     * Send deadline reminders for assignments due in 3 days
     */
    public function sendDeadlineReminders() {
        // Find all assignments due in 3 days
        $stmt = $this->conn->prepare("
            SELECT a.assignment_id, a.title, a.due_date, a.course_id, c.title AS course_title
            FROM Assignments a
            JOIN Courses c ON a.course_id = c.course_id
            WHERE a.is_active = 1 
            AND a.due_date = DATE_ADD(CURDATE(), INTERVAL 3 DAY)
        ");
        
        $stmt->execute();
        $assignments = $stmt->get_result();
        $stmt->close();
        
        $total_sent = 0;
        
        while ($assignment = $assignments->fetch_assoc()) {
            // Get all students enrolled in this course
            $stmt = $this->conn->prepare("
                SELECT u.user_id, u.name, u.email
                FROM Enrollments e
                JOIN Users u ON e.student_id = u.user_id
                WHERE e.course_id = ? 
                AND e.status = 'Enrolled'
            ");
            
            $stmt->bind_param("i", $assignment['course_id']);
            $stmt->execute();
            $students = $stmt->get_result();
            $stmt->close();
            
            while ($student = $students->fetch_assoc()) {
                // Check if student has already submitted
                $stmt = $this->conn->prepare("
                    SELECT submission_id 
                    FROM Submissions 
                    WHERE student_id = ? AND assignment_id = ?
                ");
                
                $stmt->bind_param("ii", $student['user_id'], $assignment['assignment_id']);
                $stmt->execute();
                $submission = $stmt->get_result();
                $stmt->close();
                
                // Only send reminder if student hasn't submitted yet
                if ($submission->num_rows === 0) {
                    $subject = "Deadline Reminder: {$assignment['title']} due in 3 days";
                    
                    $message = "
                        <h3>Hello {$student['name']},</h3>
                        <p>This is a friendly reminder that your assignment <strong>{$assignment['title']}</strong> 
                           for the course <strong>{$assignment['course_title']}</strong> 
                           is due in 3 days on <strong>{$assignment['due_date']}</strong>.</p>
                        
                        <p>Please make sure to submit your work before the deadline.</p>
                        
                        <p><a href='http://localhost/lms/submit_assignment.php?id={$assignment['assignment_id']}' 
                              class='button'>Submit Assignment</a></p>
                    ";
                    
                    // Send the email
                    $email_sent = $this->sendEmail(
                        $student['email'],
                        $subject,
                        $message,
                        $student['user_id'],
                        'Deadline Reminder'
                    );
                    
                    if ($email_sent) {
                        $total_sent++;
                    }
                }
            }
        }
        
        return $total_sent;
    }
    
    /**
     * Send quiz deadline reminders
     */
    public function sendQuizReminders() {
        // Find active quizzes assigned to courses
        $stmt = $this->conn->prepare("
            SELECT q.quiz_id, q.title, q.course_id, c.title AS course_title
            FROM Quizzes q
            JOIN Courses c ON q.course_id = c.course_id
            WHERE q.is_published = 1
        ");
        
        $stmt->execute();
        $quizzes = $stmt->get_result();
        $stmt->close();
        
        $total_sent = 0;
        
        while ($quiz = $quizzes->fetch_assoc()) {
            // Get all students enrolled in this course
            $stmt = $this->conn->prepare("
                SELECT u.user_id, u.name, u.email
                FROM Enrollments e
                JOIN Users u ON e.student_id = u.user_id
                WHERE e.course_id = ? 
                AND e.status = 'Enrolled'
            ");
            
            $stmt->bind_param("i", $quiz['course_id']);
            $stmt->execute();
            $students = $stmt->get_result();
            $stmt->close();
            
            while ($student = $students->fetch_assoc()) {
                // Check if student has already completed the quiz
                $stmt = $this->conn->prepare("
                    SELECT student_quiz_id 
                    FROM StudentQuizzes 
                    WHERE student_id = ? AND quiz_id = ? AND is_completed = 1
                ");
                
                $stmt->bind_param("ii", $student['user_id'], $quiz['quiz_id']);
                $stmt->execute();
                $completed = $stmt->get_result();
                $stmt->close();
                
                // Only send reminder if student hasn't completed the quiz
                if ($completed->num_rows === 0) {
                    $subject = "Reminder: Complete {$quiz['title']} Quiz";
                    
                    $message = "
                        <h3>Hello {$student['name']},</h3>
                        <p>This is a friendly reminder that you still need to complete the 
                           <strong>{$quiz['title']}</strong> quiz for your course 
                           <strong>{$quiz['course_title']}</strong>.</p>
                        
                        <p>Please make sure to complete this quiz as it is an important part of your course.</p>
                        
                        <p><a href='http://localhost/lms/take_quiz.php?id={$quiz['quiz_id']}' 
                              class='button'>Take Quiz Now</a></p>
                    ";
                    
                    // Send the email
                    $email_sent = $this->sendEmail(
                        $student['email'],
                        $subject,
                        $message,
                        $student['user_id'],
                        'Deadline Reminder'
                    );
                    
                    if ($email_sent) {
                        $total_sent++;
                    }
                }
            }
        }
        
        return $total_sent;
    }
}
?>