<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {
    header("Location: login.php");
    exit();
}

// Get instructor data
$instructor_id = $_SESSION['user_id'];
$instructor_name = $_SESSION['name'];

// Set default report parameters
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$report_type = isset($_GET['report_type']) ? $_GET['report_type'] : 'monthly';
$report_period = isset($_GET['report_period']) ? $_GET['report_period'] : date('Y-m');

// Determine date range for the report
$start_date = '';
$end_date = '';

if ($report_type == 'monthly') {
    // For monthly reports
    $year_month = explode('-', $report_period);
    $year = $year_month[0];
    $month = $year_month[1];
    $start_date = "$year-$month-01";
    $end_date = date('Y-m-t', strtotime($start_date)); // Last day of month
} else {
    // For semesterly reports
    $semester = explode('-', $report_period);
    $year = $semester[0];
    $semester_num = $semester[1];
    
    if ($semester_num == '1') {
        $start_date = "$year-01-01";
        $end_date = "$year-06-30";
    } else {
        $start_date = "$year-07-01";
        $end_date = "$year-12-31";
    }
}

// Fetch courses for the instructor
$stmt = $conn->prepare("
    SELECT course_id, title 
    FROM Courses 
    LIMIT 20
");
$stmt->execute();
$courses = $stmt->get_result();

// Initialize report data arrays and counters
$participation_data = [];
$assignment_data = [];
$quiz_data = [];
$total_assignments = 0;
$total_quizzes = 0;
$total_class_days = 0;

// Only fetch report data if a course is selected
if ($course_id > 0) {
    
    // Get total number of assignments and quizzes for the course in the given period
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total_assignments FROM Assignments WHERE course_id = ?
    ");
    $stmt->bind_param("i", $course_id);
    $stmt->execute();
    $assignment_count_result = $stmt->get_result()->fetch_assoc();
    $total_assignments = $assignment_count_result['total_assignments'];
    
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total_quizzes FROM Quizzes WHERE course_id = ?
    ");
    $stmt->bind_param("i", $course_id);
    $stmt->execute();
    $quiz_count_result = $stmt->get_result()->fetch_assoc();
    $total_quizzes = $quiz_count_result['total_quizzes'];
    
    // Get total number of class days for attendance
    // Using a more reliable method than counting distinct dates
    $days_diff = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;
    
    // Assume classes meet every weekday (Monday-Friday)
    $total_class_days = 0;
    $start = new DateTime($start_date);
    $end = new DateTime($end_date);
    $interval = new DateInterval('P1D');
    $daterange = new DatePeriod($start, $interval, $end);
    
    foreach($daterange as $date) {
        $day_of_week = $date->format('N');
        if ($day_of_week <= 5) { // 1 (Monday) to 5 (Friday)
            $total_class_days++;
        }
    }
    // Add one more day if end date is a weekday
    if ($end->format('N') <= 5) {
        $total_class_days++;
    }
    
    // 1. Participation Report - Based on attendance and completed assignments/quizzes
    $stmt = $conn->prepare("
        SELECT 
            u.user_id,
            u.name as student_name,
            COUNT(DISTINCT CASE WHEN a.status = 'Present' THEN a.attendance_id END) as attendance_count,
            COUNT(DISTINCT s.submission_id) as submission_count,
            COUNT(DISTINCT CASE WHEN sq.is_completed = 1 THEN sq.student_quiz_id END) as quiz_completed_count,
            MAX(e.progress_percentage) as progress_percentage
        FROM 
            Users u
        JOIN 
            Enrollments e ON u.user_id = e.student_id
        LEFT JOIN 
            Attendance a ON u.user_id = a.student_id AND a.course_id = ? AND a.date BETWEEN ? AND ?
        LEFT JOIN 
            Submissions s ON u.user_id = s.student_id 
        LEFT JOIN 
            Assignments ass ON s.assignment_id = ass.assignment_id AND ass.course_id = ? AND s.date_submitted BETWEEN ? AND ?
        LEFT JOIN 
            StudentQuizzes sq ON u.user_id = sq.student_id 
        LEFT JOIN 
            Quizzes q ON sq.quiz_id = q.quiz_id AND q.course_id = ? AND sq.started_at BETWEEN ? AND ?
        WHERE 
            e.course_id = ? AND u.role = 'Student'
        GROUP BY 
            u.user_id, u.name
    ");
    $stmt->bind_param("issississi", $course_id, $start_date, $end_date, $course_id, $start_date, $end_date, $course_id, $start_date, $end_date, $course_id);
    $stmt->execute();
    $participation_results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    


    // Calculate participation rates and sort by overall participation rate
    $participation_data = [];
    foreach ($participation_results as $student) {
        // Calculate rates as percentages
        $attendance_rate = $total_class_days > 0 ? ($student['attendance_count'] / $total_class_days) * 100 : 0;
        $assignment_rate = $total_assignments > 0 ? ($student['submission_count'] / $total_assignments) * 100 : 0;
        $quiz_rate = $total_quizzes > 0 ? ($student['quiz_completed_count'] / $total_quizzes) * 100 : 0;
        
        // Calculate overall participation score (weighted average)
        $overall_participation_rate = 
            ($attendance_rate * 0.4) +     // Attendance is 40% of the score
            ($assignment_rate * 0.4) +     // Assignments are 40% of the score
            ($quiz_rate * 0.2);            // Quizzes are 20% of the score
        
        $student['attendance_rate'] = round($attendance_rate, 2);
        $student['assignment_rate'] = round($assignment_rate, 2);
        $student['quiz_rate'] = round($quiz_rate, 2);
        $student['overall_participation_rate'] = round($overall_participation_rate, 2);
        $student['total_class_days'] = $total_class_days;
        $student['total_assignments'] = $total_assignments;
        $student['total_quizzes'] = $total_quizzes;
        
        $participation_data[] = $student;
    }
    // Get student assignment scores
    $stmt = $conn->prepare("
    SELECT 
        u.user_id,
        u.name as student_name,
        COUNT(DISTINCT s.submission_id) as assignments_completed,
        AVG(s.grade) as average_score
    FROM 
        Users u
    JOIN 
        Enrollments e ON u.user_id = e.student_id
    LEFT JOIN 
        Submissions s ON u.user_id = s.student_id 
    LEFT JOIN 
        Assignments ass ON s.assignment_id = ass.assignment_id AND ass.course_id = ? AND s.date_submitted BETWEEN ? AND ?
    WHERE 
        e.course_id = ? AND u.role = 'Student'
    GROUP BY 
        u.user_id, u.name
    ORDER BY 
        AVG(s.grade) DESC
    ");
    $stmt->bind_param("issi", $course_id, $start_date, $end_date, $course_id);
    $stmt->execute();
    $student_assignment_scores = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // 2. Assignment Completion Report
    $stmt = $conn->prepare("
        SELECT 
            a.assignment_id,
            a.title,
            a.due_date,
            COUNT(DISTINCT e.student_id) as total_students,
            COUNT(DISTINCT s.student_id) as submitted_count,
            ROUND((COUNT(DISTINCT s.student_id) / COUNT(DISTINCT e.student_id)) * 100, 2) as completion_rate,
            AVG(s.grade) as average_grade
        FROM 
            Assignments a
        JOIN 
            Enrollments e ON a.course_id = e.course_id
        LEFT JOIN 
            Submissions s ON a.assignment_id = s.assignment_id AND s.student_id = e.student_id
        WHERE 
            a.course_id = ? AND a.due_date BETWEEN ? AND ?
        GROUP BY 
            a.assignment_id
        ORDER BY 
            a.due_date
    ");
    $stmt->bind_param("iss", $course_id, $start_date, $end_date);
    $stmt->execute();
    $assignment_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // 3. Quiz Performance Report
    $stmt = $conn->prepare("
    SELECT 
        q.quiz_id,
        q.title,
        q.topic,
        COUNT(DISTINCT e.student_id) as total_students,
        COUNT(DISTINCT sq.student_id) as attempt_count,
        ROUND((COUNT(DISTINCT sq.student_id) / COUNT(DISTINCT e.student_id)) * 100, 2) as attempt_rate,
        AVG(sq.score * 100) as average_score
    FROM 
        Quizzes q
    JOIN 
        Enrollments e ON q.course_id = e.course_id
    LEFT JOIN 
        StudentQuizzes sq ON q.quiz_id = sq.quiz_id AND sq.student_id = e.student_id AND sq.is_completed = 1
    WHERE 
        q.course_id = ? AND q.created_at BETWEEN ? AND ?
    GROUP BY 
        q.quiz_id
    ORDER BY 
        AVG(sq.score * 100) DESC
");
    $stmt->bind_param("iss", $course_id, $start_date, $end_date);
    $stmt->execute();
    $quiz_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // 4. Individual Student Quiz Performance (Top 10 & Bottom 10)
    $stmt = $conn->prepare("
    SELECT 
        u.user_id,
        u.name as student_name,
        COUNT(DISTINCT sq.student_quiz_id) as quizzes_taken,
        AVG(sq.score * 100) as average_score
    FROM 
        Users u
    JOIN 
        Enrollments e ON u.user_id = e.student_id
    LEFT JOIN 
        StudentQuizzes sq ON u.user_id = sq.student_id
    LEFT JOIN 
        Quizzes q ON sq.quiz_id = q.quiz_id
    WHERE 
        e.course_id = ? AND q.course_id = ? AND sq.is_completed = 1 
        AND sq.completed_at BETWEEN ? AND ?
    GROUP BY 
        u.user_id
    HAVING 
        COUNT(DISTINCT sq.student_quiz_id) > 0
    ORDER BY 
        AVG(sq.score * 100) DESC
");
    $stmt->bind_param("iiss", $course_id, $course_id, $start_date, $end_date);
    $stmt->execute();
    $student_quiz_performance = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Print debug information
    echo "<!-- Debug Info: 
         Total Assignments: $total_assignments
         Total Quizzes: $total_quizzes
         Total Class Days: $total_class_days
         Student Quiz Performance Count: " . count($student_quiz_performance) . "
         Quiz Data Count: " . count($quiz_data) . "
         -->";
}

// Function to get month name
function getMonthName($monthNum) {
    return date("F", mktime(0, 0, 0, $monthNum, 1));
}

// Function to get semester name
function getSemesterName($semNum) {
    return $semNum == '1' ? 'Spring Semester' : 'Fall Semester';
}

// Generate report data for Chart.js
$participation_labels = [];
$participation_values = [];
$assignment_labels = [];
$assignment_values = [];
$quiz_labels = [];
$quiz_values = [];

// Set a minimum value if there are no assignments, quizzes, or class days
// to prevent division by zero in the calculations
$total_assignments = max(1, $total_assignments);
$total_quizzes = max(1, $total_quizzes);
$total_class_days = max(1, $total_class_days);

foreach ($participation_data as $student) {
    $participation_labels[] = $student['student_name'];
    $participation_values[] = $student['overall_participation_rate'];
}

foreach ($assignment_data as $assignment) {
    $assignment_labels[] = $assignment['title'];
    $assignment_values[] = $assignment['completion_rate'];
}

foreach ($quiz_data as $quiz) {
    $quiz_labels[] = $quiz['title'];
    $quiz_values[] = $quiz['average_score'];
}

// Generate CSV data for download
function generateCSV($data, $filename) {
    if (empty($data)) return '';
    
    // Get headers from first row
    $headers = array_keys($data[0]);
    
    // Start output buffering
    ob_start();
    
    // Create a file pointer
    $output = fopen('php://output', 'w');
    
    // Add headers
    fputcsv($output, $headers);
    
    // Add rows
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    // Get the content from the buffer
    $csv = ob_get_clean();
    
    return $csv;
}

// Handle report download requests
if (isset($_GET['download']) && $course_id > 0) {
    $download_type = $_GET['download'];
    $filename = '';
    $csv_data = '';
    
    switch ($download_type) {
        case 'participation':
            $filename = "participation_report_{$report_period}.csv";
            $csv_data = generateCSV($participation_data, $filename);
            break;
        case 'assignment':
            $filename = "assignment_report_{$report_period}.csv";
            $csv_data = generateCSV($assignment_data, $filename);
            break;
        case 'assignment_scores':
            $filename = "assignment_scores_report_{$report_period}.csv";
            $csv_data = generateCSV($student_assignment_scores, $filename);
            break;
        case 'quiz':
            $filename = "quiz_report_{$report_period}.csv";
            $csv_data = generateCSV($quiz_data, $filename);
            break;
        case 'quiz_scores':
            $filename = "quiz_scores_report_{$report_period}.csv";
            $csv_data = generateCSV($student_quiz_performance, $filename);
            break;
    }
    
    if (!empty($csv_data)) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo $csv_data;
        exit;
    }
}

// Get course title if a course is selected
$course_title = "All Courses";
if ($course_id > 0) {
    $stmt = $conn->prepare("SELECT title FROM Courses WHERE course_id = ?");
    $stmt->bind_param("i", $course_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $course_title = $row['title'];
    }
}

// Format report period for display
if ($report_type == 'monthly') {
    $year_month = explode('-', $report_period);
    $display_period = getMonthName($year_month[1]) . ' ' . $year_month[0];
} else {
    $semester = explode('-', $report_period);
    $display_period = getSemesterName($semester[1]) . ' ' . $semester[0];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Reports & Analytics - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Reports & Analytics</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
        }
        #reports {
            padding: 50px 0;
        }
        .report-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        .report-box {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            margin: 0 auto;
        }
        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .report-filters {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .chart-container {
            position: relative;
            height: 50vh;
            margin: 30px 0;
        }
        .table-responsive {
            margin-top: 30px;
        }
        .report-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .btn-download {
            margin-left: 10px;
        }
        .grade-a { color: #28a745; font-weight: bold; }
        .grade-b { color: #17a2b8; font-weight: bold; }
        .grade-c { color: #ffc107; font-weight: bold; }
        .grade-d { color: #fd7e14; font-weight: bold; }
        .grade-f { color: #dc3545; font-weight: bold; }
        .nav-tabs {
            margin-bottom: 20px;
        }
        .tab-content {
            padding: 20px;
            border: 1px solid #ddd;
            border-top: none;
            border-radius: 0 0 5px 5px;
        }
        .period-selector {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 15px;
        }
        .period-selector .form-group {
            margin-right: 10px;
            margin-bottom: 0;
        }
        .period-selector .btn-apply {
            align-self: flex-end;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="instructor-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Reports Section -->
    <section id="reports">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center">Course Reports & Analytics</h2>
                    <p class="text-center">Generate comprehensive reports to track student performance and course effectiveness.</p>
                </div>
            </div>
            
            <!-- Report Filters -->
            <div class="report-filters">
                <form id="reportForm" method="get" action="reports.php">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="course_id">Select Course:</label>
                                <select class="form-control" id="course_id" name="course_id">
                                    <option value="0">All Courses</option>
                                    <?php while ($course = $courses->fetch_assoc()): ?>
                                        <option value="<?php echo $course['course_id']; ?>" <?php echo ($course_id == $course['course_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['title']); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="report_type">Report Type:</label>
                                <select class="form-control" id="report_type" name="report_type" onchange="togglePeriodSelector()">
                                    <option value="monthly" <?php echo ($report_type == 'monthly') ? 'selected' : ''; ?>>Monthly</option>
                                    <option value="semesterly" <?php echo ($report_type == 'semesterly') ? 'selected' : ''; ?>>Semesterly</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4" id="monthSelector" <?php echo ($report_type == 'semesterly') ? 'style="display:none;"' : ''; ?>>
                            <div class="form-group">
                                <label for="monthly_period">Select Month:</label>
                                <input type="month" class="form-control" id="monthly_period" name="report_period" value="<?php echo $report_period; ?>">
                            </div>
                        </div>
                        <div class="col-md-4" id="semesterSelector" <?php echo ($report_type == 'monthly') ? 'style="display:none;"' : ''; ?>>
                            <div class="form-group">
                                <label for="semesterly_period">Select Semester:</label>
                                <select class="form-control" id="semesterly_period" name="report_period">
                                    <?php
                                    $current_year = date('Y');
                                    for ($year = $current_year; $year >= $current_year - 3; $year--) {
                                        $sem1 = "$year-1";
                                        $sem2 = "$year-2";
                                        echo "<option value='$sem1'" . ($report_period == $sem1 ? ' selected' : '') . ">Spring $year</option>";
                                        echo "<option value='$sem2'" . ($report_period == $sem2 ? ' selected' : '') . ">Fall $year</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Generate Report</button>
                        </div>
                    </div>
                </form>
            </div>
            
            <?php if ($course_id > 0): ?>
            <div class="report-header">
                <h3><?php echo htmlspecialchars($course_title); ?> - Report for <?php echo htmlspecialchars($display_period); ?></h3>
            </div>
            
            <!-- Report Navigation Tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active">
                    <a href="#participation" aria-controls="participation" role="tab" data-toggle="tab">Student Participation</a>
                </li>
                <li role="presentation">
                    <a href="#assignments" aria-controls="assignments" role="tab" data-toggle="tab">Assignment Scores</a>
                </li>
                <li role="presentation">
                    <a href="#quizzes" aria-controls="quizzes" role="tab" data-toggle="tab">Quiz Scores</a>
                </li>
            </ul>
            
            <!-- Tab Content -->
            <div class="tab-content">
                <!-- Participation Tab -->
                <div role="tabpanel" class="tab-pane active" id="participation">
                    <h4>Student Participation Report</h4>
                    <p>This report ranks students based on their participation level, combining attendance, assignment submissions, and quiz attempts.</p>
                    
                    <?php if (empty($participation_data)): ?>
                        <div class="alert alert-info">No participation data available for the selected period.</div>
                    <?php else: ?>
                        <div class="chart-container">
                            <canvas id="participationChart"></canvas>
                        </div>
                        
                        <div class="table-responsive">
                            <h5>Detailed Participation Data</h5>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Rank</th>
                                        <th>Student Name</th>
                                        <th>Assignments (Completed/Total)</th>
                                        <th>Quizzes (Completed/Total)</th>
                                        <th>Overall Participation Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($participation_data as $index => $student): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                                            <td>
                                                <?php echo $student['submission_count']; ?> / <?php echo $student['total_assignments']; ?>
                                                (<?php echo $student['assignment_rate']; ?>%)
                                            </td>
                                            <td>
                                                <?php echo $student['quiz_completed_count']; ?> / <?php echo $student['total_quizzes']; ?>
                                                (<?php echo $student['quiz_rate']; ?>%)
                                            </td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar" role="progressbar" 
                                                         style="width: <?php echo $student['overall_participation_rate']; ?>%;" 
                                                         aria-valuenow="<?php echo $student['overall_participation_rate']; ?>" 
                                                         aria-valuemin="0" aria-valuemax="100">
                                                        <?php echo $student['overall_participation_rate']; ?>%
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="report-actions">
                            <a href="reports.php?course_id=<?php echo $course_id; ?>&report_type=<?php echo $report_type; ?>&report_period=<?php echo $report_period; ?>&download=participation" class="btn btn-success">
                                <i class="fa fa-download"></i> Download Report
                            </a>
                            <button type="button" class="btn btn-info" onclick="printReport('participation')">
                                <i class="fa fa-print"></i> Print Report
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Assignments Tab -->
                <div role="tabpanel" class="tab-pane" id="assignments">
                    <h4>Assignment Scores Report</h4>
                    <p>This report shows student performance on assignments, sorted by their average scores.</p>
                    
                    <?php if (empty($student_assignment_scores)): ?>
                        <div class="alert alert-info">No assignment data available for the selected period.</div>
                    <?php else: ?>
                        <div class="chart-container">
                            <canvas id="assignmentChart"></canvas>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="sortOrder">Sort Order:</label>
                                    <select class="form-control" id="sortOrder" onchange="sortAssignmentTable()">
                                    <option value="desc">Highest to Lowest Score</option>
                                        <option value="asc">Lowest to Highest Score</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="table-responsive">
                            <h5>Student Assignment Scores</h5>
                            <table class="table table-striped" id="assignmentScoresTable">
                                <thead>
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Assignments Completed</th>
                                        <th>Average Score</th>
                                        <th>Performance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($student_assignment_scores as $student): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                                            <td><?php echo $student['assignments_completed']; ?> / <?php echo $total_assignments; ?></td>
                                            <td>
                                                <?php 
                                                    $grade_class = '';
                                                    $avg_grade = round($student['average_score'], 2);
                                                    if ($avg_grade >= 90) $grade_class = 'grade-a';
                                                    else if ($avg_grade >= 80) $grade_class = 'grade-b';
                                                    else if ($avg_grade >= 70) $grade_class = 'grade-c';
                                                    else if ($avg_grade >= 60) $grade_class = 'grade-d';
                                                    else if ($avg_grade > 0) $grade_class = 'grade-f';
                                                ?>
                                                <span class="<?php echo $grade_class; ?>">
                                                    <?php echo $avg_grade > 0 ? $avg_grade : 'N/A'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar" role="progressbar" 
                                                         style="width: <?php echo $avg_grade; ?>%;" 
                                                         aria-valuenow="<?php echo $avg_grade; ?>" 
                                                         aria-valuemin="0" aria-valuemax="100">
                                                        <?php echo $avg_grade; ?>%
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="report-actions">
                            <a href="reports.php?course_id=<?php echo $course_id; ?>&report_type=<?php echo $report_type; ?>&report_period=<?php echo $report_period; ?>&download=assignment_scores" class="btn btn-success">
                                <i class="fa fa-download"></i> Download Report
                            </a>
                            <button type="button" class="btn btn-info" onclick="printReport('assignments')">
                                <i class="fa fa-print"></i> Print Report
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Quizzes Tab -->
                <div role="tabpanel" class="tab-pane" id="quizzes">
                    <h4>Quiz Scores Report</h4>
                    <p>This report shows student performance on quizzes, sorted by their average scores.</p>
                    
                    <?php if (empty($student_quiz_performance) && empty($quiz_data)): ?>
                        <div class="alert alert-info">No quiz data available for the selected period.</div>
                    <?php elseif (empty($student_quiz_performance)): ?>
                        <!-- Show quiz overview data instead when student performance data isn't available -->
                        <div class="chart-container">
                            <canvas id="quizChart"></canvas>
                        </div>
                        
                        <div class="table-responsive">
                            <h5>Quiz Performance Overview</h5>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Quiz Title</th>
                                        <th>Topic</th>
                                        <th>Total Students</th>
                                        <th>Attempts</th>
                                        <th>Attempt Rate</th>
                                        <th>Average Score</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($quiz_data as $quiz): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($quiz['title']); ?></td>
                                            <td><?php echo htmlspecialchars($quiz['topic']); ?></td>
                                            <td><?php echo $quiz['total_students']; ?></td>
                                            <td><?php echo $quiz['attempt_count']; ?></td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar" role="progressbar" 
                                                         style="width: <?php echo $quiz['attempt_rate']; ?>%;" 
                                                         aria-valuenow="<?php echo $quiz['attempt_rate']; ?>" 
                                                         aria-valuemin="0" aria-valuemax="100">
                                                        <?php echo $quiz['attempt_rate']; ?>%
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <?php 
                                                    $grade_class = '';
                                                    $avg_score = round($quiz['average_score'], 2);
                                                    if ($avg_score >= 90) $grade_class = 'grade-a';
                                                    else if ($avg_score >= 80) $grade_class = 'grade-b';
                                                    else if ($avg_score >= 70) $grade_class = 'grade-c';
                                                    else if ($avg_score >= 60) $grade_class = 'grade-d';
                                                    else if ($avg_score > 0) $grade_class = 'grade-f';
                                                ?>
                                                <span class="<?php echo $grade_class; ?>">
                                                    <?php echo $avg_score > 0 ? $avg_score . '%' : 'N/A'; ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="report-actions">
                            <a href="reports.php?course_id=<?php echo $course_id; ?>&report_type=<?php echo $report_type; ?>&report_period=<?php echo $report_period; ?>&download=quiz" class="btn btn-success">
                                <i class="fa fa-download"></i> Download Report
                            </a>
                            <button type="button" class="btn btn-info" onclick="printReport('quizzes')">
                                <i class="fa fa-print"></i> Print Report
                            </button>
                        </div>
                    <?php else: ?>
                        <!-- Show student quiz performance data -->
                        <div class="chart-container">
                            <canvas id="quizChart"></canvas>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="quizSortOrder">Sort Order:</label>
                                    <select class="form-control" id="quizSortOrder" onchange="sortQuizTable()">
                                        <option value="desc">Highest to Lowest Score</option>
                                        <option value="asc">Lowest to Highest Score</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="table-responsive">
                            <h5>Student Quiz Scores</h5>
                            <table class="table table-striped" id="quizScoresTable">
                                <thead>
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Quizzes Completed</th>
                                        <th>Average Score</th>
                                        <th>Performance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($student_quiz_performance as $student): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                                            <td><?php echo $student['quizzes_taken']; ?> / <?php echo $total_quizzes; ?></td>
                                            <td>
                                                <?php 
                                                    $grade_class = '';
                                                    $avg_score = round($student['average_score'], 2);
                                                    if ($avg_score >= 90) $grade_class = 'grade-a';
                                                    else if ($avg_score >= 80) $grade_class = 'grade-b';
                                                    else if ($avg_score >= 70) $grade_class = 'grade-c';
                                                    else if ($avg_score >= 60) $grade_class = 'grade-d';
                                                    else if ($avg_score > 0) $grade_class = 'grade-f';
                                                ?>
                                                <span class="<?php echo $grade_class; ?>">
                                                    <?php echo $avg_score > 0 ? $avg_score : 'N/A'; ?>%
                                                </span>
                                            </td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar" role="progressbar" 
                                                         style="width: <?php echo $avg_score; ?>%;" 
                                                         aria-valuenow="<?php echo $avg_score; ?>" 
                                                         aria-valuemin="0" aria-valuemax="100">
                                                        <?php echo $avg_score; ?>%
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="report-actions">
                            <a href="reports.php?course_id=<?php echo $course_id; ?>&report_type=<?php echo $report_type; ?>&report_period=<?php echo $report_period; ?>&download=quiz_scores" class="btn btn-success">
                                <i class="fa fa-download"></i> Download Report
                            </a>
                            <button type="button" class="btn btn-info" onclick="printReport('quizzes')">
                                <i class="fa fa-print"></i> Print Report
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="alert alert-info text-center">
                <p>Please select a course to generate reports.</p>
            </div>
            <?php endif; ?>
        </div>
    </section>
    
    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2025 Learning Management System. All Rights Reserved.
                </div>
                <div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href="home.php">Home</a></li>
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <script>
        // Toggle between monthly and semesterly period selectors
        function togglePeriodSelector() {
            const reportType = document.getElementById('report_type').value;
            const monthSelector = document.getElementById('monthSelector');
            const semesterSelector = document.getElementById('semesterSelector');
            
            if (reportType === 'monthly') {
                monthSelector.style.display = 'block';
                semesterSelector.style.display = 'none';
            } else {
                monthSelector.style.display = 'none';
                semesterSelector.style.display = 'block';
            }
        }
        
        // Function to sort assignment scores table
        function sortAssignmentTable() {
            const table = document.getElementById('assignmentScoresTable');
            const sortOrder = document.getElementById('sortOrder').value;
            const rows = Array.from(table.querySelectorAll('tbody tr'));
            
            // Sort rows by average score
            rows.sort((a, b) => {
                const scoreA = parseFloat(a.cells[2].textContent.trim()) || 0;
                const scoreB = parseFloat(b.cells[2].textContent.trim()) || 0;
                
                return sortOrder === 'desc' ? scoreB - scoreA : scoreA - scoreB;
            });
            
            // Clear and re-add rows in new order
            const tbody = table.querySelector('tbody');
            tbody.innerHTML = '';
            rows.forEach(row => tbody.appendChild(row));
        }
        
        // Function to sort quiz scores table
        function sortQuizTable() {
            const table = document.getElementById('quizScoresTable');
            const sortOrder = document.getElementById('quizSortOrder').value;
            const rows = Array.from(table.querySelectorAll('tbody tr'));
            
            // Sort rows by average score
            rows.sort((a, b) => {
                const scoreA = parseFloat(a.cells[2].textContent.trim()) || 0;
                const scoreB = parseFloat(b.cells[2].textContent.trim()) || 0;
                
                return sortOrder === 'desc' ? scoreB - scoreA : scoreA - scoreB;
            });
            
            // Clear and re-add rows in new order
            const tbody = table.querySelector('tbody');
            tbody.innerHTML = '';
            rows.forEach(row => tbody.appendChild(row));
        }
        
        // Print specific report tab
        function printReport(tabId) {
            const printContents = document.getElementById(tabId).innerHTML;
            const originalContents = document.body.innerHTML;
            
            document.body.innerHTML = `
                <h1>Report: ${tabId.charAt(0).toUpperCase() + tabId.slice(1)}</h1>
                <div>${printContents}</div>
            `;
            
            window.print();
            document.body.innerHTML = originalContents;
            
            // Reinitialize charts after printing
            initializeCharts();
        }
        
        // Initialize assignment chart with student data
        function initializeAssignmentChart() {
            const assignmentCtx = document.getElementById('assignmentChart').getContext('2d');
            const studentLabels = [];
            const scoreValues = [];
            
            // Extract data from the table
            const table = document.getElementById('assignmentScoresTable');
            if (table) {
                const rows = table.querySelectorAll('tbody tr');
                rows.forEach(row => {
                    studentLabels.push(row.cells[0].textContent);
                    scoreValues.push(parseFloat(row.cells[2].textContent) || 0);
                });
                
                const scoreColors = scoreValues.map(value => {
                    if (value >= 90) return 'rgba(40, 167, 69, 0.7)';
                    else if (value >= 80) return 'rgba(23, 162, 184, 0.7)';
                    else if (value >= 70) return 'rgba(255, 193, 7, 0.7)';
                    else if (value >= 60) return 'rgba(253, 126, 20, 0.7)';
                    else return 'rgba(220, 53, 69, 0.7)';
                });
                
                new Chart(assignmentCtx, {
                    type: 'bar',
                    data: {
                        labels: studentLabels,
                        datasets: [{
                            label: 'Average Assignment Score',
                            data: scoreValues,
                            backgroundColor: scoreColors,
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100,
                                title: {
                                    display: true,
                                    text: 'Average Score (%)'
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Students'
                                }
                            }
                        },
                        plugins: {
                            title: {
                                display: true,
                                text: 'Student Assignment Performance'
                            },
                            legend: {
                                display: true,
                                position: 'top'
                            }
                        }
                    }
                });
            }
        }
        
        // Initialize quiz chart with student data
        function initializeQuizChart() {
            const quizCtx = document.getElementById('quizChart').getContext('2d');
            const studentLabels = [];
            const scoreValues = [];
            
            // Extract data from the table
            const table = document.getElementById('quizScoresTable');
            if (table) {
                const rows = table.querySelectorAll('tbody tr');
                rows.forEach(row => {
                    studentLabels.push(row.cells[0].textContent);
                    // Get score value (remove % sign if present)
                    const scoreText = row.cells[2].textContent.trim();
                    const scoreValue = parseFloat(scoreText.replace('%', '')) || 0;
                    scoreValues.push(scoreValue);
                });
                
                const scoreColors = scoreValues.map(value => {
                    if (value >= 90) return 'rgba(40, 167, 69, 0.7)';
                    else if (value >= 80) return 'rgba(23, 162, 184, 0.7)';
                    else if (value >= 70) return 'rgba(255, 193, 7, 0.7)';
                    else if (value >= 60) return 'rgba(253, 126, 20, 0.7)';
                    else return 'rgba(220, 53, 69, 0.7)';
                });
                
                new Chart(quizCtx, {
                    type: 'bar',
                    data: {
                        labels: studentLabels,
                        datasets: [{
                            label: 'Average Quiz Score',
                            data: scoreValues,
                            backgroundColor: scoreColors,
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100,
                                title: {
                                    display: true,
                                    text: 'Average Score (%)'
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Students'
                                }
                            }
                        },
                        plugins: {
                            title: {
                                display: true,
                                text: 'Student Quiz Performance'
                            },
                            legend: {
                                display: true,
                                position: 'top'
                            }
                        }
                    }
                });
            }
        }
        
        // Initialize all charts
        function initializeCharts() {
            <?php if ($course_id > 0): ?>
            
            // Participation Chart
            <?php if (!empty($participation_data)): ?>
            const participationCtx = document.getElementById('participationChart').getContext('2d');
            const participationLabels = <?php echo json_encode($participation_labels); ?>;
            const participationValues = <?php echo json_encode($participation_values); ?>;
            
            new Chart(participationCtx, {
                type: 'bar',
                data: {
                    labels: participationLabels,
                    datasets: [{
                        label: 'Participation Score',
                        data: participationValues,
                        backgroundColor: 'rgba(54, 162, 235, 0.7)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Participation Score'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Students'
                            }
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: 'Student Participation Ranking'
                        },
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    }
                }
            });
            <?php endif; ?>
            
            // Assignment Chart - Use new student scores chart
            <?php if (!empty($student_assignment_scores)): ?>
            initializeAssignmentChart();
            <?php endif; ?>
            
            // Quiz Chart - Check which data is available
            <?php if (!empty($student_quiz_performance)): ?>
            initializeQuizChart();
            <?php elseif (!empty($quiz_data)): ?>
            // Original quiz chart initialization code
            const quizCtx = document.getElementById('quizChart').getContext('2d');
            const quizLabels = <?php echo json_encode($quiz_labels); ?>;
            const quizValues = <?php echo json_encode($quiz_values); ?>;
            const quizColors = quizValues.map(value => {
                if (value >= 90) return 'rgba(40, 167, 69, 0.7)';
                else if (value >= 80) return 'rgba(23, 162, 184, 0.7)';
                else if (value >= 70) return 'rgba(255, 193, 7, 0.7)';
                else if (value >= 60) return 'rgba(253, 126, 20, 0.7)';
                else return 'rgba(220, 53, 69, 0.7)';
            });
            
            new Chart(quizCtx, {
                type: 'bar',
                data: {
                    labels: quizLabels,
                    datasets: [{
                        label: 'Average Score (%)',
                        data: quizValues,
                        backgroundColor: quizColors,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            title: {
                                display: true,
                                text: 'Average Score (%)'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Quizzes'
                            }
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: 'Quiz Performance Analysis'
                        },
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    }
                }
            });
            <?php endif; ?>
            
            <?php endif; ?>
        }
        
        // Initialize charts when document is loaded
        document.addEventListener('DOMContentLoaded', function() {
            initializeCharts();
            
            // Switch to the requested tab if specified in URL
            const urlParams = new URLSearchParams(window.location.search);
            const tab = urlParams.get('tab');
            if (tab) {
                $('.nav-tabs a[href="#' + tab + '"]').tab('show');
            }
        });
    </script>
</body>
</html>