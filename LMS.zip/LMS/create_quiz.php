<?php
// Start the session
session_start();

// Session timeout duration (30 minutes)
$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();

// Include database connection
include 'db_connection.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {
    header("Location: login.php");
    exit();
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $instructor_id = $_SESSION['user_id'];

    // Get form data
    $course_id = $_POST['course_id'];
    $title = trim($_POST['title']);
    $topic = trim($_POST['topic']);
    
    // Handle automated grading checkbox
    $is_automated_grading = isset($_POST['is_automated_grading']) 
        ? $_POST['is_automated_grading'] 
        : 0;

    // Get time limit (if set)
    $time_limit = null;
    if (isset($_POST['has_time_limit']) && $_POST['has_time_limit'] == 1) {
        $time_limit = (int)$_POST['time_limit'];

        // Validate time limit (must be positive)
        if ($time_limit <= 0) {
            $_SESSION['error_message'] = "Time limit must be a positive number";
            header("Location: instructor-dashboard.php#quizzes");
            exit();
        }
    }

    // Validate input
    if (empty($title) || empty($course_id)) {
        $_SESSION['error_message'] = "Course and title fields are required";
        header("Location: instructor-dashboard.php#quizzes");
        exit();
    }

    // Check if course exists and instructor has access
    $stmt = $conn->prepare("SELECT course_id FROM Courses WHERE course_id = ?");
    $stmt->bind_param("i", $course_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $_SESSION['error_message'] = "Invalid course selected";
        header("Location: instructor-dashboard.php#quizzes");
        exit();
    }

    // NEW CODE: Process and validate topic
    $topic_id = null;
    
    // If topic is empty or just a number, find a real topic
    if (empty($topic) || preg_match('/^[0-9]+$/', $topic)) {
        // Try to find a topic for this course
        $topic_stmt = $conn->prepare("
    SELECT topic_id, topic_name 
    FROM CourseTopics 
    WHERE course_id = ? 
    ORDER BY topic_id 
    LIMIT 1
");
        
        $topic_stmt->bind_param("i", $course_id);
        $topic_stmt->execute();
        $topic_result = $topic_stmt->get_result();
        
        if ($topic_result->num_rows > 0) {
            // Use an existing topic from the course
            $topic_row = $topic_result->fetch_assoc();
            $topic_id = $topic_row['topic_id'];
            $topic = $topic_row['topic_name'];
        } else {
            // No topics found for course, create a new one
            $new_topic = "Topic for: " . $title;
            $create_topic = $conn->prepare("
                INSERT INTO CourseTopics (course_id, topic_name, sequence_order)
                VALUES (?, ?, 1)
            ");
            $create_topic->bind_param("is", $course_id, $new_topic);
            
            if ($create_topic->execute()) {
                $topic_id = $conn->insert_id;
                $topic = $new_topic;
            }
        }
    } else {
        // Check if entered topic matches existing one
        $topic_stmt = $conn->prepare("
            SELECT topic_id 
            FROM CourseTopics 
            WHERE course_id = ? AND topic_name = ?
        ");
        
        $topic_stmt->bind_param("is", $course_id, $topic);
        $topic_stmt->execute();
        $topic_result = $topic_stmt->get_result();
        
        if ($topic_result->num_rows > 0) {
            // Topic exists, use its ID
            $topic_row = $topic_result->fetch_assoc();
            $topic_id = $topic_row['topic_id'];
        } else {
            // Topic doesn't exist, create it
            $create_topic = $conn->prepare("
                INSERT INTO CourseTopics (course_id, topic_name, sequence_order)
                VALUES (?, ?, (SELECT COALESCE(MAX(sequence_order), 0) + 1 FROM CourseTopics WHERE course_id = ?))
            ");
            
            $create_topic->bind_param("isi", $course_id, $topic, $course_id);
            if ($create_topic->execute()) {
                $topic_id = $conn->insert_id;
            }
        }
    }
    // END NEW CODE

    // Modified insert statement to include topic_id
    $stmt = $conn->prepare(
        "INSERT INTO Quizzes (
            course_id, 
            title, 
            is_automated_grading, 
            topic,
            topic_id, 
            created_at, 
            requires_manual_grading, 
            time_limit
        ) VALUES (?, ?, ?, ?, ?, NOW(), 0, ?)"
    );
    $stmt->bind_param("isisii", $course_id, $title, $is_automated_grading, $topic, $topic_id, $time_limit);

    if ($stmt->execute()) {
        $quiz_id = $conn->insert_id;
        $_SESSION['success_message'] = "Quiz created successfully";
        
        // Redirect to quiz question management page
        header("Location: manage_questions.php?id=" . $quiz_id);
        exit();
    } else {
        $_SESSION['error_message'] = "Error creating quiz: " . $conn->error;
        header("Location: instructor-dashboard.php#quizzes");
        exit();
    }
} else {
    // If accessed directly without form submission
    header("Location: instructor-dashboard.php");
    exit();
}
?>