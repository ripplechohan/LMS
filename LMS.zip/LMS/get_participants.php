<?php
session_start();
include 'db_connection.php';

// Check if user is logged in and is an instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {
    echo "<p class='text-danger'>Access denied.</p>";
    exit();
}

// Get course ID from request
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
if ($course_id <= 0) {
    echo "<p class='text-danger'>Invalid course ID.</p>";
    exit();
}

// Get course details
$stmt = $conn->prepare("
    SELECT title 
    FROM Courses 
    WHERE course_id = ? AND instructor_id = ?
");
$stmt->bind_param("ii", $course_id, $_SESSION['user_id']);
$stmt->execute();
$course_result = $stmt->get_result();

if ($course_result->num_rows == 0) {
    echo "<p class='text-danger'>Course not found or you don't have permission to view it.</p>";
    exit();
}

$course = $course_result->fetch_assoc();

// Get participants for this course
$stmt = $conn->prepare("
    SELECT 
        u.user_id,
        u.name,
        u.email,
        e.status,
        e.progress_percentage,
        e.enrollment_date
    FROM 
        Enrollments e
    JOIN 
        Users u ON e.student_id = u.user_id
    WHERE 
        e.course_id = ?
    ORDER BY 
        u.name
");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$participants_result = $stmt->get_result();
?>

<h4 class="mb-3">Participants: <?php echo htmlspecialchars($course['title']); ?> 
    <span class="badge badge-primary"><?php echo $participants_result->num_rows; ?> students</span>
</h4>

<?php if ($participants_result->num_rows > 0): ?>
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Status</th>
                   
                    <th>Enrolled On</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($participant = $participants_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($participant['name']); ?></td>
                        <td><?php echo htmlspecialchars($participant['email']); ?></td>
                        <td>
                            <?php 
                                $status_class = '';
                                switch ($participant['status']) {
                                    case 'Enrolled':
                                        $status_class = 'badge-success';
                                        break;
                                    case 'Completed':
                                        $status_class = 'badge-primary';
                                        break;
                                    case 'Dropped':
                                        $status_class = 'badge-danger';
                                        break;
                                    default:
                                        $status_class = 'badge-secondary';
                                }
                            ?>
                            <span class="badge <?php echo $status_class; ?>">
                                <?php echo htmlspecialchars($participant['status']); ?>
                            </span>
                        </td>
                       
                        <td><?php echo date('M d, Y', strtotime($participant['enrollment_date'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="alert alert-info">
        <i class="fa fa-info-circle mr-2"></i> No students are enrolled in this course yet.
    </div>
<?php endif; ?>