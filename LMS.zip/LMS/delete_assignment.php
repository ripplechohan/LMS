<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {
    header("Location: login.php");
    exit();
}

// Verify that an assignment ID was provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "No assignment ID provided for deletion.";
    
    // Get the base URL without any anchors or query parameters
    $base_url = 'instructor_dashboard.php';
    if (isset($_SERVER['HTTP_REFERER'])) {
        // Extract the base URL from the referrer by removing anything after # or ?
        $ref_url = $_SERVER['HTTP_REFERER'];
        $base_url = preg_replace('/([\?#].*)$/', '', $ref_url);
        
        // If we're left with just a directory path, append instructor_dashboard.php
        if (substr($base_url, -1) === '/') {
            $base_url .= 'instructor_dashboard.php';
        }
    }
    
    // Always add the assignments anchor to ensure we redirect to the assignments section
    $redirect_url = $base_url . '#assignments';
    
    header("Location: $redirect_url");
    exit();
}

$assignment_id = $_GET['id'];

// Begin transaction to ensure data consistency
$conn->begin_transaction();

try {
    // First, check if the assignment exists and is associated with the instructor's courses
    $stmt = $conn->prepare("
        SELECT a.assignment_id 
        FROM Assignments a
        JOIN Courses c ON a.course_id = c.course_id
        WHERE a.assignment_id = ? AND c.instructor_id = ?
    ");
    
    $stmt->bind_param("ii", $assignment_id, $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        throw new Exception("Assignment not found or you don't have permission to delete it.");
    }
    
    // Delete related records first to maintain referential integrity
    
    // 1. Delete submissions related to this assignment
    $stmt = $conn->prepare("DELETE FROM Submissions WHERE assignment_id = ?");
    $stmt->bind_param("i", $assignment_id);
    $stmt->execute();
    
    // 2. Finally delete the assignment itself
    $stmt = $conn->prepare("DELETE FROM Assignments WHERE assignment_id = ?");
    $stmt->bind_param("i", $assignment_id);
    $stmt->execute();
    
    // If we got this far, commit the transaction
    $conn->commit();
    
    $_SESSION['success_message'] = "Assignment was successfully deleted.";
    
    // Get the base URL without any anchors or query parameters
    $base_url = 'instructor_dashboard.php';
    if (isset($_SERVER['HTTP_REFERER'])) {
        // Extract the base URL from the referrer by removing anything after # or ?
        $ref_url = $_SERVER['HTTP_REFERER'];
        $base_url = preg_replace('/([\?#].*)$/', '', $ref_url);
        
        // If we're left with just a directory path, append instructor_dashboard.php
        if (substr($base_url, -1) === '/') {
            $base_url .= 'instructor_dashboard.php';
        }
    }
    
    // Always add the assignments anchor to ensure we redirect to the assignments section
    $redirect_url = $base_url . '#assignments';
    
    header("Location: $redirect_url");
    exit();
} catch (Exception $e) {
    // Something went wrong, rollback the transaction
    $conn->rollback();
    
    $_SESSION['error_message'] = "Error deleting assignment: " . $e->getMessage();
    
    // Get the base URL without any anchors or query parameters
    $base_url = 'instructor_dashboard.php';
    if (isset($_SERVER['HTTP_REFERER'])) {
        // Extract the base URL from the referrer by removing anything after # or ?
        $ref_url = $_SERVER['HTTP_REFERER'];
        $base_url = preg_replace('/([\?#].*)$/', '', $ref_url);
        
        // If we're left with just a directory path, append instructor_dashboard.php
        if (substr($base_url, -1) === '/') {
            $base_url .= 'instructor_dashboard.php';
        }
    }
    
    // Always add the assignments anchor to ensure we redirect to the assignments section
    $redirect_url = $base_url . '#assignments';
    
    header("Location: $redirect_url");
    exit();
}
?>