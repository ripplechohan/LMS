<?php
session_start();
include 'db_connection.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Student') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// This endpoint is only for AJAX auto-save requests
if (!isset($_POST['auto_save']) || $_POST['auto_save'] !== 'true') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit();
}

$student_id = $_SESSION['user_id'];
$response = ['success' => false];

// Check if quiz ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'No quiz selected']);
    exit();
}

$quiz_id = intval($_GET['id']);

// Find the student's active quiz session
$stmt = $conn->prepare("
    SELECT student_quiz_id 
    FROM StudentQuizzes 
    WHERE student_id = ? AND quiz_id = ? AND is_completed = 0
    ORDER BY started_at DESC LIMIT 1
");
$stmt->bind_param("ii", $student_id, $quiz_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // No active quiz session found, create one
    $stmt = $conn->prepare("
        INSERT INTO StudentQuizzes (student_id, quiz_id, is_completed)
        VALUES (?, ?, 0)
    ");
    $stmt->bind_param("ii", $student_id, $quiz_id);
    $stmt->execute();
    $student_quiz_id = $conn->insert_id;
} else {
    // Use existing quiz session
    $row = $result->fetch_assoc();
    $student_quiz_id = $row['student_quiz_id'];
}

// Temporary table to store current answers
$temp_table = "temp_quiz_answers_" . time();
$conn->query("CREATE TEMPORARY TABLE $temp_table (
    question_id INT,
    selected_answer TEXT
)");

// Collect all submitted answers
foreach ($_POST as $key => $value) {
    if (strpos($key, 'question_') === 0) {
        $question_id = intval(substr($key, 9));
        $selected_answer = $value;
        
        $stmt = $conn->prepare("INSERT INTO $temp_table (question_id, selected_answer) VALUES (?, ?)");
        $stmt->bind_param("is", $question_id, $selected_answer);
        $stmt->execute();
    }
}

// Get questions for this quiz
$stmt = $conn->prepare("SELECT question_id FROM Questions WHERE quiz_id = ?");
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$questions_result = $stmt->get_result();

// Prepare a statement to check if an answer already exists
$check_stmt = $conn->prepare("
    SELECT answer_id 
    FROM StudentQuizAnswers 
    WHERE student_quiz_id = ? AND question_id = ?
");

// Prepare statements for insert and update
$insert_stmt = $conn->prepare("
    INSERT INTO StudentQuizAnswers (student_quiz_id, question_id, selected_answer, is_correct, is_graded)
    VALUES (?, ?, ?, 0, 0)
");

$update_stmt = $conn->prepare("
    UPDATE StudentQuizAnswers 
    SET selected_answer = ? 
    WHERE student_quiz_id = ? AND question_id = ?
");

// Process each question
while ($question = $questions_result->fetch_assoc()) {
    $question_id = $question['question_id'];
    
    // Check if we have an answer for this question in the temporary table
    $answer_query = $conn->query("SELECT selected_answer FROM $temp_table WHERE question_id = $question_id");
    
    if ($answer_query->num_rows > 0) {
        $selected_answer = $answer_query->fetch_assoc()['selected_answer'];
        
        // Check if an answer already exists for this question
        $check_stmt->bind_param("ii", $student_quiz_id, $question_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            // Update existing answer
            $update_stmt->bind_param("sii", $selected_answer, $student_quiz_id, $question_id);
            $update_stmt->execute();
        } else {
            // Insert new answer
            $insert_stmt->bind_param("iis", $student_quiz_id, $question_id, $selected_answer);
            $insert_stmt->execute();
        }
    }
}

// Drop the temporary table
$conn->query("DROP TEMPORARY TABLE IF EXISTS $temp_table");

// Update the last activity timestamp in the quiz session
$stmt = $conn->prepare("UPDATE StudentQuizzes SET last_updated = NOW() WHERE student_quiz_id = ?");
$stmt->bind_param("i", $student_quiz_id);
$stmt->execute();

// Close all prepared statements
$check_stmt->close();
$insert_stmt->close();
$update_stmt->close();

$response['success'] = true;
$response['message'] = 'Progress saved';

header('Content-Type: application/json');
echo json_encode($response);
exit();
?>