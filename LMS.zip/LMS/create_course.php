<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {
    header("Location: login.php");
    exit();
}

// Get instructor ID
$instructor_id = $_SESSION['user_id'];

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $title = $_POST['title'];
    $description = $_POST['description'] ?? null;
    $category = $_POST['category'] ?? null;
    $skill_level = $_POST['skill_level'];
    $prereq_course_id = !empty($_POST['prereq_course_id']) ? $_POST['prereq_course_id'] : null;
    $start_date = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
    $end_date = !empty($_POST['end_date']) ? $_POST['end_date'] : null;
    $is_active = $_POST['is_active'];
    
    // Validate required fields
    if (empty($title) || empty($skill_level)) {
        $_SESSION['error_message'] = "Course title and skill level are required.";
        header("Location: instructor-dashboard.php");
        exit();
    }
    
    try {
        // Insert course into database - MODIFIED to include instructor_id
        $stmt = $conn->prepare("
            INSERT INTO Courses (
                title, description, category, skill_level, 
                prereq_course_id, start_date, end_date, is_active, instructor_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param(
            "sssssssii", 
            $title, $description, $category, $skill_level,
            $prereq_course_id, $start_date, $end_date, $is_active, $instructor_id
        );
        
        if ($stmt->execute()) {
            $course_id = $conn->insert_id;
            
            // Now each course is automatically linked to the instructor who created it
            
            $_SESSION['success_message'] = "Course created successfully!";
        } else {
            $_SESSION['error_message'] = "Error creating course: " . $conn->error;
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Database error: " . $e->getMessage();
    }
    
    // Redirect back to instructor dashboard
    header("Location: instructor-dashboard.php");
    exit();
}

// If someone tries to access this file directly without submitting the form
header("Location: instructor-dashboard.php");
exit();
?>