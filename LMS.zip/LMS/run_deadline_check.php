<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';
require_once 'email_system.php';

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Create email notification system instance
$emailSystem = new EmailNotificationSystem($conn);

// Initialize counters
$assignment_reminders_sent = 0;
$quiz_reminders_sent = 0;
$errors = [];

// Send assignment deadline reminders
try {
    $assignment_reminders_sent = $emailSystem->sendDeadlineReminders();
} catch (Exception $e) {
    $errors[] = "Error sending assignment reminders: " . $e->getMessage();
}

// Send quiz reminders
try {
    $quiz_reminders_sent = $emailSystem->sendQuizReminders();
} catch (Exception $e) {
    $errors[] = "Error sending quiz reminders: " . $e->getMessage();
}

// Calculate total
$total_sent = $assignment_reminders_sent + $quiz_reminders_sent;

// Log this run to the system
$log_dir = __DIR__ . '/logs/system/';
if (!is_dir($log_dir)) {
    mkdir($log_dir, 0755, true);
}

$log_file = $log_dir . date('Y-m-d') . '_deadline_check.txt';
$log_content = date('Y-m-d H:i:s') . " | Admin: {$_SESSION['name']} | Assignment Reminders: {$assignment_reminders_sent} | " .
               "Quiz Reminders: {$quiz_reminders_sent} | Total: {$total_sent}\n";

if (!empty($errors)) {
    $log_content .= "Errors: " . implode(", ", $errors) . "\n";
}

file_put_contents($log_file, $log_content, FILE_APPEND);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Deadline Reminders - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Deadline Reminders</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
            padding: 20px;
        }
        .result-container {
            margin-top: 20px;
            padding: 20px;
            border-radius: 5px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stat-box {
            background-color: #fff;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #007bff;
        }
        .error-list {
            margin-top: 20px;
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2><i class="fas fa-bell"></i> Deadline Reminder System</h2>
        
        <div class="result-container">
            <div class="row">
                <div class="col-md-4">
                    <div class="stat-box">
                        <div class="stat-number"><?php echo $assignment_reminders_sent; ?></div>
                        <div>Assignment Reminders</div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="stat-box">
                        <div class="stat-number"><?php echo $quiz_reminders_sent; ?></div>
                        <div>Quiz Reminders</div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="stat-box">
                        <div class="stat-number"><?php echo $total_sent; ?></div>
                        <div>Total Emails Sent</div>
                    </div>
                </div>
            </div>
            
            <?php if(!empty($errors)): ?>
                <div class="error-list">
                    <h4><i class="fas fa-exclamation-triangle"></i> Errors:</h4>
                    <ul>
                        <?php foreach($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php else: ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Deadline reminders processed successfully.
                </div>
            <?php endif; ?>
            
            <div class="text-center" style="margin-top: 20px;">
                <a href="admin-dashboard.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>