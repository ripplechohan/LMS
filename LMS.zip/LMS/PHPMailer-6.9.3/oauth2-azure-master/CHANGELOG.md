# Changelog
This file is not actively maintained. All Notable changes to `oauth2-azure` are documented at https://github.com/TheNetworg/oauth2-azure/releases 

## v1.0.0 - 16NOV2015
- Initial release
