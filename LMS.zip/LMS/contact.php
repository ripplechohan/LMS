<?php
session_start();
include 'db_connection.php';
require_once 'email_system.php';

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$name = "";
$message = "";
$success_message = "";
$error_message = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = trim($_POST['name']);
    $message = trim($_POST['message']);
    
    // Validate inputs
    if (empty($name) || empty($message)) {
        $error_message = "Please fill all required fields.";
    } else {
        // Get user email from the session
        $user_id = $_SESSION['user_id'];
        $stmt = $conn->prepare("SELECT email FROM Users WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $user_email = $user['email'];
            
            // Create EmailNotificationSystem instance
            $emailSystem = new EmailNotificationSystem($conn);
            
            // Prepare email content
            $subject = "Contact Form Submission from " . $name;
            $email_message = "
                <h3>New Contact Form Submission</h3>
                <p><strong>From:</strong> {$name} ({$user_email})</p>
                <p><strong>Message:</strong></p>
                <p>{$message}</p>
            ";
            
            // Send email to admin - using a hardcoded admin email address
            // since we can't access the private property
            $admin_email = 'lms2413g6@gmail.com';
            
            try {
                $send_result = $emailSystem->sendEmail(
                    $admin_email,
                    $subject,
                    $email_message,
                    $user_id,
                    'Contact Form'
                );
                // If we get here without an exception, the email was sent
                $success_message = "Your message has been sent successfully. We'll get back to you soon.";
                $name = "";
                $message = "";
            } catch (Exception $e) {
                $error_message = "Failed to send your message. Please try again later.";
            }
            
            // Success/failure is now handled in the try/catch block above
        } else {
            $error_message = "User information not found.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Contact Us - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Contact Us</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
        }
        #contact-us {
            background-color: #f8f9fa;
            padding: 50px 0;
        }
        .contact-box {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body class="homepage">
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li class="active"><a href="contact.php">Contact Us</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <section id="contact-us">
        <div class="container">
            <div class="center wow fadeInDown">
                <h2>Contact Us</h2>
                <p class="lead">For any inquiries or assistance, please feel free to reach out to us:</p>
                <p><strong>Email:</strong> lms2413g6@gmail.com</p>
            </div>
            
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success">
                            <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger">
                            <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="contact-box">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div class="form-group">
                                <label for="name">Name:</label>
                                <input type="text" id="name" name="name" class="form-control" placeholder="Enter your name" value="<?php echo htmlspecialchars($name); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="message">Message:</label>
                                <textarea id="message" name="message" class="form-control" rows="5" placeholder="Enter your message" required><?php echo htmlspecialchars($message); ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Online Learning Management System | All Rights Reserved</p>
    </footer>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>