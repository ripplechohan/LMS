<?php 
session_start(); 

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();

include 'db_connection.php';  

// Check if user is logged in and has the right role 
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {     
    header("Location: login.php");     
    exit(); 
}  

// Get instructor ID 
$instructor_id = $_SESSION['user_id'];

// Check if assignment ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "No assignment specified.";
    header("Location: instructor-dashboard.php");
    exit();
}

$assignment_id = $_GET['id'];

// Process form submission for updates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data     
    $course_id = $_POST['course_id'];     
    $title = $_POST['title'];     
    $description = $_POST['description'] ?? null;     
    $due_date = $_POST['due_date'];     
    $topic = $_POST['topic'] ?? null;     
    $grading_criteria = $_POST['grading_criteria'] ?? null;     
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    // Validate required fields     
    if (empty($course_id) || empty($title) || empty($due_date)) {         
        $_SESSION['error_message'] = "Course ID, assignment title, and due date are required.";         
        header("Location: edit_assignment.php?id=" . $assignment_id);         
        exit();     
    }
    
    try {
        // Process and validate topic
        $topic_id = null;
        
        // If topic is empty or just a number, find a real topic
        if (empty($topic) || preg_match('/^[0-9]+$/', $topic)) {
            // Try to find a topic for this course
            $topic_stmt = $conn->prepare("
                SELECT topic_id, topic_name 
                FROM CourseTopics 
                WHERE course_id = ? 
                ORDER BY topic_id 
                LIMIT 1
            ");
            
            $topic_stmt->bind_param("i", $course_id);
            $topic_stmt->execute();
            $topic_result = $topic_stmt->get_result();
            
            if ($topic_result->num_rows > 0) {
                // Use an existing topic from the course
                $topic_row = $topic_result->fetch_assoc();
                $topic_id = $topic_row['topic_id'];
                $topic = $topic_row['topic_name'];
            } else {
                // No topics found for course, create a new one
                $new_topic = "Topic for: " . $title;
                $create_topic = $conn->prepare("
                    INSERT INTO CourseTopics (course_id, topic_name)
                    VALUES (?, ?)
                ");
                $create_topic->bind_param("is", $course_id, $new_topic);
                
                if ($create_topic->execute()) {
                    $topic_id = $conn->insert_id;
                    $topic = $new_topic;
                }
            }
        } else {
            // Check if entered topic matches existing one
            $topic_stmt = $conn->prepare("
                SELECT topic_id 
                FROM CourseTopics 
                WHERE course_id = ? AND topic_name = ?
            ");
            
            $topic_stmt->bind_param("is", $course_id, $topic);
            $topic_stmt->execute();
            $topic_result = $topic_stmt->get_result();
            
            if ($topic_result->num_rows > 0) {
                // Topic exists, use its ID
                $topic_row = $topic_result->fetch_assoc();
                $topic_id = $topic_row['topic_id'];
            } else {
                // Topic doesn't exist, create it
                $create_topic = $conn->prepare("
                    INSERT INTO CourseTopics (course_id, topic_name)
                    VALUES (?, ?)
                ");
                
                $create_topic->bind_param("is", $course_id, $topic);
                if ($create_topic->execute()) {
                    $topic_id = $conn->insert_id;
                }
            }
        }
        
        // Update assignment in database
        $update_stmt = $conn->prepare("
            UPDATE Assignments
            SET course_id = ?, 
                title = ?, 
                description = ?, 
                due_date = ?,
                topic = ?, 
                topic_id = ?, 
                grading_criteria = ?, 
                is_active = ?
            WHERE assignment_id = ?
        ");
        
        $update_stmt->bind_param(
            "issssisii",
            $course_id, 
            $title, 
            $description, 
            $due_date,
            $topic, 
            $topic_id, 
            $grading_criteria, 
            $is_active,
            $assignment_id
        );
        
        if ($update_stmt->execute()) {
            $_SESSION['success_message'] = "Assignment updated successfully!";
            
            // Check if due date is within 3 days - if so, trigger immediate email notification
            $current_date = date('Y-m-d');
            $three_days_from_now = date('Y-m-d', strtotime('+3 days'));
            
            if ($due_date <= $three_days_from_now && $due_date >= $current_date && $is_active) {
                // Include email system and trigger immediate notification
                require_once 'email_system.php';
                $emailSystem = new EmailNotificationSystem($conn);
                
                // Trigger the deadline reminder function
                $sent = $emailSystem->sendDeadlineReminders($assignment_id);
                
                if ($sent > 0) {
                    $_SESSION['success_message'] .= " Deadline reminders were sent to enrolled students.";
                    
                    // Log this action
                    $log_dir = __DIR__ . '/logs/system/';
                    if (!is_dir($log_dir)) {
                        mkdir($log_dir, 0755, true);
                    }
                    
                    $log_file = $log_dir . date('Y-m-d') . '_assignment_update.txt';
                    $log_content = date('Y-m-d H:i:s') . " | Assignment ID: {$assignment_id} | " .
                                  "Title: {$title} | Due: {$due_date} | Reminders sent: {$sent}\n";
                    file_put_contents($log_file, $log_content, FILE_APPEND);
                }
            }
            
            header("Location: instructor-dashboard.php");
            exit();
        } else {
            $_SESSION['error_message'] = "Error updating assignment: " . $conn->error;
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Database error: " . $e->getMessage();
    }
    
    // If we reach here, there was an error
    header("Location: edit_assignment.php?id=" . $assignment_id);
    exit();
}

// Fetch assignment details for display
$stmt = $conn->prepare("
    SELECT a.* 
    FROM Assignments a
    WHERE a.assignment_id = ?
");

$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $_SESSION['error_message'] = "Assignment not found.";
    header("Location: instructor-dashboard.php");
    exit();
}

$assignment = $result->fetch_assoc();

// Verify this assignment belongs to a course taught by this instructor
$check_instructor = $conn->prepare("
    SELECT 1 FROM Courses 
    WHERE course_id = ? AND instructor_id = ?
");

$check_instructor->bind_param("ii", $assignment['course_id'], $instructor_id);
$check_instructor->execute();
$instructor_result = $check_instructor->get_result();

if ($instructor_result->num_rows == 0) {
    $_SESSION['error_message'] = "You do not have permission to edit this assignment.";
    header("Location: instructor-dashboard.php");
    exit();
}

// Get all courses taught by this instructor for the dropdown
$courses_stmt = $conn->prepare("
    SELECT course_id, title AS course_name 
    FROM Courses
    WHERE instructor_id = ?
");

$courses_stmt->bind_param("i", $instructor_id);
$courses_stmt->execute();
$courses_result = $courses_stmt->get_result();

// Get all topics for the current course
$topics_stmt = $conn->prepare("
    SELECT topic_id, topic_name 
    FROM CourseTopics 
    WHERE course_id = ?
");

$topics_stmt->bind_param("i", $assignment['course_id']);
$topics_stmt->execute();
$topics_result = $topics_stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Edit Assignment - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Edit Assignment | LMS</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <style>
        body {
            background-color: white;
        }
        .edit-assignment-container {
            max-width: 900px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .page-title {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="LMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="instructor-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="edit-assignment-container">
        <h2 class="page-title">Edit Assignment</h2>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?php 
                    echo $_SESSION['error_message']; 
                    unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>
            
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php 
                    echo $_SESSION['success_message']; 
                    unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>
                
                <div class="panel panel-default">
                    <div class="panel-body">
                        <form action="edit_assignment.php?id=<?php echo $assignment_id; ?>" method="post">
                            <div class="form-group">
                                <label for="course_id">Course:</label>
                                <select class="form-control" id="course_id" name="course_id" required>
                                    <?php while ($course = $courses_result->fetch_assoc()): ?>
                                        <option value="<?php echo $course['course_id']; ?>" 
                                                <?php echo ($course['course_id'] == $assignment['course_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_name']); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="title">Assignment Title:</label>
                                <input type="text" class="form-control" id="title" name="title" 
                                       value="<?php echo htmlspecialchars($assignment['title']); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="description">Description:</label>
                                <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($assignment['description'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label for="topic">Topic:</label>
                                <select class="form-control" id="topic" name="topic" required>
                                    <?php while ($topic = $topics_result->fetch_assoc()): ?>
                                        <option value="<?php echo $topic['topic_id']; ?>" 
                                                <?php echo ($topic['topic_id'] == $assignment['topic_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($topic['topic_name']); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="due_date">Due Date:</label>
                                <input type="date" class="form-control" id="due_date" name="due_date" 
                                       value="<?php echo $assignment['due_date']; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="grading_criteria">Grading Criteria:</label>
                                <textarea class="form-control" id="grading_criteria" name="grading_criteria" rows="2"><?php echo htmlspecialchars($assignment['grading_criteria'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label for="is_active">Status:</label>
                                <select class="form-control" id="is_active" name="is_active">
                                    <option value="1" <?php echo ($assignment['is_active'] == 1) ? 'selected' : ''; ?>>Active</option>
                                    <option value="0" <?php echo ($assignment['is_active'] == 0) ? 'selected' : ''; ?>>Inactive</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                                <a href="instructor-dashboard.php" class="btn btn-default">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <script>
        // Function to load topics based on selected course
        $(document).ready(function() {
            $('#course_id').change(function() {
                var courseId = $(this).val();
                loadTopics(courseId);
            });
            
            function loadTopics(courseId) {
                $.ajax({
                    url: 'get_course_topics.php',
                    type: 'POST',
                    data: {course_id: courseId},
                    success: function(data) {
                        $('#topic').html(data);
                    }
                });
            }
        });
    </script>
</body>
</html>