<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';
require_once 'email_utils.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Instructor') {
    header("Location: login.php");
    exit();
}

// Get instructor data
$instructor_id = $_SESSION['user_id'];
$instructor_name = $_SESSION['name'];

$success_message = '';
$error_message = '';

if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// Check if quiz_id is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid quiz ID";
    header("Location: instructor-dashboard.php");
    exit();
}

$quiz_id = $_GET['id'];

// Process form submission for grading quiz
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['grade_quiz'])) {
    // Loop through the essay answers to be graded
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'grade_') === 0) {
            $answer_id = substr($key, 6); // Extract answer_id from 'grade_{answer_id}'
            $grade = floatval($value);
            $feedback = trim($_POST['feedback_' . $answer_id] ?? '');
            
            // Ensure grade is between 0-100
            $grade = max(0, min(100, $grade));
            
            // Calculate grade value as decimal (0-1)
            $grade_value = $grade / 100;
            
            // Update the answer with the exact grade
            $stmt = $conn->prepare("
                UPDATE StudentQuizAnswers
                SET is_correct = ?, instructor_feedback = ?, is_graded = 1
                WHERE answer_id = ?
            ");
            $stmt->bind_param("dsi", $grade_value, $feedback, $answer_id);
            $stmt->execute();
        }
    }
    
    // Check if we need to update the StudentQuizzes record for completion
    if (isset($_POST['student_quiz_id']) && !empty($_POST['student_quiz_id'])) {
        $student_quiz_id = intval($_POST['student_quiz_id']);
        
        // Count how many questions have been graded
        $stmt = $conn->prepare("
            SELECT 
                COUNT(*) as total_questions, 
                SUM(is_graded) as graded_questions,
                SUM(is_correct) as total_score,
                COUNT(*) as question_count
            FROM StudentQuizAnswers
            WHERE student_quiz_id = ?
        ");
        $stmt->bind_param("i", $student_quiz_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $grading_data = $result->fetch_assoc();
        
        // Only mark as complete if all questions have been graded
        if ($grading_data && $grading_data['total_questions'] > 0 && 
            $grading_data['total_questions'] == $grading_data['graded_questions']) {
            
            // Calculate final score as average of all answers
            $final_score = 0;
            if ($grading_data['question_count'] > 0) {
                $final_score = $grading_data['total_score'] / $grading_data['question_count'];
                
                // Log for debugging
                error_log("Final score calculation: " . $grading_data['total_score'] . " / " . $grading_data['question_count'] . " = " . $final_score);
            }
            
            // Update the quiz as completed with the final score (explicitly casting to float)
            $stmt = $conn->prepare("
                UPDATE StudentQuizzes
                SET is_completed = 1, 
                    score = ?,
                    completed_at = NOW()
                WHERE student_quiz_id = ?
            ");
            
            // Make sure we bind the score as a proper decimal/float
            $stmt->bind_param("di", $final_score, $student_quiz_id);
            $success = $stmt->execute();
            
            if (!$success) {
                error_log("Error updating final score: " . $stmt->error);
            } else {
                error_log("Successfully updated final score to: " . $final_score);
            }
            
            $success_message = "Quiz has been fully graded and marked as complete.";

            if ($stmt->affected_rows > 0) {
                // Get the student ID and quiz information for the email
                $get_quiz_info = $conn->prepare("
                    SELECT sq.student_id, q.title, q.course_id 
                    FROM StudentQuizzes sq
                    JOIN Quizzes q ON sq.quiz_id = q.quiz_id
                    WHERE sq.student_quiz_id = ?
                ");
                $get_quiz_info->bind_param("i", $student_quiz_id);
                $get_quiz_info->execute();
                $quiz_info_result = $get_quiz_info->get_result();
                
                if ($quiz_info_result->num_rows > 0) {
                    $quiz_info = $quiz_info_result->fetch_assoc();
                    
                    // Send email notification
                    try {
                        EmailUtils::sendFeedbackNotification(
                            $quiz_info['student_id'],
                            $quiz_info['course_id'],
                            $quiz_info['title'],
                            'quiz'
                        );
                        
                        // Add to the success message
                        $success_message .= " An email notification has been sent to the student.";
                    } catch (Exception $e) {
                        error_log("Failed to send feedback notification email: " . $e->getMessage());
                    }
                }
            }

            // After quiz is marked as complete, trigger feedback regeneration
if ($stmt->affected_rows > 0) {
    // Get student ID from the StudentQuizzes table
    $get_student_stmt = $conn->prepare("
        SELECT student_id FROM StudentQuizzes WHERE student_quiz_id = ?
    ");
    $get_student_stmt->bind_param("i", $student_quiz_id);
    $get_student_stmt->execute();
    $student_result = $get_student_stmt->get_result();
    
    if ($student_result->num_rows > 0) {
        $student_data = $student_result->fetch_assoc();
        $student_id = $student_data['student_id'];
        
        // Mark feedback for regeneration
        require_once 'feedback_utils.php';
        markFeedbackForRegeneration($student_id);
        
        // Log for debugging
        error_log("Marked quiz complete for student $student_id - Feedback regeneration scheduled");
    }
}

        } else {
            $success_message = "Answers graded successfully. Quiz will be marked as complete when all questions are graded.";
        }
    }
    
    // Refresh the page to show updated data
   // Store success/error messages in session for display after redirect
if (!empty($success_message)) {
    $_SESSION['success_message'] = $success_message;
}
if (!empty($error_message)) {
    $_SESSION['error_message'] = $error_message;
}

// Check if we need to regenerate feedback
if (isset($_SESSION['regenerate_feedback']) && $_SESSION['regenerate_feedback']) {
    // Redirect to feedback.php with regenerate=1 parameter
    // This will trigger regeneration of the AI feedback
    $student_id = $_SESSION['feedback_student_id'];
    
    // Clear the regeneration flags
    unset($_SESSION['regenerate_feedback']);
    unset($_SESSION['feedback_student_id']);
    
    // Redirect to feedback.php to regenerate the feedback
    header("Location: feedback.php?regenerate=1&student_id=$student_id");
    exit();
} else {
    // Normal redirect back to the grading page
    header("Location: grade_quiz.php?id=$quiz_id&student_quiz_id=$student_quiz_id");
    exit();
}
}

// Get quiz information
$stmt = $conn->prepare("
    SELECT q.quiz_id, q.title, q.topic, q.is_automated_grading, q.is_published, q.requires_manual_grading,
           c.title as course_title, c.course_id
    FROM Quizzes q
    JOIN Courses c ON q.course_id = c.course_id
    WHERE q.quiz_id = ?
");
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$quiz_result = $stmt->get_result();

if ($quiz_result->num_rows === 0) {
    $_SESSION['error_message'] = "Quiz not found";
    header("Location: instructor-dashboard.php");
    exit();
}

$quiz = $quiz_result->fetch_assoc();

// Get student attempts for this quiz
$stmt = $conn->prepare("
    SELECT sq.student_quiz_id, u.user_id, u.name as student_name, sq.score, sq.total_questions, 
           sq.started_at, sq.completed_at, sq.is_completed
    FROM StudentQuizzes sq
    JOIN Users u ON sq.student_id = u.user_id
    WHERE sq.quiz_id = ?
    ORDER BY sq.is_completed ASC, sq.started_at DESC
");
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$student_attempts = $stmt->get_result();
$attempt_count = $student_attempts->num_rows;

// Get the specific student's attempt if student_id is provided
$student_quiz_id = null;
$student_data = null;
$quiz_answers = null;

if (isset($_GET['student_quiz_id']) && is_numeric($_GET['student_quiz_id'])) {
    $student_quiz_id = $_GET['student_quiz_id'];
    
    // Get student information
    $stmt = $conn->prepare("
        SELECT sq.student_quiz_id, u.user_id, u.name as student_name, sq.score, sq.total_questions, 
               sq.started_at, sq.completed_at, sq.is_completed
        FROM StudentQuizzes sq
        JOIN Users u ON sq.student_id = u.user_id
        WHERE sq.student_quiz_id = ?
    ");
    $stmt->bind_param("i", $student_quiz_id);
    $stmt->execute();
    $student_result = $stmt->get_result();
    
    if ($student_result->num_rows > 0) {
        $student_data = $student_result->fetch_assoc();
        
        // Get this student's answers
        $stmt = $conn->prepare("
        SELECT sqa.answer_id, q.question_id, q.text as question_text, q.question_format, 
               q.answer as correct_answer, q.essay_answer_template, q.point_value,
               sqa.selected_answer, sqa.is_correct, sqa.is_graded, sqa.instructor_feedback
        FROM StudentQuizAnswers sqa
        JOIN Questions q ON sqa.question_id = q.question_id
        WHERE sqa.student_quiz_id = ?
        ORDER BY q.question_id
    ");
    $stmt->bind_param("i", $student_quiz_id);
    $stmt->execute();
    $quiz_answers = $stmt->get_result();
    }
}

// Function to parse and display MCQ options
function displayMCQOptions($questionText) {
    $lines = explode("\n", $questionText);
    
    // First line is the question, the rest are options
    $question = $lines[0];
    $options = array_slice($lines, 1);
    
    echo '<p><strong>Question:</strong> ' . htmlspecialchars($question) . '</p>';
    echo '<p><strong>Options:</strong></p>';
    echo '<ul class="list-group">';
    
    foreach ($options as $option) {
        echo '<li class="list-group-item">' . htmlspecialchars($option) . '</li>';
    }
    
    echo '</ul>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Grade Quiz - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Grade Quiz</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
        }
        
        #page-breadcrumb {
            background: #2A95BE;
            padding: 4px 0;
            color: white;
            margin-bottom: 40px;
        }
        .vertical-center {
            display: flex;
            align-items: center;
            min-height: 100px;
        }
        .sun {
            background-image: url('images/bg1.jpg');
            background-size: cover;
        }
        .grading-container {
            margin-top: 30px;
        }
        .quiz-info {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .student-card {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .student-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        .question-card {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border-left: 4px solid #007bff;
        }
        .essay-question {
            border-left: 4px solid #28a745;
        }
        .answer-section {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
        }
        .student-answer {
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #6c757d;
        }
        .grading-section {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 15px;
            border: 1px solid #dee2e6;
        }
        .badge-essay {
            background-color: #28a745;
        }
        .badge-mcq {
            background-color: #007bff;
        }
        .badge-tf {
            background-color: #6c757d;
        }
        .mt-3 {
            margin-top: 15px;
        }
        .action-buttons {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }
        .graded {
            border-left: 4px solid #28a745;
        }
        .ungraded {
            border-left: 4px solid #dc3545;
        }
        .needs-grading {
            background-color: #fff3cd;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 4px solid #ffc107;
        }
        .student-list {
            max-height: 500px;
            overflow-y: auto;
            margin-bottom: 20px;
        }
        .status-badge {
            display: inline-block;
            padding: 3px 7px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-completed {
            background-color: #d4edda;
            color: #155724;
        }
        .status-in-progress {
            background-color: #fff3cd;
            color: #856404;
        }
        .status-needs-grading {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="instructor-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <section id="page-breadcrumb">
        <div class="vertical-center sun">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Grade Quiz</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p class="mt-3"><a href="instructor-dashboard.php#quizzes" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back to Dashboard</a></p>
                
                <?php if(!empty($success_message)): ?>
                    <div class="alert alert-success">
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>

                <?php if(!empty($error_message)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                
                <div class="quiz-info">
                    <h3><?php echo htmlspecialchars($quiz['title']); ?></h3>
                    <p><strong>Course:</strong> <?php echo htmlspecialchars($quiz['course_title']); ?></p>
                    <p><strong>Topic:</strong> <?php echo htmlspecialchars($quiz['topic']); ?></p>
                    <p><strong>Manual Grading Required:</strong> <?php echo $quiz['requires_manual_grading'] ? 'Yes' : 'No'; ?></p>
                    
                    <?php if($attempt_count == 0): ?>
                        <div class="alert alert-info">
                            <p>No students have attempted this quiz yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php if($attempt_count > 0): ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">Student Attempts</h4>
                                </div>
                                <div class="panel-body">
                                    <div class="student-list">
                                        <div class="list-group">
                                            <?php
                                            $student_attempts->data_seek(0); // Reset pointer
                                            while($attempt = $student_attempts->fetch_assoc()): 
                                            ?>
                                                <a href="grade_quiz.php?id=<?php echo $quiz_id; ?>&student_quiz_id=<?php echo $attempt['student_quiz_id']; ?>" 
                                                   class="list-group-item <?php echo ($student_quiz_id == $attempt['student_quiz_id']) ? 'active' : ''; ?>">
                                                    <h4 class="list-group-item-heading"><?php echo htmlspecialchars($attempt['student_name']); ?></h4>
                                                    <p class="list-group-item-text">
                                                        Submitted: <?php echo date('M d, Y H:i', strtotime($attempt['started_at'])); ?>
                                                    </p>
                                                    <?php if($attempt['is_completed']): ?>
                                                        <span class="status-badge status-completed">Completed</span>
                                                        <span class="label label-info">Score: <?php echo round($attempt['score'] * 100, 1); ?>%</span>
                                                    <?php else: ?>
                                                        <?php if($quiz['requires_manual_grading']): ?>
                                                            <span class="status-badge status-needs-grading">Needs Grading</span>
                                                        <?php else: ?>
                                                            <span class="status-badge status-in-progress">In Progress</span>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </a>
                                            <?php endwhile; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-8">
                            <?php if($student_quiz_id && $student_data && $quiz_answers): ?>
                                <div class="student-card">
                                    <div class="student-header">
                                        <h4>
                                            <?php echo htmlspecialchars($student_data['student_name']); ?>
                                            <?php if($student_data['is_completed']): ?>
                                                <span class="label label-success">Completed</span>
                                            <?php else: ?>
                                                <span class="label label-warning">Needs Grading</span>
                                            <?php endif; ?>
                                        </h4>
                                        <div>
                                            <p><strong>Started:</strong> <?php echo date('M d, Y H:i', strtotime($student_data['started_at'])); ?></p>
                                            <?php if($student_data['completed_at']): ?>
                                                <p><strong>Completed:</strong> <?php echo date('M d, Y H:i', strtotime($student_data['completed_at'])); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="grading-container">
                                        <h4>Student's Answers</h4>
                                        
                                        <form action="grade_quiz.php?id=<?php echo $quiz_id; ?>&student_quiz_id=<?php echo $student_quiz_id; ?>" method="post">
                                            <input type="hidden" name="student_quiz_id" value="<?php echo $student_quiz_id; ?>">
                                            
                                            <?php 
                                            $needs_grading = false;
                                            $quiz_answers->data_seek(0);
                                            while($answer = $quiz_answers->fetch_assoc()): 
                                                $is_essay = ($answer['question_format'] === 'Essay');
                                                if($is_essay && !$answer['is_graded']) {
                                                    $needs_grading = true;
                                                }
                                            ?>
                                                <div class="question-card <?php echo $is_essay ? 'essay-question' : ''; ?> <?php echo $answer['is_graded'] ? 'graded' : 'ungraded'; ?>">
                                                    <div class="question-header">
                                                        <span class="badge <?php echo $is_essay ? 'badge-essay' : ($answer['question_format'] === 'MCQ' ? 'badge-mcq' : 'badge-tf'); ?>">
                                                            <?php echo htmlspecialchars($answer['question_format']); ?>
                                                        </span>
                                                    </div>
                                                    
                                                    <?php if($answer['question_format'] === 'MCQ'): ?>
                                                        <?php displayMCQOptions($answer['question_text']); ?>
                                                        <div class="answer-section">
                                                            <p><strong>Correct Answer:</strong> <?php echo htmlspecialchars($answer['correct_answer']); ?></p>
                                                            <p><strong>Student's Answer:</strong> <?php echo htmlspecialchars($answer['selected_answer']); ?></p>
                                                            <p><strong>Status:</strong> 
                                                                <?php if($answer['is_graded']): ?>
                                                                    <?php if($answer['is_correct'] >= 0.6): ?>
                                                                        <span class="text-success"><i class="fa fa-check-circle"></i> Pass (<?php echo round($answer['is_correct'] * 100, 1); ?>%)</span>
                                                                    <?php else: ?>
                                                                        <span class="text-danger"><i class="fa fa-times-circle"></i> Fail (<?php echo round($answer['is_correct'] * 100, 1); ?>%)</span>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <span class="text-warning"><i class="fa fa-clock"></i> Pending</span>
                                                                <?php endif; ?>
                                                            </p>
                                                        </div>
                                                    <?php elseif($answer['question_format'] === 'True/False'): ?>
                                                        <p><strong>Question:</strong> <?php echo htmlspecialchars($answer['question_text']); ?></p>
                                                        <div class="answer-section">
                                                            <p><strong>Correct Answer:</strong> <?php echo htmlspecialchars($answer['correct_answer']); ?></p>
                                                            <p><strong>Student's Answer:</strong> <?php echo htmlspecialchars($answer['selected_answer']); ?></p>
                                                            <p><strong>Status:</strong> 
                                                                <?php if($answer['is_graded']): ?>
                                                                    <?php if($answer['is_correct'] >= 0.6): ?>
                                                                        <span class="text-success"><i class="fa fa-check-circle"></i> Pass (<?php echo round($answer['is_correct'] * 100, 1); ?>%)</span>
                                                                    <?php else: ?>
                                                                        <span class="text-danger"><i class="fa fa-times-circle"></i> Fail (<?php echo round($answer['is_correct'] * 100, 1); ?>%)</span>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <span class="text-warning"><i class="fa fa-clock"></i> Pending</span>
                                                                <?php endif; ?>
                                                            </p>
                                                        </div>
                                                        <?php elseif($answer['question_format'] === 'Essay'): ?>
    <p><strong>Essay Question:</strong> <?php echo htmlspecialchars($answer['question_text']); ?></p>
    <p><strong>Point Value:</strong> <span class="badge badge-info"><?php echo $answer['point_value']; ?> points</span></p>
    
    <?php if($answer['essay_answer_template']): ?>
        <div class="answer-section">
            <p><strong>Grading Guidelines/Rubric:</strong></p>
            <div class="well">
                <?php echo nl2br(htmlspecialchars($answer['essay_answer_template'])); ?>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="student-answer">
        <p><strong>Student's Answer:</strong></p>
        <div class="well">
            <?php echo nl2br(htmlspecialchars($answer['selected_answer'])); ?>
        </div>
    </div>
    
    <div class="grading-section">
        <h5>Grade This Answer (<?php echo $answer['point_value']; ?> points possible)</h5>
        
        <?php if(!$answer['is_graded']): ?>
            <div class="form-group">
                <label for="grade_<?php echo $answer['answer_id']; ?>">Score:</label>
                <div class="input-group">
                    <input type="number" class="form-control grade-input" id="grade_<?php echo $answer['answer_id']; ?>" 
                           name="grade_<?php echo $answer['answer_id']; ?>" min="0" max="100" step="1" 
                           required>
                    <span class="input-group-addon">%</span>
                </div>
                <small class="text-muted">Enter a percentage score (0-100). This will be weighted based on the question's point value (<?php echo $answer['point_value']; ?> points).</small>
            </div>
            
            <div class="form-group">
                <label for="feedback_<?php echo $answer['answer_id']; ?>">Feedback:</label>
                <textarea class="form-control" id="feedback_<?php echo $answer['answer_id']; ?>" 
                          name="feedback_<?php echo $answer['answer_id']; ?>" rows="3"></textarea>
            </div>
        <?php else: ?>
            <div class="alert alert-success">
                <p><strong>Graded:</strong> Score: <?php echo round($answer['is_correct'] * 100, 1); ?>% (<?php echo round($answer['is_correct'] * $answer['point_value'], 1); ?> out of <?php echo $answer['point_value']; ?> points)</p>
                <p><strong>Pass/Fail:</strong> <?php echo ($answer['is_correct'] >= 0.6) ? 'Pass' : 'Fail'; ?> (60% threshold)</p>
                <?php if(!empty($answer['instructor_feedback'])): ?>
                    <p><strong>Feedback:</strong> <?php echo nl2br(htmlspecialchars($answer['instructor_feedback'])); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
                                                </div>
                                            <?php endwhile; ?>
                                            
                                            <?php if ($needs_grading): ?>
                                                <div class="needs-grading">
                                                    <p><i class="fa fa-exclamation-triangle"></i> This quiz contains essay questions that need grading.</p>
                                                    <p>Please provide a score and feedback for each essay question.</p>
                                                </div>
                                                
                                                <button type="submit" name="grade_quiz" class="btn btn-primary btn-block">
                                                    <i class="fa fa-save"></i> Save Grades
                                                </button>
                                            <?php elseif(!$student_data['is_completed'] && $quiz['requires_manual_grading']): ?>
                                                <div class="alert alert-warning">
                                                    <p>All essay questions have been graded, but the quiz is not yet marked as complete.</p>
                                                    <button type="submit" name="grade_quiz" class="btn btn-success">
                                                        <i class="fa fa-check-circle"></i> Finalize Grading
                                                    </button>
                                                </div>
                                            <?php else: ?>
                                                <div class="alert alert-success">
                                                    <p><i class="fa fa-check-circle"></i> This quiz has been fully graded.</p>
                                                    <p><strong>Final Score:</strong> <?php echo round($student_data['score'] * 100, 1); ?>%</p>
                                                    <p><strong>Status:</strong> <?php echo ($student_data['score'] >= 0.6) ? 'Pass' : 'Fail'; ?> (60% threshold)</p>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <div class="action-buttons" style="margin-bottom: 30px;">
                                                <a href="instructor-dashboard.php#quizzes" class="btn btn-default">
                                                    <i class="fa fa-arrow-left"></i> Back to Dashboard
                                                </a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <p>Select a student from the list to view and grade their answers.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Score input validation
            // Score input validation
const scoreInputs = document.querySelectorAll('.grade-input');
scoreInputs.forEach(function(input) {
    // Initial validation on page load
    if (input.value === '') {
        input.value = '';  // This line is redundant and should be removed
    }
    
    // Validation on input
    input.addEventListener('input', function() {
        // Remove any non-numeric characters
        this.value = this.value.replace(/[^0-9]/g, '');
        
        // Ensure value is between 0-100
        const val = parseInt(this.value, 10);
        if (isNaN(val)) {
            this.value = '';
        } else if (val < 0) {
            this.value = '0';
        } else if (val > 100) {
            this.value = '100';
        }
    });
});
            
            // Form submission validation
            const form = document.querySelector('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const ungraded = document.querySelectorAll('.grade-input:invalid').length;
                    if (ungraded > 0) {
                        e.preventDefault();
                        alert('Please provide a score for all ungraded questions.');
                        return false;
                    }
                    
                    return confirm('Are you sure you want to submit these grades? This action cannot be undone.');
                });
            }
        });
    </script>
</body>
</html>