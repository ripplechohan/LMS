<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

$success_message = '';
$error_message = '';
$user_data = null;

// Check if user ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid user ID";
    header("Location: admin-dashboard.php");
    exit();
}

$user_id = $_GET['id'];

// Get user data
$stmt = $conn->prepare("SELECT * FROM Users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error_message'] = "User not found";
    header("Location: admin-dashboard.php");
    exit();
}

$user_data = $result->fetch_assoc();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $active = isset($_POST['active']) ? 1 : 0;
    
    // Validate data
    $errors = [];
    
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email is not valid";
    }
    
    if (empty($role) || !in_array($role, ['Admin', 'Instructor', 'Student'])) {
        $errors[] = "Please select a valid role";
    }
    
    // Check if email already exists (excluding current user)
    $stmt = $conn->prepare("SELECT * FROM Users WHERE email = ? AND user_id != ?");
    $stmt->bind_param("si", $email, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $errors[] = "Email already exists in the system";
    }
    
    // If password is provided, validate it
    $password_update = false;
    if (!empty($_POST['password'])) {
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 characters long";
        }
        
        if ($password !== $confirm_password) {
            $errors[] = "Passwords do not match";
        }
        
        $password_update = true;
    }
    
    // Profile image handling (if uploaded)
    $profile_image_update = false;
    $profile_image = $user_data['profile_image']; // Keep existing image by default
    
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['profile_image']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($filetype), $allowed)) {
            $new_filename = uniqid() . '.' . $filetype;
            $upload_dir = 'uploads/profile_images/';
            
            // Create directory if it doesn't exist
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_dir . $new_filename)) {
                // Delete old image if it exists
                if (!empty($user_data['profile_image']) && file_exists($user_data['profile_image'])) {
                    unlink($user_data['profile_image']);
                }
                
                $profile_image = $upload_dir . $new_filename;
                $profile_image_update = true;
            } else {
                $errors[] = "Failed to upload image";
            }
        } else {
            $errors[] = "Invalid file type. Only JPG, JPEG, PNG and GIF are allowed";
        }
    }
    
    // If no errors, proceed with user update
    if (empty($errors)) {
        // Prepare SQL based on what's being updated
        if ($password_update && $profile_image_update) {
            // Update everything including password and image
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE Users SET name = ?, email = ?, password = ?, role = ?, profile_image = ?, active = ? WHERE user_id = ?");
            $stmt->bind_param("sssssii", $name, $email, $hashed_password, $role, $profile_image, $active, $user_id);
        } elseif ($password_update) {
            // Update including password but not image
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE Users SET name = ?, email = ?, password = ?, role = ?, active = ? WHERE user_id = ?");
            $stmt->bind_param("ssssii", $name, $email, $hashed_password, $role, $active, $user_id);
        } elseif ($profile_image_update) {
            // Update including image but not password
            $stmt = $conn->prepare("UPDATE Users SET name = ?, email = ?, role = ?, profile_image = ?, active = ? WHERE user_id = ?");
            $stmt->bind_param("ssssii", $name, $email, $role, $profile_image, $active, $user_id);
        } else {
            // Update without password or image
            $stmt = $conn->prepare("UPDATE Users SET name = ?, email = ?, role = ?, active = ? WHERE user_id = ?");
            $stmt->bind_param("sssii", $name, $email, $role, $active, $user_id);
        }
        
        if ($stmt->execute()) {
            $success_message = "User updated successfully!";
            
            // Set success message in session for redirect
            $_SESSION['success_message'] = $success_message;
            header("Location: admin-dashboard.php");
            exit();
        } else {
            $error_message = "Error updating user: " . $conn->error;
        }
    }
    
    if (!empty($errors)) {
        $error_message = implode("<br>", $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Edit User - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Edit User</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            max-width: 800px;
        }
        .form-title {
            margin-bottom: 30px;
            color: #333;
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .btn-container {
            margin-top: 30px;
            text-align: center;
        }
        .custom-file-label::after {
            content: "Browse";
        }
        .role-info {
            margin-top: 10px;
            font-style: italic;
            color: #6c757d;
        }
        .current-image {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="admin-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Edit User</h2>
            
            <?php if(!empty($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <?php if(!empty($error_message)): ?>
                <div class="alert alert-danger">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="edit_user.php?id=<?php echo $user_id; ?>" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user_data['name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="password">New Password</label>
                            <input type="password" class="form-control" id="password" name="password" minlength="8">
                            <small class="text-muted">Leave blank to keep current password</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" minlength="8">
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="role">User Role <span class="text-danger">*</span></label>
                            <select class="form-control" id="role" name="role" required>
                                <option value="Admin" <?php echo ($user_data['role'] == 'Admin') ? 'selected' : ''; ?>>Admin</option>
                                <option value="Instructor" <?php echo ($user_data['role'] == 'Instructor') ? 'selected' : ''; ?>>Instructor</option>
                                <option value="Student" <?php echo ($user_data['role'] == 'Student') ? 'selected' : ''; ?>>Student</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="active" <?php echo ($user_data['active'] == 1) ? 'checked' : ''; ?>>
                                    Active Account
                                </label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Profile Image</label>
                            
                            <?php if(!empty($user_data['profile_image']) && file_exists($user_data['profile_image'])): ?>
                                <div class="current-image">
                                    <p>Current image:</p>
                                    <img src="<?php echo htmlspecialchars($user_data['profile_image']); ?>" alt="Current Profile" class="img-thumbnail" style="max-height: 150px;">
                                </div>
                            <?php else: ?>
                                <p>No current image</p>
                            <?php endif; ?>
                            
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="profile_image" name="profile_image" accept="image/*">
                                <label class="custom-file-label" for="profile_image">Choose new image</label>
                            </div>
                            <small class="text-muted">Optional. Max file size: 2MB</small>
                        </div>
                        
                        <div class="form-group" id="previewContainer" style="display: none;">
                            <label>New Image Preview</label>
                            <div>
                                <img id="imagePreview" src="#" alt="Profile Preview" class="img-thumbnail" style="max-height: 150px;">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="btn-container">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                    <a href="admin-dashboard.php" class="btn btn-secondary btn-lg">
                        <i class="fas fa-arrow-left"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        // Image preview functionality
        document.getElementById('profile_image').addEventListener('change', function(e) {
            const previewContainer = document.getElementById('previewContainer');
            const imagePreview = document.getElementById('imagePreview');
            const fileInput = e.target;
            
            if (fileInput.files && fileInput.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                
                reader.readAsDataURL(fileInput.files[0]);
            } else {
                previewContainer.style.display = 'none';
            }
        });
        
        // Update custom file input label with filename
        $(".custom-file-input").on("change", function() {
            var fileName = $(this).val().split("\\").pop();
            $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
        });
        
        // Display role information based on selection
        document.getElementById('role').addEventListener('change', function() {
            const roleInfo = document.getElementById('roleInfo');
            const selectedRole = this.value;
            
            if (selectedRole === 'Admin') {
                roleInfo.textContent = 'Administrators have full access to all system features and user management.';
            } else if (selectedRole === 'Instructor') {
                roleInfo.textContent = 'Instructors can create and manage courses, assignments, and grade student work.';
            } else if (selectedRole === 'Student') {
                roleInfo.textContent = 'Students can enroll in courses, submit assignments, and track their progress.';
            } else {
                roleInfo.textContent = '';
            }
        });
    </script>
</body>
</html>