
<?php
session_start();

// Add this session timeout code right after session_start()
// Set timeout duration (30 minutes = 1800 seconds)
$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();

// Continue with your existing code
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="About Us - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>About Us</title>
	
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

</head>
<body class="homepage">
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74" ></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li class="active"><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

   <section id="about-us">
    <div class="container">
        <div class="center wow fadeInDown">
            <h2>About Our Learning Management System</h2>
            <p class="lead">
                Our Online Learning Management System (LMS) is a web-based platform designed to streamline education 
                delivery, enhance the learning experience for students, and support instructors in course management. 
                Developed by Ripple Chohan, Alex Tran, Karan, Mauricio Constancio, and Mahdi Biabanpour Vazvani—
                the system provides a structured and accessible learning environment for academic institutions and 
                professional training organizations.
            </p>
        </div>
        
         <div class="row">
            <div class="col-md-12 text-center">
                <h3>Our Mission</h3>
                <p>
                    Our mission is to create an intuitive, scalable, and efficient learning platform that ensures accessibility, 
                    security, and ease of use for all stakeholders. We aim to optimize course administration, improve student 
                    engagement, and simplify administrative processes.
                </p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12 text-center">
                <h3>Meet Our Team</h3>
                <p>
                    The development of this LMS was a collaborative effort by Ripple Chohan, Alex Tran, Karan, Mauricio Constancio, 
                    and Mahdi Biabanpour Vazvani, who have worked diligently to design and implement an effective e-learning platform. 
                    Our team members specialize in software development, user experience design, database management, and AI integration.
                </p>
            </div>
        </div>
    </div>
</section>
	
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Online Learning Management System | All Rights Reserved</p>
    </footer>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>