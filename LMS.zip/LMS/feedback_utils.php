<?php
/**
 * Marks a student's feedback for regeneration
 *
 * @param int $student_id The ID of the student
 * @return bool Success status
 */
function markFeedbackForRegeneration($student_id) {
    // Create a flag in the session that will be checked by student_dashboard.php
    if (!isset($_SESSION)) {
        session_start();
    }

    // Store this flag in the database to make it persistent
    global $conn;

    // First, check if there's an existing record
    $check_stmt = $conn->prepare("
        SELECT feedback_id FROM StudentFeedback 
        WHERE student_id = ? 
        ORDER BY date_feedback DESC 
        LIMIT 1
    ");
    $check_stmt->bind_param("i", $student_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        // Update the existing record with a flag
        $feedback = $result->fetch_assoc();
        $feedback_id = $feedback['feedback_id'];

        $update_stmt = $conn->prepare("
            UPDATE StudentFeedback 
            SET needs_regeneration = 1 
            WHERE feedback_id = ?
        ");
        $update_stmt->bind_param("i", $feedback_id);
        $update_stmt->execute();
    } else {
        // No existing feedback, nothing to mark
        return false;
    }

    // Also set a session variable as a backup
    $_SESSION['force_feedback_refresh'] = true;

    // Log this event
    error_log("Marked feedback for regeneration for student ID: $student_id");

    return true;
}

/**
 * Checks if a student's feedback needs regeneration
 *
 * @param int $student_id The ID of the student
 * @return bool Whether feedback needs regeneration
 */
function checkFeedbackNeedsRegeneration($student_id) {
    global $conn;

    // First check the session flag (for situations where database wasn't updated)
    if (isset($_SESSION['force_feedback_refresh']) && $_SESSION['force_feedback_refresh']) {
        return true;
    }

    // Then check the database flag
    $check_stmt = $conn->prepare("
        SELECT needs_regeneration FROM StudentFeedback 
        WHERE student_id = ? 
        ORDER BY date_feedback DESC 
        LIMIT 1
    ");
    $check_stmt->bind_param("i", $student_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        $feedback = $result->fetch_assoc();
        return (bool)$feedback['needs_regeneration'];
    }

    // If no feedback exists, we should generate one
    return true;
}

/**
 * Clears the regeneration flag for a student's feedback
 *
 * @param int $student_id The ID of the student
 * @return bool Success status
 */
function clearFeedbackRegenerationFlag($student_id) {
    global $conn;

    // Clear the session flag
    if (isset($_SESSION['force_feedback_refresh'])) {
        unset($_SESSION['force_feedback_refresh']);
    }

    // Clear the database flag
    $update_stmt = $conn->prepare("
        UPDATE StudentFeedback 
        SET needs_regeneration = 0 
        WHERE student_id = ?
        ORDER BY date_feedback DESC 
        LIMIT 1
    ");
    $update_stmt->bind_param("i", $student_id);
    $result = $update_stmt->execute();

    // Log this event
    error_log("Cleared feedback regeneration flag for student ID: $student_id");

    return $result;
}
?>