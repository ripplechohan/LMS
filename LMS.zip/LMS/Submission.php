<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Student') {
    header("Location: login.php");
    exit();
}

// Get student data
$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['name'];

// Check if assignment ID is provided
if (!isset($_GET['id'])) {
    $_SESSION['error_message'] = "No assignment specified.";
    header("Location: student-dashboard.php");
    exit();
}

$assignment_id = $_GET['id'];

// Fetch assignment details
$stmt = $conn->prepare("
    SELECT a.assignment_id, a.title, a.description, a.due_date, 
           c.title as course_title
    FROM Assignments a
    JOIN Courses c ON a.course_id = c.course_id
    WHERE a.assignment_id = ?
");
$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $_SESSION['error_message'] = "Assignment not found.";
    header("Location: student-dashboard.php");
    exit();
}

$assignment = $result->fetch_assoc();

// Check if student is enrolled in the course
$stmt = $conn->prepare("
    SELECT e.enrollment_id 
    FROM Enrollments e
    JOIN Assignments a ON e.course_id = a.course_id
    WHERE e.student_id = ? AND a.assignment_id = ?
");
$stmt->bind_param("ii", $student_id, $assignment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $_SESSION['error_message'] = "You are not enrolled in this course.";
    header("Location: student-dashboard.php");
    exit();
}

// Check if assignment is already submitted
$stmt = $conn->prepare("
    SELECT submission_id, submission_url, date_submitted 
    FROM Submissions 
    WHERE student_id = ? AND assignment_id = ?
");
$stmt->bind_param("ii", $student_id, $assignment_id);
$stmt->execute();
$result = $stmt->get_result();
$existing_submission = null;

if ($result->num_rows > 0) {
    $existing_submission = $result->fetch_assoc();
}

// Process form submission
$submission_successful = false;
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comments = isset($_POST['comments']) ? trim($_POST['comments']) : "";
    $submission_url = "";
    
    // Check if file is uploaded
    if (isset($_FILES['submission_file']) && $_FILES['submission_file']['error'] == 0) {
        $allowed_types = array('application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain');
        $file_type = $_FILES['submission_file']['type'];
        
        if (!in_array($file_type, $allowed_types)) {
            $error_message = "Invalid file type. Please upload a PDF, DOCX, or TXT file.";
        } else {
            // Create uploads directory if it doesn't exist
            $upload_dir = "uploads/assignments/";
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Generate unique filename
            $file_extension = pathinfo($_FILES['submission_file']['name'], PATHINFO_EXTENSION);
            $unique_filename = "submission_" . $student_id . "_" . $assignment_id . "_" . time() . "." . $file_extension;
            $submission_url = $upload_dir . $unique_filename;
            
            // Move uploaded file
            if (move_uploaded_file($_FILES['submission_file']['tmp_name'], $submission_url)) {
                // Insert or update submission in database
                if ($existing_submission) {
                    // Update existing submission
                    $stmt = $conn->prepare("
                        UPDATE Submissions 
                        SET submission_url = ?, date_submitted = NOW() 
                        WHERE submission_id = ?
                    ");
                    $stmt->bind_param("si", $submission_url, $existing_submission['submission_id']);
                } else {
                    // Get due date from assignment
                    $due_date = $assignment['due_date'];
                    
                    // Insert new submission
                    $stmt = $conn->prepare("
                        INSERT INTO Submissions (student_id, assignment_id, submission_url, date_submitted, due_date) 
                        VALUES (?, ?, ?, NOW(), ?)
                    ");
                    $stmt->bind_param("isss", $student_id, $assignment_id, $submission_url, $due_date);
                }
                
                if ($stmt->execute()) {
                    $submission_successful = true;
                    $_SESSION['success_message'] = "Assignment submitted successfully!";
                    header("Location: student-dashboard.php");
                    exit();
                } else {
                    $error_message = "Database error: " . $conn->error;
                }
            } else {
                $error_message = "Failed to upload file. Please try again.";
            }
        }
    } else if ($_FILES['submission_file']['error'] == 4) {
        // If no file uploaded, show error
        $error_message = "Please upload a file to submit your assignment.";
    } else {
        $error_message = "File upload error: " . $_FILES['submission_file']['error'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Submit Assignment - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Submit Assignment | LMS</title>
    
    <!-- Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .submission-container {
            max-width: 800px;
            margin: 50px auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        .assignment-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #007bff;
        }
        .existing-submission {
            background: #e8f4ff;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        .file-upload-container {
            border: 2px dashed #ccc;
            border-radius: 5px;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        .file-upload-container:hover, .file-upload-container.dragover {
            border-color: #007bff;
            background-color: #f8f9fa;
        }
        .file-upload-text {
            display: block;
            margin-bottom: 10px;
            font-size: 16px;
        }
        .file-upload-btn {
            display: inline-block;
            background: #007bff;
            color: white;
            padding: 8px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .file-upload-btn:hover {
            background: #0069d9;
        }
        #file-name {
            margin-top: 10px;
            font-style: italic;
        }
        .countdown {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            font-weight: bold;
            text-align: center;
        }
        .due-passed {
            background-color: #f8d7da;
            color: #721c24;
        }
        .due-close {
            background-color: #fff3cd;
            color: #856404;
        }
        .due-good {
            background-color: #d4edda;
            color: #155724;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="student-dashboard.php">Dashboard</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="submission-container">
        <h2>Submit Assignment</h2>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <div class="assignment-info">
            <h4><?php echo htmlspecialchars($assignment['title']); ?></h4>
            <p><strong>Course:</strong> <?php echo htmlspecialchars($assignment['course_title']); ?></p>
            <p><strong>Due Date:</strong> <?php echo date('F j, Y, g:i a', strtotime($assignment['due_date'])); ?></p>
            
            <?php
            $now = new DateTime();
            $due_date = new DateTime($assignment['due_date']);
            $time_left = $now->diff($due_date);
            $days_left = $time_left->days;
            
            // Set status class based on time remaining
            $status_class = 'due-good';
            if ($now > $due_date) {
                $status_class = 'due-passed';
            } elseif ($days_left <= 1) {
                $status_class = 'due-close';
            }
            
            if ($now > $due_date):
            ?>
                <div class="countdown <?php echo $status_class; ?>">
                    <i class="fas fa-exclamation-triangle"></i> 
                    Assignment is past due. Late submissions may be penalized.
                </div>
            <?php elseif ($days_left <= 1): ?>
                <div class="countdown <?php echo $status_class; ?>">
                    <i class="fas fa-clock"></i> 
                    <?php if ($time_left->h > 0 || $time_left->i > 0): ?>
                        Time remaining: <?php echo $time_left->h; ?> hours and <?php echo $time_left->i; ?> minutes
                    <?php else: ?>
                        Due today!
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="countdown <?php echo $status_class; ?>">
                    <i class="fas fa-calendar-check"></i> 
                    Time remaining: <?php echo $days_left; ?> days
                </div>
            <?php endif; ?>
            
            <p><strong>Description:</strong></p>
            <div class="well">
                <?php echo nl2br(htmlspecialchars($assignment['description'])); ?>
            </div>
        </div>
        
        <?php if ($existing_submission): ?>
            <div class="existing-submission">
                <h4><i class="fas fa-check-circle"></i> You have already submitted this assignment</h4>
                <p><strong>Submitted on:</strong> <?php echo date('F j, Y, g:i a', strtotime($existing_submission['date_submitted'])); ?></p>
                
                <?php if (!empty($existing_submission['submission_url'])): ?>
                    <p><strong>Uploaded file:</strong> 
                        <a href="<?php echo $existing_submission['submission_url']; ?>" target="_blank">
                            <?php echo basename($existing_submission['submission_url']); ?>
                        </a>
                    </p>
                <?php endif; ?>
                
                <p class="text-info">
                    <i class="fas fa-info-circle"></i> You can update your submission below if needed. 
                    Your previous submission will be replaced.
                </p>
            </div>
        <?php endif; ?>
        
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="submission_file">Upload Assignment File</label>
                <div class="file-upload-container" id="drop-area">
                    <span class="file-upload-text">
                        <i class="fas fa-cloud-upload-alt fa-2x mb-2"></i><br>
                        Drag & drop your file here or
                    </span>
                    <label for="submission_file" class="file-upload-btn">
                        <i class="fas fa-file-upload"></i> Choose File
                    </label>
                    <input type="file" id="submission_file" name="submission_file" style="display: none;" 
                           accept=".pdf, .docx, .doc, .txt">
                    <div id="file-name"></div>
                </div>
                <small class="form-text text-muted">
                    Accepted file types: PDF, Word Document (.docx, .doc), Text File (.txt)
                </small>
            </div>
            
            <!-- Removed comments section as it doesn't exist in the database schema -->
            
            <div class="form-group text-center">
                <button type="submit" class="btn btn-success btn-lg">
                    <?php echo $existing_submission ? '<i class="fas fa-sync-alt"></i> Update Submission' : '<i class="fas fa-paper-plane"></i> Submit Assignment'; ?>
                </button>
                <a href="student-dashboard.php" class="btn btn-default btn-lg">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </form>
    </div>
    
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Online Learning Management System | All Rights Reserved</p>
    </footer>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        // File upload handling
        document.getElementById('submission_file').addEventListener('change', function(e) {
            var fileName = e.target.files[0] ? e.target.files[0].name : 'No file selected';
            document.getElementById('file-name').textContent = fileName;
        });
        
        // Drag and drop functionality
        const dropArea = document.getElementById('drop-area');
        
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        ['dragenter', 'dragover'].forEach(eventName => {
            dropArea.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, unhighlight, false);
        });
        
        function highlight() {
            dropArea.classList.add('dragover');
        }
        
        function unhighlight() {
            dropArea.classList.remove('dragover');
        }
        
        dropArea.addEventListener('drop', handleDrop, false);
        
        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            document.getElementById('submission_file').files = files;
            
            var fileName = files[0] ? files[0].name : 'No file selected';
            document.getElementById('file-name').textContent = fileName;
        }
    </script>
</body>
</html>