<?php
session_start();
include 'db_connection.php';

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();



// Check if user is logged in
$logged_in = isset($_SESSION['user_id']);
$user_role = $logged_in ? $_SESSION['role'] : '';
$user_name = $logged_in ? $_SESSION['name'] : '';

// Get filter parameters
$category_filter = isset($_GET['category']) ? $_GET['category'] : '';
$level_filter = isset($_GET['level']) ? $_GET['level'] : '';
$search_filter = isset($_GET['search']) ? $_GET['search'] : '';
$prereq_filter = isset($_GET['prerequisite']) ? $_GET['prerequisite'] : ''; // New prerequisite filter



// Display error messages from session
if (isset($_SESSION['error_message'])) {
    echo '<div class="alert alert-danger alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            ' . $_SESSION['error_message'] . '
          </div>';
    unset($_SESSION['error_message']); // Clear the message after displaying it
}

// Display success messages from session
if (isset($_SESSION['success_message'])) {
    echo '<div class="alert alert-success alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            ' . $_SESSION['success_message'] . '
          </div>';
    unset($_SESSION['success_message']); // Clear the message after displaying it
}

// Display info messages from session
if (isset($_SESSION['info_message'])) {
    echo '<div class="alert alert-info alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            ' . $_SESSION['info_message'] . '
          </div>';
    unset($_SESSION['info_message']); // Clear the message after displaying it
}

// Base query
$query = "
    SELECT c.course_id, c.title, c.description, c.category, c.skill_level, 
           c.prereq_course_id, pc.title as prereq_title, u.name as instructor_name 
    FROM Courses c
    LEFT JOIN Users u ON c.instructor_id = u.user_id
    LEFT JOIN Courses pc ON c.prereq_course_id = pc.course_id
    WHERE c.is_active = 1
";

// Add filters to query
$params = [];
$types = '';

if (!empty($category_filter)) {
    $query .= " AND c.category = ?";
    $params[] = $category_filter;
    $types .= 's';
}

if (!empty($level_filter)) {
    $query .= " AND c.skill_level = ?";
    $params[] = $level_filter;
    $types .= 's';
}

if (!empty($search_filter)) {
    $query .= " AND (c.title LIKE ? OR c.description LIKE ?)";
    $params[] = "%$search_filter%";
    $params[] = "%$search_filter%";
    $types .= 'ss';
}

// Handle prerequisite filter
if (!empty($prereq_filter)) {
    if ($prereq_filter === 'none') {
        $query .= " AND c.prereq_course_id IS NULL";
    } else if ($prereq_filter === 'any') {
        $query .= " AND c.prereq_course_id IS NOT NULL";
    } else {
        // Filter by specific prerequisite course
        $query .= " AND c.prereq_course_id = ?";
        $params[] = $prereq_filter;
        $types .= 'i';
    }
}

$query .= " ORDER BY c.title";

// Prepare and execute query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$courses = $stmt->get_result();

// Get enrolled courses for students
// Get enrolled courses for students (active enrollments only)

// Get enrolled and dropped courses for students
$enrolled_courses = [];
$dropped_courses = [];
if ($logged_in && $user_role == 'Student') {
    $student_id = $_SESSION['user_id'];
    
    // Get active enrollments
    $stmt = $conn->prepare("
        SELECT course_id 
        FROM Enrollments 
        WHERE student_id = ? AND status = 'Enrolled'
    ");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $enrolled_courses[] = $row['course_id'];
    }
    
    // Get dropped enrollments
    $stmt = $conn->prepare("
        SELECT course_id 
        FROM Enrollments 
        WHERE student_id = ? AND status = 'Dropped'
    ");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $dropped_courses[] = $row['course_id'];
    }
}

// Get all categories for filter dropdown
$stmt = $conn->query("SELECT DISTINCT category FROM Courses WHERE category IS NOT NULL AND category != '' ORDER BY category");
$categories = $stmt->fetch_all(MYSQLI_ASSOC);

// Get all courses for prerequisite dropdown
$stmt = $conn->query("SELECT course_id, title FROM Courses WHERE is_active = 1 ORDER BY title");
$prereq_courses = $stmt->fetch_all(MYSQLI_ASSOC);
?>
<!-- Add this code after the filters section, before displaying courses -->
<?php
// Display messages for dropout status
if (isset($_GET['dropout'])) {
    if ($_GET['dropout'] === 'success') {
        echo '<div class="alert alert-success alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <strong>Success!</strong> You have successfully dropped the course.
              </div>';
    } elseif ($_GET['dropout'] === 'error') {
        echo '<div class="alert alert-danger alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <strong>Error!</strong> There was a problem dropping the course. Please try again.
              </div>';
    } elseif ($_GET['dropout'] === 'not_enrolled') {
        echo '<div class="alert alert-warning alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <strong>Warning!</strong> You are not enrolled in this course.
              </div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Courses - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Courses | LMS</title>
    
    <!-- Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        body {
            background-color: white;
        }
        
        h1 {
            text-align: center;
            font-weight: bold;
            margin-bottom: 30px;
        }
        .course-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-top: 30px;
            margin-bottom: 50px;
        }
        .course-card {
            width: 350px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
            background: white;
        }
        .course-card:hover {
            transform: translateY(-10px);
            box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.15);
        }
        .course-header {
            background-color: #007bff;
            color: white;
            padding: 15px;
            text-align: center;
            font-weight: bold;
            font-size: 18px;
        }
        .course-content {
            padding: 20px;
        }
        .course-description {
            color: #555;
            margin-bottom: 15px;
            min-height: 80px;
        }
        .course-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #f8f9fa;
            border-top: 1px solid #eee;
        }
        .course-meta {
            display: flex;
            flex-direction: column;
        }
        .course-level {
            font-size: 14px;
            color: #6c757d;
        }
        .course-category {
            font-size: 14px;
            font-weight: bold;
            color: #343a40;
        }
        .course-prereq {
            font-size: 13px;
            color: #6c757d;
            margin-top: 5px;
        }
        .btn-enroll {
            padding: 8px 20px;
            font-weight: bold;
        }
        .already-enrolled {
            background-color: #28a745;
            color: white;
        }
        .course-filters {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .filter-title {
            font-weight: bold;
            margin-bottom: 15px;
            color: #343a40;
        }
        .filter-group {
            margin-bottom: 15px;
        }
        .no-courses {
            text-align: center;
            padding: 50px;
            font-size: 18px;
            color: #6c757d;
        }
        footer {
            margin-top: 50px;
        }
        .filter-heading {
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 18px;
            color: #333;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        .search-group {
            margin-bottom: 15px;
        }
        .form-buttons {
            display: flex;
            gap: 10px;
        }
        .form-buttons button {
            flex: 1;
        }
        .btn-dropout {
    margin-top: 5px;
    background-color: #dc3545;
    color: white;
}
.btn-dropout:hover {
    background-color: #bd2130;
    color: white;
}
.course-footer div {
    display: flex;
    flex-direction: column;
}
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="LMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li class="active"><a href="courses.php">Courses</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    
                    <?php if($logged_in): ?>
                        <?php if($user_role == 'Admin'): ?>
                            <li><a href="admin-dashboard.php">Dashboard</a></li>
                        <?php elseif($user_role == 'Instructor'): ?>
                            <li><a href="instructor-dashboard.php">Dashboard</a></li>
                        <?php elseif($user_role == 'Student'): ?>
                            <li><a href="student-dashboard.php">Dashboard</a></li>
                        <?php endif; ?>
                        <li><a href="profile.php">Profile</a></li>
                        <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a class="btn btn-primary" href="login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Available Courses</h1>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <div class="course-filters">
                        <h4 class="filter-heading">Filter Courses</h4>
                        
                        <!-- Form-based filtering approach -->
                        <form method="GET" action="courses.php">
                            <div class="filter-group">
                                <label for="category">Category:</label>
                                <select class="form-control" id="category" name="category">
                                    <option value="">All Categories</option>
                                    <?php foreach($categories as $cat): ?>
                                        <option value="<?php echo htmlspecialchars($cat['category']); ?>" 
                                            <?php echo ($category_filter === $cat['category']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($cat['category']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="level">Skill Level:</label>
                                <select class="form-control" id="level" name="level">
                                    <option value="">All Levels</option>
                                    <option value="Beginner" <?php echo ($level_filter === 'Beginner') ? 'selected' : ''; ?>>Beginner</option>
                                    <option value="Intermediate" <?php echo ($level_filter === 'Intermediate') ? 'selected' : ''; ?>>Intermediate</option>
                                    <option value="Advanced" <?php echo ($level_filter === 'Advanced') ? 'selected' : ''; ?>>Advanced</option>
                                </select>
                            </div>
                            
                            <!-- New prerequisite filter -->
                            <div class="filter-group">
                                <label for="prerequisite">Prerequisites:</label>
                                <select class="form-control" id="prerequisite" name="prerequisite">
                                    <option value="">All Courses</option>
                                    <option value="none" <?php echo ($prereq_filter === 'none') ? 'selected' : ''; ?>>No Prerequisites</option>
                                    <option value="any" <?php echo ($prereq_filter === 'any') ? 'selected' : ''; ?>>Has Prerequisites</option>
                                    <!-- Individual prerequisite courses -->
                                    <optgroup label="Specific Prerequisite">
                                        <?php foreach($prereq_courses as $prereq): ?>
                                            <option value="<?php echo $prereq['course_id']; ?>" 
                                                <?php echo ($prereq_filter === (string)$prereq['course_id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($prereq['title']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="search">Search:</label>
                                <input type="text" class="form-control" id="search" name="search" 
                                    placeholder="Search courses..." value="<?php echo htmlspecialchars($search_filter); ?>">
                            </div>
                            
                            <div class="form-buttons">
                                <button type="submit" class="btn btn-primary">Apply Filters</button>
                                <a href="courses.php" class="btn btn-default">Reset</a>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="col-md-9">
                    <div class="course-container" id="courseContainer">
                        <?php if ($courses->num_rows > 0): ?>
                            <?php while($course = $courses->fetch_assoc()): ?>
                                <div class="course-card">
                                    <div class="course-header">
                                        <?php echo htmlspecialchars($course['title']); ?>
                                    </div>
                                    <div class="course-content">
                                        <div class="course-description">
                                            <?php 
                                            if (!empty($course['description'])) {
                                                echo htmlspecialchars(substr($course['description'], 0, 150)) . (strlen($course['description']) > 150 ? '...' : '');
                                            } else {
                                                echo 'No description available for this course.';
                                            }
                                            ?>
                                        </div>
                                        <p><small>Instructor: <?php echo htmlspecialchars($course['instructor_name'] ?? 'Not Assigned'); ?></small></p>
                                        <!-- Show prerequisite information -->
                                        <?php if (!empty($course['prereq_course_id'])): ?>
                                            <p class="course-prereq">
                                                <i class="fa fa-arrow-circle-right"></i> 
                                                Prerequisite: <?php echo htmlspecialchars($course['prereq_title']); ?>
                                            </p>
                                        <?php else: ?>
                                            <p class="course-prereq">
                                                <i class="fa fa-check-circle"></i> No prerequisites
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="course-footer">
                                        <div class="course-meta">
                                            <span class="course-category"><?php echo !empty($course['category']) ? htmlspecialchars($course['category']) : 'General'; ?></span>
                                            <span class="course-level"><?php echo htmlspecialchars($course['skill_level'] ?? 'Not specified'); ?></span>
                                        </div>
                                        <?php if ($logged_in && $user_role == 'Student'): ?>
    <?php if (in_array($course['course_id'], $enrolled_courses)): ?>
        <div class="btn-actions">
            <a href="course-details.php?id=<?php echo $course['course_id']; ?>" class="btn btn-success btn-enrolled">
                <i class="fa fa-check"></i> Enrolled
            </a>
            <a href="dropout.php?id=<?php echo $course['course_id']; ?>" class="btn btn-dropout" 
               onclick="return confirm('Are you sure you want to drop this course? You will lose access and cannot enroll again.');">
                <i class="fa fa-times"></i> Drop Out
            </a>
        </div>
    <?php elseif (in_array($course['course_id'], $dropped_courses)): ?>
        <button class="btn btn-secondary" disabled>
            <i class="fa fa-ban"></i> Dropped
        </button>
    <?php else: ?>
        <a href="enroll.php?id=<?php echo $course['course_id']; ?>" class="btn btn-primary btn-enroll">
            Enroll Now
        </a>
    <?php endif; ?>
<?php elseif ($logged_in && $user_role == 'Instructor'): ?>
    <a href="course-details.php?id=<?php echo $course['course_id']; ?>" class="btn btn-info btn-enroll">
        View Details
    </a>
<?php else: ?>
    <a href="<?php echo $logged_in ? 'course-details.php?id=' . $course['course_id'] : 'login.php'; ?>" class="btn btn-primary btn-enroll">
        <?php echo $logged_in ? 'View Details' : 'Login to Enroll'; ?>
    </a>
<?php endif; ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                            
                            <?php if ($courses->num_rows === 0): ?>
                                <div class="no-courses">
                                    <i class="fa fa-filter fa-3x mb-3"></i>
                                    <p>No courses match your filter criteria.</p>
                                    <p><a href="courses.php" class="btn btn-primary">Reset Filters</a></p>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="no-courses">
                                <i class="fa fa-book fa-3x mb-3"></i>
                                <p>No courses are available at the moment.</p>
                                <p>Please check back later or contact an administrator.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Online Learning Management System | All Rights Reserved</p>
    </footer>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>