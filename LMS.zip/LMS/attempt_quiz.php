<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has the right role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Student') {
    header("Location: login.php");
    exit();
}

// Get student data
$student_id = $_SESSION['user_id'];

// Check if quiz ID was actually passed through
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $quiz_id = $_GET['id'];
} else {
    $_SESSION['error_message'] = "No quiz selected.";
    header("Location: student-dashboard.php");
    exit();
}

// Check if student has already completed this quiz
$stmt = $conn->prepare("
    SELECT student_quiz_id 
    FROM StudentQuizzes 
    WHERE student_id = ? AND quiz_id = ? AND is_completed = 1
");
$stmt->bind_param("ii", $student_id, $quiz_id);
$stmt->execute();
$completed_result = $stmt->get_result();

if ($completed_result->num_rows > 0) {
    $_SESSION['error_message'] = "You have already completed this quiz.";
    header("Location: student-dashboard.php#quizzes");
    exit();
}

// Check if a quiz session already exists and is in progress
$stmt = $conn->prepare("
    SELECT student_quiz_id, started_at 
    FROM StudentQuizzes 
    WHERE student_id = ? AND quiz_id = ? AND is_completed = 0
");
$stmt->bind_param("ii", $student_id, $quiz_id);
$stmt->execute();
$in_progress_result = $stmt->get_result();
$is_quiz_in_progress = ($in_progress_result->num_rows > 0);
$quiz_start_time = null;

if ($is_quiz_in_progress) {
    // Quiz already in progress, get the start time
    $quiz_session = $in_progress_result->fetch_assoc();
    $quiz_start_time = strtotime($quiz_session['started_at']);
}

// Get quiz information including time limit
$stmt = $conn->prepare("SELECT q.title, c.title as course_title, q.is_published, q.requires_manual_grading, q.time_limit 
                        FROM Quizzes q 
                        JOIN Courses c ON q.course_id = c.course_id 
                        WHERE q.quiz_id = ?");
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$quiz_info = $stmt->get_result()->fetch_assoc();

// Calculate remaining time if time limit is set
$time_limit_seconds = null;
$remaining_seconds = null;

if ($quiz_info && $quiz_info['time_limit']) {
    $time_limit_seconds = $quiz_info['time_limit'] * 60; // convert minutes to seconds
    
    if ($is_quiz_in_progress) {
        // Calculate remaining time for an in-progress quiz
        $elapsed_seconds = time() - $quiz_start_time;
        $remaining_seconds = max(0, $time_limit_seconds - $elapsed_seconds);
    } else {
        // For a new quiz, the full time is available
        $remaining_seconds = $time_limit_seconds;
    }
}

// Check if a quiz is in progress and time has expired
if ($is_quiz_in_progress && $quiz_info && $quiz_info['time_limit']) {
    $time_limit_seconds = $quiz_info['time_limit'] * 60; // convert minutes to seconds
    $elapsed_seconds = time() - $quiz_start_time;
    $remaining_seconds = max(0, $time_limit_seconds - $elapsed_seconds);
    
    // If time has expired and no POST submission has been made yet
    if ($remaining_seconds <= 0 && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        // Create a hidden form and auto-submit it
        echo '<!DOCTYPE html>
        <html>
        <head>
            <title>Submitting Quiz...</title>
            <script>
                window.onload = function() {
                    document.getElementById("auto-submit-form").submit();
                }
            </script>
        </head>
        <body>
            <h3>Time\'s up! Submitting your quiz...</h3>
            <form id="auto-submit-form" action="attempt_quiz.php?id=' . $quiz_id . '" method="POST">
                <input type="hidden" name="time_expired" value="1">';
        
        // Get all questions for this quiz to include them in the auto-submit
        $stmt = $conn->prepare("SELECT question_id, question_format FROM Questions WHERE quiz_id = ?");
        $stmt->bind_param("i", $quiz_id);
        $stmt->execute();
        $auto_questions_result = $stmt->get_result();
        
        // Fetch answers the student has already provided (if any)
        $stmt = $conn->prepare("
            SELECT q.question_id, q.question_format, sqa.selected_answer
            FROM Questions q
            LEFT JOIN StudentQuizAnswers sqa ON q.question_id = sqa.question_id
            LEFT JOIN StudentQuizzes sq ON sqa.student_quiz_id = sq.student_quiz_id
            WHERE q.quiz_id = ? AND (sq.student_id = ? OR sq.student_id IS NULL)
        ");
        $stmt->bind_param("ii", $quiz_id, $student_id);
        $stmt->execute();
        $saved_answers = $stmt->get_result();
        
        // Create a map of question_id to selected_answer
        $answer_map = [];
        while ($saved_answer = $saved_answers->fetch_assoc()) {
            $answer_map[$saved_answer['question_id']] = $saved_answer['selected_answer'];
        }
        
        // Add all questions to the form
        while ($question = $auto_questions_result->fetch_assoc()) {
            $q_id = $question['question_id'];
            $q_format = $question['question_format'];
            $answer_key = "question_" . $q_id;
            
            // Include answers that were already saved
            if (isset($answer_map[$q_id])) {
                echo '<input type="hidden" name="' . $answer_key . '" value="' . htmlspecialchars($answer_map[$q_id]) . '">';
            } else {
                // For questions with no saved answer, provide empty answers to avoid validation issues
                // For essay, provide an empty string
                if ($q_format == 'Essay') {
                    echo '<input type="hidden" name="' . $answer_key . '" value="">';
                } 
                // For MCQ and True/False, provide a default value
                else if ($q_format == 'MCQ') {
                    echo '<input type="hidden" name="' . $answer_key . '" value="A">'; // Default to A
                } 
                else if ($q_format == 'True/False') {
                    echo '<input type="hidden" name="' . $answer_key . '" value="False">'; // Default to False
                }
            }
        }
        
        echo '<input type="hidden" name="submit_quiz" value="1">
            </form>
            <p>Please wait while we process your submission...</p>
        </body>
        </html>';
        exit();
    }
}

// Process quiz submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if submission is due to timer expiration or normal submit button
    $time_expired = isset($_POST['time_expired']) ? true : false;
    
    if (isset($_POST['submit_quiz']) || $time_expired) {
        // Log for debugging purposes
        error_log("Quiz submitted. Time expired: " . ($time_expired ? "Yes" : "No"));
        
        // Check if quiz requires manual grading (has essay questions)
        $stmt = $conn->prepare("SELECT requires_manual_grading FROM Quizzes WHERE quiz_id = ?");
        $stmt->bind_param("i", $quiz_id);
        $stmt->execute();
        $quiz_result = $stmt->get_result();
        $quiz_data = $quiz_result->fetch_assoc();
        $requires_manual_grading = $quiz_data['requires_manual_grading'];

        // Create a new student quiz record if one doesn't exist
        if (!$is_quiz_in_progress) {
            $stmt = $conn->prepare("
                INSERT INTO StudentQuizzes (student_id, quiz_id, total_questions)
                VALUES (?, ?, (SELECT COUNT(*) FROM Questions WHERE quiz_id = ?))
            ");
            $stmt->bind_param("iii", $student_id, $quiz_id, $quiz_id);
            $stmt->execute();
            
            // Get the ID of the inserted student quiz
            $student_quiz_id = $conn->insert_id;
        } else {
            // If a quiz is already in progress, use the existing student_quiz_id
            $student_quiz_id = $quiz_session['student_quiz_id'];
        }
        
        // Get all questions for this quiz
        $stmt = $conn->prepare("SELECT question_id, answer, question_format FROM Questions WHERE quiz_id = ?");
        $stmt->bind_param("i", $quiz_id);
        $stmt->execute();
        $questions_result = $stmt->get_result();
        
        $score = 0;
        $total_questions = $questions_result->num_rows;
        $total_gradable_questions = 0; // Questions that can be auto-graded
        
        // Process each answer
        while ($question = $questions_result->fetch_assoc()) {
            $question_id = $question['question_id'];
            $answer_key = "question_" . $question_id;
            $question_format = $question['question_format'];
            
            if (isset($_POST[$answer_key])) {
                $selected_answer = trim($_POST[$answer_key]);
                
                // Get the correct answer
                $correct_answer = trim($question['answer']);
                
                // Check if the answer is correct using strict comparison
                $is_correct = 0;
                $is_graded = 1; // Default is graded for MCQ and True/False
                
                if ($question_format == 'MCQ') {
                    // For MCQs, we need to match exactly the option letter (A, B, C, D)
                    $is_correct = ($selected_answer === $correct_answer) ? 1 : 0;
                    $total_gradable_questions++;
                } else if ($question_format == 'True/False') {
                    // For True/False, standardize the comparison
                    $is_correct = (strtolower($selected_answer) === strtolower($correct_answer)) ? 1 : 0;
                    $total_gradable_questions++;
                } else if ($question_format == 'Essay') {
                    // Essay questions can't be auto-graded
                    $is_correct = NULL; // Set to NULL as it will be graded later
                    $is_graded = 0; // Mark as not graded
                }
                
                if ($is_correct === 1) {
                    $score++;
                }
                
                // Check if this answer has already been saved
                $check_stmt = $conn->prepare("
                    SELECT answer_id 
                    FROM StudentQuizAnswers 
                    WHERE student_quiz_id = ? AND question_id = ?
                ");
                $check_stmt->bind_param("ii", $student_quiz_id, $question_id);
                $check_stmt->execute();
                $check_result = $check_stmt->get_result();
                
                if ($check_result->num_rows > 0) {
                    // Update existing answer
                    if ($question_format == 'Essay') {
                        $update_stmt = $conn->prepare("
                            UPDATE StudentQuizAnswers 
                            SET selected_answer = ?, is_correct = NULL, is_graded = 0
                            WHERE student_quiz_id = ? AND question_id = ?
                        ");
                        $update_stmt->bind_param("sii", $selected_answer, $student_quiz_id, $question_id);
                    } else {
                        $update_stmt = $conn->prepare("
                            UPDATE StudentQuizAnswers 
                            SET selected_answer = ?, is_correct = ?, is_graded = 1
                            WHERE student_quiz_id = ? AND question_id = ?
                        ");
                        $update_stmt->bind_param("siii", $selected_answer, $is_correct, $student_quiz_id, $question_id);
                    }
                    $update_stmt->execute();
                } else {
                    // Save the student's answer with instructor feedback field for essays
                    if ($question_format == 'Essay') {
                        $stmt = $conn->prepare("
                            INSERT INTO StudentQuizAnswers (student_quiz_id, question_id, selected_answer, is_correct, is_graded)
                            VALUES (?, ?, ?, NULL, 0)
                        ");
                        $stmt->bind_param("iis", $student_quiz_id, $question_id, $selected_answer);
                    } else {
                        $stmt = $conn->prepare("
                            INSERT INTO StudentQuizAnswers (student_quiz_id, question_id, selected_answer, is_correct, is_graded)
                            VALUES (?, ?, ?, ?, 1)
                        ");
                        $stmt->bind_param("iisi", $student_quiz_id, $question_id, $selected_answer, $is_correct);
                    }
                    $stmt->execute();
                }
            }
        }
        
        // Determine quiz completion status based on if it needs manual grading
        $is_completed = $requires_manual_grading ? 0 : 1;
        
        // Calculate the decimal score (as a percentage from 0.0 to 1.0)
        $decimal_score = ($total_gradable_questions > 0) ? $score / $total_gradable_questions : 0;
        
        // Update the student quiz record with the score and completion status
        if ($requires_manual_grading) {
            // If there are essay questions, mark as waiting for grading
            $stmt = $conn->prepare("
                UPDATE StudentQuizzes
                SET score = ?, is_completed = 0, completed_at = NOW()
                WHERE student_quiz_id = ?
            ");
        } else {
            // If only objective questions, mark as completed
            $stmt = $conn->prepare("
                UPDATE StudentQuizzes
                SET score = ?, is_completed = 1, completed_at = NOW()
                WHERE student_quiz_id = ?
            ");
        }
        $stmt->bind_param("di", $decimal_score, $student_quiz_id);
        $stmt->execute();
        
        // Only generate feedback if all questions can be graded automatically
        if (!$requires_manual_grading) {
            // Generate AI feedback for the completed quiz
            include_once 'generate_ai_feedback.php';
            
            // Fetch quiz title and topic for better feedback
            $stmt = $conn->prepare("
                SELECT q.title, q.topic 
                FROM Quizzes q 
                WHERE q.quiz_id = ?
            ");
            $stmt->bind_param("i", $quiz_id);
            $stmt->execute();
            $quiz_data = $stmt->get_result()->fetch_assoc();
            
            // Prepare data for feedback generation
            $feedback_data = [
                'student_name' => $_SESSION['name'],
                'score' => $score,
                'total_questions' => $total_questions,
                'percentage' => ($total_questions > 0) ? round(($score / $total_questions) * 100) : 0,
                'strong_areas' => [], // Will populate below
                'weak_areas' => [], // Will populate below
                'quiz_title' => $quiz_data['title'],
                'topic' => $quiz_data['topic'] ?? ''
            ];
            
            // Calculate grade letter
            if ($feedback_data['percentage'] >= 90) {
                $feedback_data['grade'] = 'A';
            } elseif ($feedback_data['percentage'] >= 80) {
                $feedback_data['grade'] = 'B';
            } elseif ($feedback_data['percentage'] >= 70) {
                $feedback_data['grade'] = 'C';
            } elseif ($feedback_data['percentage'] >= 60) {
                $feedback_data['grade'] = 'D';
            } else {
                $feedback_data['grade'] = 'F';
            }
            
            // Check if Questions table has a topic column
            $question_fields_query = "SHOW COLUMNS FROM Questions LIKE 'topic'";
            $field_result = $conn->query($question_fields_query);
            $has_topic_column = ($field_result->num_rows > 0);
            
            if ($has_topic_column) {
                // If Questions table has topic column, analyze by question topics
                $stmt = $conn->prepare("
                    SELECT q.topic, a.is_correct
                    FROM StudentQuizAnswers a
                    JOIN Questions q ON a.question_id = q.question_id
                    WHERE a.student_quiz_id = ?
                ");
                $stmt->bind_param("i", $student_quiz_id);
                $stmt->execute();
                $answers_result = $stmt->get_result();
                
                $topic_performance = [];
                
                while ($answer = $answers_result->fetch_assoc()) {
                    $topic = $answer['topic'] ?? '';
                    if (!empty($topic)) {
                        if (!isset($topic_performance[$topic])) {
                            $topic_performance[$topic] = ['correct' => 0, 'total' => 0];
                        }
                        
                        $topic_performance[$topic]['total']++;
                        if ($answer['is_correct']) {
                            $topic_performance[$topic]['correct']++;
                        }
                    }
                }
                
                // Determine strong and weak areas based on percentage correct
                foreach ($topic_performance as $topic => $data) {
                    $percentage = ($data['total'] > 0) ? ($data['correct'] / $data['total'] * 100) : 0;
                    
                    if ($percentage >= 70) {
                        $feedback_data['strong_areas'][] = $topic;
                    } else {
                        $feedback_data['weak_areas'][] = $topic;
                    }
                }
            } else {
                // If no topic column in Questions, use the quiz topic from Quizzes table
                if ($feedback_data['percentage'] >= 70) {
                    if (!empty($quiz_data['topic'])) {
                        $feedback_data['strong_areas'][] = $quiz_data['topic'];
                    } else {
                        $feedback_data['strong_areas'][] = $quiz_data['title'];
                    }
                } else {
                    if (!empty($quiz_data['topic'])) {
                        $feedback_data['weak_areas'][] = $quiz_data['topic'];
                    } else {
                        $feedback_data['weak_areas'][] = $quiz_data['title'];
                    }
                }
            }
            
            // Generate the feedback
            $feedback_response = generateQuizFeedback($feedback_data);
            
            // Store the feedback in the database
            $ai_feedback = $feedback_response['feedback'];
            $topics_covered = implode(", ", array_unique(array_merge($feedback_data['strong_areas'], $feedback_data['weak_areas'])));
            $resources_recommended = isset($feedback_response['resources_recommended']) ? 
                $feedback_response['resources_recommended'] : 
                "General quiz materials, Study guides, Practice quizzes";
            
            // Get course_id for the quiz
            $stmt = $conn->prepare("SELECT course_id FROM Quizzes WHERE quiz_id = ?");
            $stmt->bind_param("i", $quiz_id);
            $stmt->execute();
            $course_result = $stmt->get_result();
            $course_id = $course_result->fetch_assoc()['course_id'];
            
            // Save feedback to StudentFeedback table
            $feedback_stmt = $conn->prepare("
                INSERT INTO StudentFeedback (
                    student_id, 
                    course_id, 
                    topics_covered, 
                    resources_recommended,
                    ai_feedback, 
                    date_feedback
                ) VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $feedback_stmt->bind_param(
                "iisss", 
                $student_id, 
                $course_id, 
                $topics_covered, 
                $resources_recommended, 
                $ai_feedback
            );
            $feedback_stmt->execute();
            
            // Set success message and redirect
            $_SESSION['success_message'] = "Quiz submitted successfully! Your score: $score/$total_gradable_questions";
            header("Location: student-dashboard.php#quizzes");
        } else {
            // If quiz requires manual grading, show a different message
            $_SESSION['success_message'] = "Quiz submitted successfully! Your essay answers will be graded by your instructor.";
            header("Location: student-dashboard.php#quizzes");
        }
        exit();
    }
}

// If no quiz session exists yet, create one
if (!$is_quiz_in_progress && $quiz_info && isset($remaining_seconds)) {
    // Create a new student quiz record to mark the start time
    $stmt = $conn->prepare("
        INSERT INTO StudentQuizzes (student_id, quiz_id, total_questions, is_completed)
        VALUES (?, ?, (SELECT COUNT(*) FROM Questions WHERE quiz_id = ?), 0)
    ");
    $stmt->bind_param("iii", $student_id, $quiz_id, $quiz_id);
    $stmt->execute();
}

// Functions to display different question types
function displayMCQOptions($questionText, $question_id) {
    $lines = explode("\n", $questionText);
    
    // First line is the question, the rest are options
    $question = $lines[0];
    $options = array_slice($lines, 1);
    
    echo '<p><strong>Question:</strong> ' . htmlspecialchars($question) . '</p>';
    echo '<p><strong>Options:</strong></p>';
    echo '<ul class="list-group">';
    
    // Loop through and create the radio button options
    foreach ($options as $option) {
        // Extract the option letter (A, B, C, etc.) from the beginning
        $option_letter = trim(substr($option, 0, 1)); 
        
        echo '<li class="list-group-item">';
        echo '<input type="radio" name="question_' . $question_id . '" value="' . htmlspecialchars($option_letter) . '" required> ';
        echo '<label>' . htmlspecialchars($option) . '</label>';
        echo '</li>';
    }
    
    echo '</ul>';
}

function displayTrueFalseOptions($questionText, $question_id) {
    echo '<p><strong>Question:</strong> ' . htmlspecialchars($questionText) . '</p>';
    echo '<ul class="list-group">';
    
    echo '<li class="list-group-item">';
    echo '<input type="radio" name="question_' . $question_id . '" value="True" required> ';
    echo '<label>True</label>';
    echo '</li>';
    
    echo '<li class="list-group-item">';
    echo '<input type="radio" name="question_' . $question_id . '" value="False" required> ';
    echo '<label>False</label>';
    echo '</li>';
    
    echo '</ul>';
}

function displayEssayOptions($questionText, $question_id) {
    echo '<p><strong>Essay Question:</strong> ' . htmlspecialchars($questionText) . '</p>';
    echo '<div class="form-group">';
    echo '<textarea class="form-control" name="question_' . $question_id . '" rows="8" 
            placeholder="Enter your answer here..." required></textarea>';
    echo '</div>';
    echo '<p class="text-muted small">Your essay answer will be graded by your instructor.</p>';
}

function getQuestions($quiz_id) {
    global $conn;
    
    // Check if the quiz exists and is published
    $stmt = $conn->prepare("SELECT is_published, requires_manual_grading FROM Quizzes WHERE quiz_id = ?");
    $stmt->bind_param("i", $quiz_id);
    $stmt->execute();
    $quiz_result = $stmt->get_result();
    
    if ($quiz_result->num_rows === 0) {
        echo '<div class="alert alert-danger">Quiz not found.</div>';
        return 0;
    }
    
    $quiz = $quiz_result->fetch_assoc();
    if (!$quiz['is_published']) {
        echo '<div class="alert alert-warning">This quiz is not yet available.</div>';
        return 0;
    }
    
    $has_essay_questions = $quiz['requires_manual_grading'];
    
    // Get the questions
    $stmt = $conn->prepare("SELECT * FROM Questions WHERE quiz_id = ?");
    $stmt->bind_param("i", $quiz_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo '<div class="alert alert-info">No questions available for this quiz.</div>';
        return 0;
    }
    
    if ($has_essay_questions) {
        echo '<div class="alert alert-info">
                <i class="fa fa-info-circle"></i> This quiz contains essay questions that will be manually graded by your instructor.
              </div>';
    }
    
    // Iterate through each question
    while ($row = $result->fetch_assoc()) {
        $question_id = $row["question_id"];
        $text = $row["text"];
        $question_format = $row["question_format"];
        
        echo '<div class="question-container mb-4">';
        
        // Display based on question format
        if ($question_format == "MCQ") { 
            displayMCQOptions($text, $question_id); 
        } elseif ($question_format == "True/False") {
            displayTrueFalseOptions($text, $question_id);
        } elseif ($question_format == "Essay") {
            displayEssayOptions($text, $question_id);
        }
        
        echo '</div>';
    }
    
    return $result->num_rows; // Return the number of questions
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Attempt Quiz - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Attempt Quiz</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
        }
        
        #page-breadcrumb {
            background: #2A95BE;
            padding: 4px 0;
            color: white;
            margin-bottom: 40px;
        }
        .vertical-center {
            display: flex;
            align-items: center;
            min-height: 100px;
        }

        .questions-container {
            margin: 30px auto;
            max-width: 800px;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .question-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.05);
        }
        
        .list-group-item {
            border-left: 4px solid #007bff;
            margin-bottom: 5px;
        }
        
        .list-group-item:hover {
            background-color: #f5f5f5;
        }

        .quiz-info {
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
            padding-bottom: 20px;
        }
        
        .mb-4 {
            margin-bottom: 1.5rem;
        }
        
        .mt-4 {
            margin-top: 1.5rem;
        }
        
        .ml-2 {
            margin-left: 0.5rem;
        }
        
        /* Essay textarea styling */
        textarea.form-control {
            border: 1px solid #ced4da;
            border-left: 4px solid #28a745;
            resize: vertical;
        }
        
        textarea.form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        
        .text-muted.small {
            font-size: 0.85rem;
            font-style: italic;
        }
        
        .essay-question {
            border-left: 4px solid #28a745;
            padding-left: 15px;
        }
        
        /* Timer styling */
        #timer-container {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: rgba(255, 255, 255, 0.95);
            padding: 10px 15px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            font-size: 18px;
            font-weight: bold;
            border-left: 4px solid #dc3545;
            display: flex;
            align-items: center;
        }
        
        #timer-container i {
            margin-right: 8px;
            color: #dc3545;
        }
        
        #timer {
            color: #333;
        }
        
        /* When time is running low, apply warning color */
        .timer-warning {
            color: #dc3545 !important;
            animation: pulse 1s infinite;
        }
        
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="student-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <section id="page-breadcrumb">
        <div class="vertical-center sun">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Attempt Quiz</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php if ($quiz_info && $quiz_info['time_limit']): ?>
    <!-- Timer Display -->
    <div id="timer-container">
        <i class="fa fa-clock"></i>
        <div id="timer">Time remaining: <span id="minutes"></span>:<span id="seconds"></span></div>
    </div>
    <?php endif; ?>
    
    <div class="questions-container">
        <?php
        if ($quiz_info && $quiz_info['is_published']): 
        ?>
            <div class="quiz-info">
                <h3><?php echo htmlspecialchars($quiz_info['title']); ?></h3>
                <p><strong>Course:</strong> <?php echo htmlspecialchars($quiz_info['course_title']); ?></p>
                <p><strong>Instructions:</strong> Answer all questions below. All questions are required.</p>
                
                <?php if($quiz_info['time_limit']): ?>
                <p class="text-danger"><i class="fa fa-clock"></i> <strong>Time Limit:</strong> <?php echo $quiz_info['time_limit']; ?> minutes</p>
                <?php endif; ?>
                
                <?php if($quiz_info['requires_manual_grading']): ?>
                <p class="text-info"><i class="fa fa-info-circle"></i> This quiz contains essay questions that will require manual grading by your instructor.</p>
                <?php endif; ?>
            </div>
            
            <form id="quiz-form" action="attempt_quiz.php?id=<?php echo $quiz_id; ?>" method="POST">
                <?php 
                // Get and display all questions
                $question_count = getQuestions($quiz_id);
                
                if ($question_count > 0): 
                ?>
                <div class="mt-4">
                    <button type="submit" name="submit_quiz" class="btn btn-primary">Submit Quiz</button>
                    <a href="student-dashboard.php#quizzes" class="btn btn-secondary ml-2" onclick="return confirm('Are you sure you want to cancel? Your progress will be lost.')">Cancel</a>
                </div>
                <?php endif; ?>
            </form>
        <?php elseif ($quiz_info && !$quiz_info['is_published']): ?>
            <div class="alert alert-warning">
                <h4>Quiz Not Available</h4>
                <p>This quiz has not been published by the instructor yet.</p>
                <a href="student-dashboard.php#quizzes" class="btn btn-primary mt-4">Back to Dashboard</a>
            </div>
        <?php else: ?>
            <div class="alert alert-danger">
                <h4>Quiz Not Found</h4>
                <p>The requested quiz could not be found.</p>
                <a href="student-dashboard.php#quizzes" class="btn btn-primary mt-4">Back to Dashboard</a>
            </div>
        <?php endif; ?>
    </div>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        <?php if ($quiz_info && $quiz_info['time_limit']): ?>
        // Timer functionality
        let remainingSeconds = <?php echo $remaining_seconds ?? 'null'; ?>;
        let timerInterval;

        function updateTimer() {
            if (remainingSeconds !== null) {
                const minutes = Math.floor(remainingSeconds / 60);
                const seconds = remainingSeconds % 60;
                
                // Display with leading zeros
                document.getElementById('minutes').textContent = String(minutes).padStart(2, '0');
                document.getElementById('seconds').textContent = String(seconds).padStart(2, '0');
                
                // Apply warning styling when less than 5 minutes remain
                if (remainingSeconds <= 300) {
                    document.getElementById('timer').classList.add('timer-warning');
                }
                
                // If time is up, stop the timer and submit the form
                if (remainingSeconds <= 0) {
                    clearInterval(timerInterval);
                    alert("Time's up! Your quiz will be submitted automatically.");
                    
                    // Add a hidden field to indicate time expiration
                    const timeUpField = document.createElement('input');
                    timeUpField.type = 'hidden';
                    timeUpField.name = 'time_expired';
                    timeUpField.value = '1';
                    document.getElementById('quiz-form').appendChild(timeUpField);
                    
                    // Submit the form and prevent further execution
                    document.getElementById('quiz-form').submit();
                    return;
                }
                
                // Decrease the counter by 1 second
                remainingSeconds--;
            }
        }

        // Start timer when page loads
        if (remainingSeconds !== null) {
            // Update timer display every second
            timerInterval = setInterval(updateTimer, 1000);
            
            // Initial update
            updateTimer();
        }
        
        // Auto-save answers every 30 seconds
        function autoSaveAnswers() {
            const formData = new FormData(document.getElementById('quiz-form'));
            formData.append('auto_save', 'true');
            
            fetch('save_quiz_progress.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Auto-saved: ' + new Date().toLocaleTimeString());
                }
            })
            .catch(error => console.error('Auto-save error:', error));
        }
        
        // Set auto-save interval
        const autoSaveInterval = setInterval(autoSaveAnswers, 30000);
        
        // Clean up intervals when page is unloaded
        window.addEventListener('beforeunload', function() {
            clearInterval(timerInterval);
            clearInterval(autoSaveInterval);
        });
        <?php endif; ?>
        
        // Add an event listener to ensure form submission works when time expires
        document.addEventListener('DOMContentLoaded', function() {
            const quizForm = document.getElementById('quiz-form');
            if (quizForm) {
                // Disable unload warning when form is submitted due to timeout
                quizForm.addEventListener('submit', function() {
                    window.removeEventListener('beforeunload', confirmExit);
                });
            }
        });
        
        // Confirm before leaving the page
        const confirmExit = function(e) {
            // Only prompt if the form has been started but not submitted
            const radioButtons = document.querySelectorAll('input[type="radio"]:checked');
            const textareas = document.querySelectorAll('textarea');
            let textareasWithContent = 0;
            
            textareas.forEach(function(textarea) {
                if (textarea.value.trim().length > 0) {
                    textareasWithContent++;
                }
            });
            
            const totalInputs = radioButtons.length + textareasWithContent;
            
            if (totalInputs > 0 && totalInputs < <?php echo $question_count ?? 0; ?>) {
                e.preventDefault();
                e.returnValue = '';
            }
        };
        
        window.addEventListener('beforeunload', confirmExit);
        
        // Add character counter for essay questions
        document.addEventListener('DOMContentLoaded', function() {
            const textareas = document.querySelectorAll('textarea');
            textareas.forEach(function(textarea) {
                textarea.addEventListener('input', function() {
                    const charCount = this.value.length;
                    let counter = this.nextElementSibling;
                    
                    if (!counter || !counter.classList.contains('char-counter')) {
                        counter = document.createElement('div');
                        counter.className = 'text-muted small char-counter';
                        this.parentNode.insertBefore(counter, this.nextSibling);
                    }
                    
                    counter.textContent = `Characters: ${charCount}`;
                });
                
                // Trigger once to initialize
                textarea.dispatchEvent(new Event('input'));
            });
        });
    </script>
</body>
</html>