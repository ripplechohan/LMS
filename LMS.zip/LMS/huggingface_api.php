<?php
/**
 * HuggingFace API Integration
 * This file contains functions for interacting with the HuggingFace Inference API
 */

// HuggingFace API Configuration
$HUGGINGFACE_TOKEN = "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"; // Your token
$MODEL_ID = "tiiuae/falcon-7b-instruct"; // The model to use
$CACHE_ENABLED = true; // Whether to cache responses
$CACHE_EXPIRY = 86400; // Cache lifetime in seconds (24 hours)

// Define cache directory
define('CACHE_DIR', __DIR__ . '/cache');

/**
 * Make a request to the HuggingFace Inference API
 * 
 * @param string $prompt The prompt to send to the model
 * @param string $model_id The model ID to use
 * @param string $token Your HuggingFace API token
 * @param array $params Additional parameters for the model
 * @return string|false The model's response or false on failure
 */
function huggingface_generate_text($prompt, $model_id, $token, $params = []) {
    // Set default parameters if not provided
    $default_params = [
        'max_new_tokens' => 250,
        'temperature' => 0.7,
        'top_p' => 0.9,
        'do_sample' => true
    ];
    
    $parameters = array_merge($default_params, $params);
    
    // Set API endpoint
    $api_url = "https://api-inference.huggingface.co/models/" . $model_id;
    
    // Prepare request data
    $data = [
        'inputs' => $prompt,
        'parameters' => $parameters
    ];
    
    // Set up cURL request
    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $token,
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    // Execute request
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);
    
    // Handle errors
    if ($response === false || $http_code != 200) {
        error_log("HuggingFace API Error: " . ($curl_error ?: "HTTP Code: $http_code"));
        error_log("Response: " . $response);
        return false;
    }
    
    // Parse response
    $result = json_decode($response, true);
    
    // Extract the generated text
    if (isset($result[0]['generated_text'])) {
        // Remove the input prompt from the response
        $generated_text = str_replace($prompt, '', $result[0]['generated_text']);
        return trim($generated_text);
    } else {
        error_log("Unexpected response format from HuggingFace API: " . $response);
        return false;
    }
}

/**
 * Get a cached response if available
 * 
 * @param string $key Cache key
 * @return string|false Cached content or false if not found/expired
 */
function huggingface_get_cached_response($key) {
    $cache_file = CACHE_DIR . '/' . $key . '.cache';
    
    // Make sure cache directory exists
    if (!is_dir(CACHE_DIR)) {
        if (!mkdir(CACHE_DIR, 0755, true)) {
            error_log("Failed to create cache directory: " . CACHE_DIR);
            return false;
        }
    }
    
    if (file_exists($cache_file)) {
        $cache_data = unserialize(file_get_contents($cache_file));
        
        if ($cache_data['expires'] > time()) {
            return $cache_data['content'];
        }
    }
    
    return false;
}

/**
 * Cache a response
 * 
 * @param string $key Cache key
 * @param string $content Content to cache
 * @param int $expiry Expiry time in seconds
 * @return bool Success
 */
function huggingface_cache_response($key, $content, $expiry) {
    $cache_file = CACHE_DIR . '/' . $key . '.cache';
    
    // Make sure cache directory exists
    if (!is_dir(CACHE_DIR)) {
        if (!mkdir(CACHE_DIR, 0755, true)) {
            error_log("Failed to create cache directory: " . CACHE_DIR);
            return false;
        }
    }
    
    $cache_data = [
        'content' => $content,
        'expires' => time() + $expiry
    ];
    
    return file_put_contents($cache_file, serialize($cache_data)) !== false;
}

/**
 * Generate text with caching
 * 
 * @param string $prompt The prompt to send
 * @param string $model_id The model to use
 * @param string $token API token
 * @param bool $use_cache Whether to use cache
 * @param int $cache_expiry Cache expiry in seconds
 * @param array $params Model parameters
 * @return array Response with generated text and cache status
 */
function huggingface_generate_with_cache($prompt, $model_id, $token, $use_cache = true, $cache_expiry = 86400, $params = []) {
    // Create a unique cache key
    $cache_key = md5($prompt . $model_id . json_encode($params));
    
    // Check cache if enabled
    if ($use_cache) {
        $cached_response = huggingface_get_cached_response($cache_key);
        if ($cached_response !== false) {
            return [
                'text' => $cached_response,
                'cached' => true
            ];
        }
    }
    
    // Call API
    $response = huggingface_generate_text($prompt, $model_id, $token, $params);
    
    // Handle API failure
    if ($response === false) {
        return [
            'text' => "I'm sorry, I couldn't generate feedback at this time. Please try again later.",
            'cached' => false,
            'error' => true
        ];
    }
    
    // Cache the response
    if ($use_cache) {
        huggingface_cache_response($cache_key, $response, $cache_expiry);
    }
    
    return [
        'text' => $response,
        'cached' => false,
        'error' => false
    ];
}

/**
 * Clear the API response cache
 * 
 * @return bool Success
 */
function huggingface_clear_cache() {
    if (!is_dir(CACHE_DIR)) {
        return true; // No cache directory, so nothing to clear
    }
    
    $success = true;
    $files = glob(CACHE_DIR . '/*.cache');
    
    foreach ($files as $file) {
        if (!unlink($file)) {
            error_log("Failed to delete cache file: " . $file);
            $success = false;
        }
    }
    
    return $success;
}

/**
 * Generate educational feedback for a student
 * 
 * @param array $data Student data including performance metrics
 * @return array Response with feedback text
 */
function generate_student_feedback($data) {
    global $HUGGINGFACE_TOKEN, $MODEL_ID, $CACHE_ENABLED, $CACHE_EXPIRY;
    
    // Construct the prompt
    $prompt = "You are an educational assistant providing feedback to a student. ";
    $prompt .= "Give encouraging, constructive feedback in 3-4 paragraphs.\n\n";
    
    // Add student data to prompt
    $prompt .= "Student: " . $data['name'] . "\n";
    if (isset($data['course'])) {
        $prompt .= "Course: " . $data['course'] . "\n";
    }
    $prompt .= "Score: " . $data['score'] . "%\n";
    
    // Add strengths and weaknesses
    if (isset($data['strengths']) && !empty($data['strengths'])) {
        $prompt .= "Strengths: " . implode(", ", $data['strengths']) . "\n";
    }
    if (isset($data['weaknesses']) && !empty($data['weaknesses'])) {
        $prompt .= "Areas for Improvement: " . implode(", ", $data['weaknesses']) . "\n";
    }
    
    // Add guidance for the model
    $prompt .= "\nProvide personalized academic feedback with:\n";
    $prompt .= "1. A positive opening that acknowledges strengths\n";
    $prompt .= "2. Specific advice for improvement areas\n";
    $prompt .= "3. Encouragement and a positive closing";
    
    // Generate the feedback
    $response = huggingface_generate_with_cache(
        $prompt,
        $MODEL_ID,
        $HUGGINGFACE_TOKEN,
        $CACHE_ENABLED,
        $CACHE_EXPIRY
    );
    
    return $response;
}
?>