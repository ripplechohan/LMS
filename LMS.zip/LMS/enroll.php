<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has the student role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Student') {
    header("Location: login.php");
    exit();
}

// Check if course ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "No course selected for enrollment.";
    header("Location: courses.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$course_id = $_GET['id'];

// Check if course exists and is active
$stmt = $conn->prepare("SELECT course_id, title FROM Courses WHERE course_id = ? AND is_active = 1");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $_SESSION['error_message'] = "The selected course does not exist or is not active.";
    header("Location: courses.php");
    exit();
}

$course = $result->fetch_assoc();

// Check if student has an enrollment record for this course (active or dropped)
$stmt = $conn->prepare("SELECT enrollment_id, status FROM Enrollments WHERE student_id = ? AND course_id = ?");
$stmt->bind_param("ii", $student_id, $course_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $enrollment = $result->fetch_assoc();
    
    // Check if the student has dropped this course before
    if ($enrollment['status'] === 'Dropped') {
        $_SESSION['error_message'] = "You previously dropped this course and cannot re-enroll.";
        header("Location: courses.php");
        exit();
    }
    
    // If student is already enrolled (not dropped)
    $_SESSION['info_message'] = "You are already enrolled in this course.";
    header("Location: course-details.php?id=" . $course_id);
    exit();
}

// NEW CODE: Check for prerequisites
// Get the prerequisite course ID for the current course (if any)
$prereq_stmt = $conn->prepare("
    SELECT prereq_course_id, title
    FROM Courses 
    WHERE course_id = ? AND prereq_course_id IS NOT NULL
");
$prereq_stmt->bind_param("i", $course_id);
$prereq_stmt->execute();
$prereq_result = $prereq_stmt->get_result();

// If the course has a prerequisite
if ($prereq_result->num_rows > 0) {
    $course_data = $prereq_result->fetch_assoc();
    $prerequisite_id = $course_data['prereq_course_id'];
    
    // Get prerequisite course title for error message
    $prereq_title_stmt = $conn->prepare("SELECT title FROM Courses WHERE course_id = ?");
    $prereq_title_stmt->bind_param("i", $prerequisite_id);
    $prereq_title_stmt->execute();
    $prereq_title_result = $prereq_title_stmt->get_result();
    $prereq_title = $prereq_title_result->fetch_assoc()['title'];
    
    // Check if student has completed this prerequisite
    $check_stmt = $conn->prepare("
        SELECT status, progress_percentage 
        FROM Enrollments 
        WHERE student_id = ? AND course_id = ?
    ");
    $check_stmt->bind_param("ii", $student_id, $prerequisite_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    $prerequisite_completed = false;
    
    // Check if student is enrolled in the prerequisite
    if ($check_result->num_rows > 0) {
        $prereq_enrollment = $check_result->fetch_assoc();
        
        // Check if the prerequisite is completed (Completed status or 100% progress)
        if ($prereq_enrollment['status'] === 'Completed' || $prereq_enrollment['progress_percentage'] >= 100) {
            $prerequisite_completed = true;
        }
    }
    
    // If prerequisite is not completed, don't allow enrollment
    if (!$prerequisite_completed) {
        $_SESSION['error_message'] = "<strong>Prerequisite Requirement Not Met:</strong> To enroll in <strong>\"" . $course['title'] . "\"</strong>, you must first complete <strong>\"" . $prereq_title . "\"</strong>. Please complete the prerequisite course before attempting to enroll.";
        header("Location: courses.php");
        exit();
    }
}

// Enroll the student in the course
try {
    $enrollment_date = date('Y-m-d H:i:s');
    $progress = 0;
    $status = 'Enrolled';
    
    $stmt = $conn->prepare("INSERT INTO Enrollments (student_id, course_id, enrollment_date, progress_percentage, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisds", $student_id, $course_id, $enrollment_date, $progress, $status);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "You have successfully enrolled in " . $course['title'] . "!";
        
        // Create a notification for the enrollment
        $type = 'Course Update';
        $stmt = $conn->prepare("INSERT INTO Notifications (user_id, type, sent_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $student_id, $type);
        $stmt->execute();
        
        header("Location: student-dashboard.php");
        exit();
    } else {
        throw new Exception("Database error: " . $conn->error);
    }
} catch (Exception $e) {
    $_SESSION['error_message'] = "Error enrolling in course: " . $e->getMessage();
    header("Location: courses.php");
    exit();
}
?>