<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();
include 'db_connection.php';

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Define log directory
$log_dir = __DIR__ . '/logs/emails/';

// Initialize variables
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$log_file = $log_dir . $date . '_email_log.txt';
$log_entries = [];
$dates_available = [];

// Get list of available log dates
if (is_dir($log_dir)) {
    $files = scandir($log_dir);
    foreach ($files as $file) {
        if (preg_match('/^(\d{4}-\d{2}-\d{2})_email_log\.txt$/', $file, $matches)) {
            $dates_available[] = $matches[1];
        }
    }
    
    // Sort dates in descending order (newest first)
    rsort($dates_available);
}

// Read log file if it exists
if (file_exists($log_file)) {
    $log_content = file_get_contents($log_file);
    $lines = explode("\n", $log_content);
    
    foreach ($lines as $line) {
        if (!empty(trim($line))) {
            // Parse log line format: date | to | subject | status
            $parts = explode(" | ", $line);
            
            if (count($parts) >= 3) {
                $entry = [
                    'timestamp' => $parts[0],
                    'to' => isset($parts[1]) ? str_replace('To: ', '', $parts[1]) : '',
                    'subject' => isset($parts[2]) ? str_replace('Subject: ', '', $parts[2]) : '',
                    'status' => isset($parts[3]) ? str_replace('Status: ', '', $parts[3]) : '',
                    'error' => isset($parts[4]) ? str_replace('Error: ', '', $parts[4]) : null
                ];
                
                $log_entries[] = $entry;
            }
        }
    }
}

// Filter by type if requested
$filter_type = isset($_GET['type']) ? $_GET['type'] : '';
if (!empty($filter_type)) {
    $filtered_entries = [];
    foreach ($log_entries as $entry) {
        if (stripos($entry['subject'], $filter_type) !== false) {
            $filtered_entries[] = $entry;
        }
    }
    $log_entries = $filtered_entries;
}

// Count email types for statistics
$stats = [
    'deadline_reminders' => 0,
    'grade_notifications' => 0,
    'contact_forms' => 0,
    'other' => 0,
    'success' => 0,
    'failed' => 0
];

foreach ($log_entries as $entry) {
    if (stripos($entry['subject'], 'Deadline Reminder') !== false) {
        $stats['deadline_reminders']++;
    } elseif (stripos($entry['subject'], 'Feedback Available') !== false || 
              stripos($entry['subject'], 'Grade') !== false) {
        $stats['grade_notifications']++;
    } elseif (stripos($entry['subject'], 'Contact Form') !== false) {
        $stats['contact_forms']++;
    } else {
        $stats['other']++;
    }
    
    if (stripos($entry['status'], 'Sent') !== false) {
        $stats['success']++;
    } else {
        $stats['failed']++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Email Logs - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Email Notification Logs</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
            padding: 20px;
        }
        .logs-container {
            margin-top: 20px;
        }
        .filter-section {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .stats-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-box {
            flex: 1;
            min-width: 150px;
            background-color: #fff;
            border-radius: 5px;
            padding: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-number {
            font-size: 1.8rem;
            font-weight: bold;
        }
        .status-sent {
            color: #28a745;
        }
        .status-failed {
            color: #dc3545;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .date-selector {
            max-width: 200px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2><i class="fas fa-envelope"></i> Email Notification Logs</h2>
        
        <div class="filter-section">
            <div class="row">
                <div class="col-md-4">
                    <form action="" method="get" class="form-inline">
                        <div class="form-group">
                            <label for="date">Select Date:</label>
                            <select name="date" id="date" class="form-control date-selector" onchange="this.form.submit()">
                                <?php foreach($dates_available as $available_date): ?>
                                    <option value="<?php echo $available_date; ?>" <?php echo ($date == $available_date) ? 'selected' : ''; ?>>
                                        <?php echo date('F j, Y', strtotime($available_date)); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>
                </div>
                
                <div class="col-md-4">
                    <form action="" method="get" class="form-inline">
                        <input type="hidden" name="date" value="<?php echo $date; ?>">
                        <div class="form-group">
                            <label for="type">Filter by Type:</label>
                            <select name="type" id="type" class="form-control" onchange="this.form.submit()">
                                <option value="">All Types</option>
                                <option value="Deadline Reminder" <?php echo ($filter_type == 'Deadline Reminder') ? 'selected' : ''; ?>>Deadline Reminders</option>
                                <option value="Feedback" <?php echo ($filter_type == 'Feedback') ? 'selected' : ''; ?>>Grade Notifications</option>
                                <option value="Contact Form" <?php echo ($filter_type == 'Contact Form') ? 'selected' : ''; ?>>Contact Forms</option>
                            </select>
                        </div>
                    </form>
                </div>
                
                <div class="col-md-4 text-right">
                    <a href="admin-dashboard.php" class="btn btn-primary">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                </div>
            </div>
        </div>
        
        <div class="stats-container">
            <div class="stat-box">
                <div class="stat-number status-sent"><?php echo $stats['success']; ?></div>
                <div>Successful</div>
            </div>
            
            <div class="stat-box">
                <div class="stat-number status-failed"><?php echo $stats['failed']; ?></div>
                <div>Failed</div>
            </div>
            
            <div class="stat-box">
                <div class="stat-number"><?php echo $stats['deadline_reminders']; ?></div>
                <div>Deadline Reminders</div>
            </div>
            
            <div class="stat-box">
                <div class="stat-number"><?php echo $stats['grade_notifications']; ?></div>
                <div>Grade Notifications</div>
            </div>
            
            <div class="stat-box">
                <div class="stat-number"><?php echo $stats['contact_forms']; ?></div>
                <div>Contact Forms</div>
            </div>
        </div>
        
        <div class="logs-container">
            <h3>Email Logs for <?php echo date('F j, Y', strtotime($date)); ?></h3>
            
            <?php if(empty($log_entries)): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No email logs found for this date.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Recipient</th>
                                <th>Subject</th>
                                <th>Status</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($log_entries as $entry): ?>
                                <tr>
                                    <td><?php echo date('H:i:s', strtotime($entry['timestamp'])); ?></td>
                                    <td><?php echo htmlspecialchars($entry['to']); ?></td>
                                    <td><?php echo htmlspecialchars($entry['subject']); ?></td>
                                    <td>
                                        <?php if(stripos($entry['status'], 'Sent') !== false): ?>
                                            <span class="label label-success">Sent</span>
                                        <?php else: ?>
                                            <span class="label label-danger">Failed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(!empty($entry['error'])): ?>
                                            <button type="button" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="top" title="<?php echo htmlspecialchars($entry['error']); ?>">
                                                <i class="fas fa-exclamation-circle"></i> Error Details
                                            </button>
                                        <?php else: ?>
                                            <span class="text-success"><i class="fas fa-check-circle"></i> Delivered</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</body>
</html>