// autoload.php
spl_autoload_register(function ($class) {
    // Convert namespace to full file path
    $prefix = '';
    $base_dir = __DIR__ . '/PHPMailer-6.9.3/';
    
    // Normalize class name
    $class = ltrim($class, '\\');
    
    // Determine file path
    $file = $base_dir . str_replace('\\', '/', $class) . '.php';
    
    // If the file exists, require it
    if (file_exists($file)) {
        require $file;
    }
});