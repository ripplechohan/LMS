<?php
session_start();
include 'db_connection.php';

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

$success_message = '';
$error_message = '';
$course_data = null;

// Check if course ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid course ID";
    header("Location: admin-dashboard.php");
    exit();
}

$course_id = $_GET['id'];

// Get course data including current instructor information
$stmt = $conn->prepare("
    SELECT c.*, u.name as instructor_name, u.email as instructor_email 
    FROM Courses c
    LEFT JOIN Users u ON c.instructor_id = u.user_id
    WHERE c.course_id = ?
");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error_message'] = "Course not found";
    header("Location: admin-dashboard.php");
    exit();
}

$course_data = $result->fetch_assoc();

// Get all active instructors except current one - FIXED THIS PART
$stmt = $conn->prepare("
    SELECT user_id, name, email 
    FROM Users 
    WHERE role = 'Instructor' AND active = 1 AND user_id != ? 
    ORDER BY name
");
$stmt->bind_param("i", $course_data['instructor_id']);
$stmt->execute();
$result = $stmt->get_result(); // Get the result first
$instructors = [];
while ($row = $result->fetch_assoc()) {
    $instructors[] = $row;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the selected instructor
    $new_instructor_id = isset($_POST['instructor_id']) ? $_POST['instructor_id'] : null;
    
    // Validate input
    if (empty($new_instructor_id)) {
        $error_message = "Please select a new instructor to assign to the course.";
    } else {
        try {
            // Start transaction
            $conn->begin_transaction();
            
            // Update the course with the new instructor
            $stmt = $conn->prepare("UPDATE Courses SET instructor_id = ? WHERE course_id = ?");
            $stmt->bind_param("ii", $new_instructor_id, $course_id);
            
            if ($stmt->execute()) {
                // Commit transaction
                $conn->commit();
                
                $_SESSION['success_message'] = "Instructor changed successfully for '" . htmlspecialchars($course_data['title']) . "'.";
                header("Location: admin-dashboard.php");
                exit();
            } else {
                throw new Exception($conn->error);
            }
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $error_message = "Error changing instructor: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Change Instructor - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Change Course Instructor</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            max-width: 800px;
        }
        .form-title {
            margin-bottom: 10px;
            color: #333;
            text-align: center;
        }
        .course-title {
            color: #007bff;
            margin-bottom: 20px;
            text-align: center;
            font-weight: normal;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .btn-container {
            margin-top: 30px;
            text-align: center;
        }
        .instructor-list {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
        }
        .instructor-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        .instructor-item:last-child {
            border-bottom: none;
        }
        .instructor-info {
            margin-left: 10px;
        }
        .actions-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }
        .current-instructor {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="admin-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Change Instructor</h2>
            <h3 class="course-title">for: <?php echo htmlspecialchars($course_data['title']); ?></h3>
            
            <?php if(!empty($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <?php if(!empty($error_message)): ?>
                <div class="alert alert-danger">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <div class="current-instructor">
                <h4><i class="fas fa-user-tie"></i> Current Instructor</h4>
                <p><strong><?php echo htmlspecialchars($course_data['instructor_name']); ?></strong></p>
                <p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($course_data['instructor_email']); ?></p>
            </div>
            
            <?php if(empty($instructors)): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> There are no other active instructors in the system. 
                    <a href="add_user.php" class="alert-link">Add another instructor</a> first.
                </div>
            <?php else: ?>
                <p class="text-center">Select a new instructor to assign to this course:</p>
                
                <form method="POST" action="change_instructor.php?id=<?php echo $course_id; ?>">
                    <div class="instructor-list">
                        <?php foreach($instructors as $instructor): ?>
                            <div class="instructor-item">
                                <div class="radio">
                                    <label>
                                        <input type="radio" name="instructor_id" value="<?php echo $instructor['user_id']; ?>">
                                        <strong><?php echo htmlspecialchars($instructor['name']); ?></strong>
                                        <div class="instructor-info text-muted">
                                            <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($instructor['email']); ?>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="actions-container">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-exchange-alt"></i> Change Instructor
                        </button>
                        <a href="admin-dashboard.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Cancel
                        </a>
                    </div>
                </form>
            <?php endif; ?>
            
            <div class="btn-container">
                <div class="btn-group">
                    <a href="admin_edit_course.php?id=<?php echo $course_id; ?>" class="btn btn-info">
                        <i class="fas fa-edit"></i> Edit Course
                    </a>
                    <a href="admin-dashboard.php" class="btn btn-secondary">
                        <i class="fas fa-th-list"></i> All Courses
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>