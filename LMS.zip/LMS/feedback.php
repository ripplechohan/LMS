<?php
session_start();

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();

// Similar redirect count protection
if (isset($_SESSION['redirect_count']) && $_SESSION['redirect_count'] > 3) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// Increment redirect count
$_SESSION['redirect_count'] = isset($_SESSION['redirect_count']) ? 
    $_SESSION['redirect_count'] + 1 : 1;

include 'db_connection.php';
// Make sure this file exists and contains the generateOverallFeedback function
include 'generate_ai_feedback.php';
include 'feedback_utils.php'; // Include our utility functions

// Check if the required function exists, if not define a fallback
if (!function_exists('generateOverallFeedback')) {
    /**
     * Fallback function in case generate_ai_feedback.php doesn't load properly
     * 
     * @param array $data Student performance data
     * @return array Response with feedback text
     */
    function generateOverallFeedback($data) {
        // Simple fallback that returns basic feedback
        $student_name = $data['student_name'];
        $score = $data['score'];
        $grade = $data['grade'];
        
        return [
            'feedback' => "We're currently experiencing technical difficulties with our feedback system. " .
                        "Based on your current score of {$score}% (Grade: {$grade}), we recommend reviewing your course materials " .
                        "and reaching out to your instructor for more detailed feedback.",
            'cached' => false,
            'topics_covered' => isset($data['topics_covered']) ? $data['topics_covered'] : "General",
            'resources_recommended' => isset($data['resources_recommended']) ? $data['resources_recommended'] : "Course materials"
        ];
    }
}

// Check if user is logged in 
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Determine which student to generate feedback for
// If an instructor triggers the regeneration, use the student_id parameter
if ($_SESSION['role'] == 'Instructor' && isset($_GET['student_id'])) {
    $student_id = $_GET['student_id'];
} else {
    // Otherwise use the logged-in student's ID
    $student_id = $_SESSION['user_id'];
}

// Only instructors or the student themselves can regenerate feedback
if ($_SESSION['role'] != 'Instructor' && $student_id != $_SESSION['user_id']) {
    $_SESSION['error_message'] = "You don't have permission to generate feedback for other students.";
    header("Location: " . ($_SESSION['role'] == 'Student' ? 'student-dashboard.php' : 'instructor-dashboard.php'));
    exit();
}

// Check if regeneration is needed (using function from feedback_utils.php)
$regenerate = checkFeedbackNeedsRegeneration($student_id);

if ($regenerate) {
    // Calculate total score and possible total
    $total_score = 0;
    $total_possible = 0;
    
    // Add up assignment scores with topic information
    $assign_stmt = $conn->prepare("
        SELECT a.title, a.topic, a.topic_id, s.grade, s.assignment_id,
               ct.topic_name
        FROM Submissions s
        JOIN Assignments a ON s.assignment_id = a.assignment_id
        LEFT JOIN CourseTopics ct ON a.topic_id = ct.topic_id
        WHERE s.student_id = ? AND s.grade IS NOT NULL
    ");
    $assign_stmt->bind_param("i", $student_id);
    $assign_stmt->execute();
    $assignments_result = $assign_stmt->get_result();
    
    $strong_assignments = [];
    $weak_assignments = [];
    
    while ($assignment = $assignments_result->fetch_assoc()) {
        $total_score += $assignment['grade'];
        $total_possible += 100; // Assuming assignments are out of 100
        
        // Get the topic name - use CourseTopics name if available, otherwise fallback to topic field
        $topic_name = !empty($assignment['topic_name']) ? $assignment['topic_name'] : $assignment['topic'];
        
        // Track strong and weak assignments
        if ($assignment['grade'] >= 70) {
            $strong_assignments[] = [
                'title' => $assignment['title'],
                'topic' => $topic_name,
                'topic_id' => $assignment['topic_id'],
                'score' => $assignment['grade']
            ];
        } else {
            $weak_assignments[] = [
                'title' => $assignment['title'],
                'topic' => $topic_name,
                'topic_id' => $assignment['topic_id'],
                'score' => $assignment['grade']
            ];
        }
    }
    
    // Add up quiz scores with topic information
    $quiz_stmt = $conn->prepare("
        SELECT q.title, q.topic, q.topic_id, sq.score, sq.total_questions, sq.quiz_id,
               ct.topic_name
        FROM StudentQuizzes sq
        JOIN Quizzes q ON sq.quiz_id = q.quiz_id
        LEFT JOIN CourseTopics ct ON q.topic_id = ct.topic_id
        WHERE sq.student_id = ? AND sq.is_completed = 1
    ");
    $quiz_stmt->bind_param("i", $student_id);
    $quiz_stmt->execute();
    $quizzes_result = $quiz_stmt->get_result();
    
    $strong_quizzes = [];
    $weak_quizzes = [];
    
    while ($quiz = $quizzes_result->fetch_assoc()) {
        // Important: Handle quiz scores correctly based on their data type
        // Ensure we're getting the decimal value properly
        $quiz_score = 0;
        if ($quiz['total_questions'] > 0) {
            // Check if score is stored as decimal or needs conversion
            if (is_numeric($quiz['score']) && $quiz['score'] <= 1.0) {
                // Score is already stored as decimal (0-1)
                $quiz_score = $quiz['score'] * 100;
            } else {
                // Score might be stored as raw points
                $quiz_score = ($quiz['score'] / $quiz['total_questions']) * 100;
            }
        }
        
        $total_score += $quiz_score;
        $total_possible += 100; // Normalizing to 100
        
        // Get the topic name - use CourseTopics name if available, otherwise fallback to topic field
        $topic_name = !empty($quiz['topic_name']) ? $quiz['topic_name'] : $quiz['topic'];
        
        // Track strong and weak quizzes
        if ($quiz_score >= 70) {
            $strong_quizzes[] = [
                'title' => $quiz['title'],
                'topic' => $topic_name,
                'topic_id' => $quiz['topic_id'],
                'score' => round($quiz_score)
            ];
        } else {
            $weak_quizzes[] = [
                'title' => $quiz['title'],
                'topic' => $topic_name,
                'topic_id' => $quiz['topic_id'],
                'score' => round($quiz_score)
            ];
        }
    }
    
    // Calculate overall percentage using the requested formula:
    // (Sum of all quiz scores + sum of all assignment scores) / (total number of quizzes + assignments)
    $total_assessments = count($strong_quizzes) + count($weak_quizzes) + count($strong_assignments) + count($weak_assignments);
    $overall_percentage = ($total_assessments > 0) ? round($total_score / $total_assessments) : 0;
    
    // Get student name
    $name_stmt = $conn->prepare("SELECT name FROM Users WHERE user_id = ?");
    $name_stmt->bind_param("i", $student_id);
    $name_stmt->execute();
    $student_data = $name_stmt->get_result()->fetch_assoc();
    $student_name = $student_data['name'];
    
    // Get weak topics for resource recommendations - use topic_id when available for more precise matching
    $weak_topics = [];
    $weak_topic_ids = [];
    
    foreach ($weak_assignments as $assignment) {
        if (!empty($assignment['topic_id']) && !in_array($assignment['topic_id'], $weak_topic_ids)) {
            $weak_topic_ids[] = $assignment['topic_id'];
        }
        if (!empty($assignment['topic']) && !in_array($assignment['topic'], $weak_topics)) {
            $weak_topics[] = $assignment['topic'];
        }
    }
    
    foreach ($weak_quizzes as $quiz) {
        if (!empty($quiz['topic_id']) && !in_array($quiz['topic_id'], $weak_topic_ids)) {
            $weak_topic_ids[] = $quiz['topic_id'];
        }
        if (!empty($quiz['topic']) && !in_array($quiz['topic'], $weak_topics)) {
            $weak_topics[] = $quiz['topic'];
        }
    }
    
    // Get resources for weak topics
    $resources = [];
    if (!empty($weak_topic_ids) || !empty($weak_topics)) {
        // Get the courses the student is enrolled in
        $enrolled_courses_stmt = $conn->prepare("
            SELECT course_id FROM Enrollments WHERE student_id = ?
        ");
        $enrolled_courses_stmt->bind_param("i", $student_id);
        $enrolled_courses_stmt->execute();
        $enrolled_courses_result = $enrolled_courses_stmt->get_result();
        
        $enrolled_course_ids = [];
        while ($course = $enrolled_courses_result->fetch_assoc()) {
            $enrolled_course_ids[] = $course['course_id'];
        }
        
        if (!empty($enrolled_course_ids)) {
            $query_parts = [];
            $params = [];
            $types = "";
            
            // Add all enrolled course IDs to the parameters
            foreach ($enrolled_course_ids as $course_id) {
                $types .= "i";
                $params[] = $course_id;
            }
            
            $course_placeholders = implode(',', array_fill(0, count($enrolled_course_ids), '?'));
            
            // Base query to find materials from enrolled courses
            $base_query = "
                SELECT cm.title, cm.type, cm.file_path, c.title as course_title, 
                       cm.topic, ct.topic_name
                FROM CourseMaterials cm
                JOIN Courses c ON cm.course_id = c.course_id
                LEFT JOIN CourseTopics ct ON cm.topic_id = ct.topic_id
                WHERE cm.course_id IN ($course_placeholders)
            ";
            
            // Add topic_id conditions if we have them
            if (!empty($weak_topic_ids)) {
                $topic_id_placeholders = implode(',', array_fill(0, count($weak_topic_ids), '?'));
                $query_parts[] = "cm.topic_id IN ($topic_id_placeholders)";
                
                foreach ($weak_topic_ids as $topic_id) {
                    $types .= "i";
                    $params[] = $topic_id;
                }
            }
            
            // Add topic name conditions as a fallback
            if (!empty($weak_topics)) {
                $topic_conditions = [];
                
                foreach ($weak_topics as $topic) {
                    if (!empty($topic)) {
                        $topic_conditions[] = "cm.topic LIKE ? OR ct.topic_name LIKE ?";
                        $types .= "ss";
                        $params[] = "%$topic%";
                        $params[] = "%$topic%";
                    }
                }
                
                if (!empty($topic_conditions)) {
                    $query_parts[] = "(" . implode(" OR ", $topic_conditions) . ")";
                }
            }
            
            // Complete the query with any conditions
            $full_query = $base_query;
            if (!empty($query_parts)) {
                $full_query .= " AND (" . implode(" OR ", $query_parts) . ")";
            }
            
            // Add ordering and limit
            $full_query .= " ORDER BY cm.upload_date DESC LIMIT 10";
            
            $resource_query = $conn->prepare($full_query);
            
            if (!empty($params)) {
                $resource_query->bind_param($types, ...$params);
            }
            
            $resource_query->execute();
            $resource_result = $resource_query->get_result();
            
            while ($resource = $resource_result->fetch_assoc()) {
                // Get the topic name for display - use the CourseTopics name if available, otherwise fallback to topic field
                $display_topic = !empty($resource['topic_name']) ? $resource['topic_name'] : $resource['topic'];
                
                $resources[] = [
                    'title' => $resource['title'],
                    'type' => $resource['type'],
                    'file_path' => $resource['file_path'],
                    'course_title' => $resource['course_title'],
                    'topic' => $display_topic
                ];
            }
        }
    }
    
    // Generate AI feedback
    $feedback_data = [
        'student_name' => $student_name,
        'quiz_title' => 'Overall Academic Performance',
        'score' => $overall_percentage,
        'total_questions' => 100, // Normalized to percentage
        'percentage' => $overall_percentage,
        'grade' => getGradeLetter($overall_percentage),
        'strong_areas' => array_filter(array_merge(
            array_column($strong_quizzes, 'topic'),
            array_column($strong_assignments, 'topic')
        )),
        'weak_areas' => array_filter(array_merge(
            array_column($weak_quizzes, 'topic'),
            array_column($weak_assignments, 'topic')
        )),
        'resources' => $resources
    ];
    
    // Generate new feedback
    $feedback_response = generateOverallFeedback($feedback_data);
    $ai_feedback = $feedback_response['feedback'];
    
    // Get the first enrolled course ID for the student
    if (!empty($enrolled_course_ids)) {
        $course_id = $enrolled_course_ids[0];
        
        // Combine all topics into a single string
        $topics = implode(", ", array_unique(array_filter(array_merge(
            array_column($strong_quizzes, 'topic'),
            array_column($strong_assignments, 'topic'),
            array_column($weak_quizzes, 'topic'),
            array_column($weak_assignments, 'topic')
        ))));
        
        // If no topics are available, set a default value
        if (empty($topics)) {
            $topics = "General";
        }
        
        // Serialize resources info as JSON
        $resources_json = json_encode($resources);
        
        // First check if feedback already exists for this student
        $check_existing = $conn->prepare("
            SELECT feedback_id FROM StudentFeedback 
            WHERE student_id = ? 
            ORDER BY date_feedback DESC 
            LIMIT 1
        ");
        $check_existing->bind_param("i", $student_id);
        $check_existing->execute();
        $existing_result = $check_existing->get_result();

        if ($existing_result->num_rows > 0) {
            // Update existing feedback
            $feedback_record = $existing_result->fetch_assoc();
            $feedback_id = $feedback_record['feedback_id'];
            
            $update_feedback = $conn->prepare("
                UPDATE StudentFeedback 
                SET course_id = ?, 
                    topics_covered = ?, 
                    resources_recommended = ?, 
                    ai_feedback = ?, 
                    date_feedback = NOW(),
                    needs_regeneration = 0
                WHERE feedback_id = ?
            ");
            
            $update_feedback->bind_param(
                "isssi", 
                $course_id,
                $topics,
                $resources_json,
                $ai_feedback,
                $feedback_id
            );
            
            $result = $update_feedback->execute();
            
            if ($result) {
                // Set success message
                $_SESSION['success_message'] = "AI feedback has been updated successfully.";
                
                // Clear the regeneration flag
                clearFeedbackRegenerationFlag($student_id);
            } else {
                // Handle error
                $_SESSION['error_message'] = "Error updating feedback: " . $conn->error;
            }
        } else {
            // Create new feedback record (only for first-time feedback)
            $save_feedback = $conn->prepare("
                INSERT INTO StudentFeedback (
                    student_id, 
                    course_id, 
                    topics_covered, 
                    resources_recommended, 
                    ai_feedback, 
                    date_feedback,
                    needs_regeneration
                ) VALUES (?, ?, ?, ?, ?, NOW(), 0)
            ");
            
            $save_feedback->bind_param(
                "iisss", 
                $student_id, 
                $course_id,
                $topics,
                $resources_json,
                $ai_feedback
            );
            
            $result = $save_feedback->execute();
            
            if ($result) {
                // Set success message
                $_SESSION['success_message'] = "AI feedback has been generated successfully.";
                
                // Clear the regeneration flag
                clearFeedbackRegenerationFlag($student_id);
            } else {
                // Handle error
                $_SESSION['error_message'] = "Error generating feedback: " . $conn->error;
            }
        }

        // Clear the feedback cache for this student regardless of insert/update
        if (function_exists('clearFeedbackCache')) {
            clearFeedbackCache($student_id);
        }
    } else {
        // Handle the case where the student isn't enrolled in any courses
        $_SESSION['error_message'] = "Unable to generate feedback. Please enroll in at least one course first.";
    }
}

// Helper function to get grade letter
function getGradeLetter($percentage) {
    if ($percentage >= 90) return 'A';
    if ($percentage >= 80) return 'B';
    if ($percentage >= 70) return 'C';
    if ($percentage >= 60) return 'D';
    return 'F';
}

// Determine where to redirect based on user role
// In feedback.php, change the redirect line to:
$redirect_url = ($_SESSION['role'] == 'Student') ? 'student-dashboard.php?skip_feedback_check=1#feedback' : 'instructor-dashboard.php#students';

// Redirect back to appropriate dashboard
header("Location: $redirect_url");
exit();
?>