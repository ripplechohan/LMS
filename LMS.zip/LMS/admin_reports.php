<?php
session_start();
include 'db_connection.php';

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Get admin data
$admin_id = $_SESSION['user_id'];
$admin_name = $_SESSION['name'];

// Set default report parameters
$report_type = isset($_GET['report_type']) ? $_GET['report_type'] : 'semesterly';
$report_period = isset($_GET['report_period']) ? $_GET['report_period'] : date('Y-1'); // Default to spring semester of current year
$course_category = isset($_GET['category']) ? $_GET['category'] : 'all';

// Determine which sections to display
$active_section = isset($_GET['section']) ? $_GET['section'] : 'all'; // Default to show all sections

// Determine date range for the report
$start_date = '';
$end_date = '';
$period_display = '';

if ($report_type == 'semesterly') {
    // For semesterly reports
    $parts = explode('-', $report_period);
    $year = isset($parts[0]) ? $parts[0] : date('Y');
    $semester = isset($parts[1]) ? $parts[1] : '1';
    
    if ($semester == '1') { // Spring semester
        $start_date = "$year-01-01";
        $end_date = "$year-06-30";
        $period_display = "Spring $year";
    } else { // Fall semester
        $start_date = "$year-07-01";
        $end_date = "$year-12-31";
        $period_display = "Fall $year";
    }
} else { // Yearly
    $year = $report_period;
    $start_date = "$year-01-01";
    $end_date = "$year-12-31";
    $period_display = "Year $year";
}

// Get all course categories
$stmt = $conn->prepare("SELECT DISTINCT category FROM Courses WHERE category IS NOT NULL ORDER BY category");
$stmt->execute();
$categories = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// 1. Course Completion Rates by Category
$category_condition = ($course_category != 'all') ? "AND c.category = ?" : "";
$category_params = ($course_category != 'all') ? "sssss" : "ssss";
$category_values = ($course_category != 'all') ? [$start_date, $end_date, $course_category, $start_date, $end_date] : [$start_date, $end_date, $start_date, $end_date];

$stmt = $conn->prepare("
    SELECT 
        COALESCE(c.category, 'Uncategorized') as category,
        COUNT(DISTINCT c.course_id) as total_courses,
        COUNT(DISTINCT e.enrollment_id) as total_enrollments,
        SUM(CASE WHEN e.status = 'Completed' THEN 1 ELSE 0 END) as completed_enrollments,
        ROUND(SUM(CASE WHEN e.status = 'Completed' THEN 1 ELSE 0 END) / COUNT(DISTINCT e.enrollment_id) * 100, 2) as completion_rate
    FROM 
        Courses c
    LEFT JOIN 
        Enrollments e ON c.course_id = e.course_id AND (e.enrollment_date BETWEEN ? AND ?)
    WHERE 
        c.start_date <= ? $category_condition
        AND (c.end_date IS NULL OR c.end_date >= ?)
    GROUP BY 
        c.category
    ORDER BY 
        completion_rate DESC
");

$stmt->bind_param($category_params, ...$category_values);
$stmt->execute();
$completion_by_category = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// 2. Student Engagement and Retention
$stmt = $conn->prepare("
    SELECT 
        COUNT(DISTINCT u.user_id) as total_students,
        COUNT(DISTINCT CASE WHEN e.status = 'Dropped' THEN e.student_id END) as dropped_students,
        ROUND((COUNT(DISTINCT CASE WHEN e.status = 'Dropped' THEN e.student_id END) / GREATEST(COUNT(DISTINCT u.user_id), 1)) * 100, 2) as dropout_rate,
        AVG(e.progress_percentage) as average_progress,
        (SELECT COUNT(*) FROM Assignments) as total_assignments,
        (SELECT COUNT(*) FROM Quizzes WHERE is_published = 1) as total_quizzes,
        ((SELECT COUNT(*) FROM Assignments) + (SELECT COUNT(*) FROM Quizzes WHERE is_published = 1)) as total_activities
    FROM 
        Users u
    LEFT JOIN 
        Enrollments e ON u.user_id = e.student_id AND (e.enrollment_date BETWEEN ? AND ?)
    WHERE 
        u.role = 'Student'
");

$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$engagement_overview = $stmt->get_result()->fetch_assoc();

// Initialize these values to prevent undefined index errors
$engagement_overview['total_assignments'] = $engagement_overview['total_assignments'] ?? 0;
$engagement_overview['total_quizzes'] = $engagement_overview['total_quizzes'] ?? 0;
$engagement_overview['total_activities'] = $engagement_overview['total_activities'] ?? 0;
$engagement_overview['average_progress'] = $engagement_overview['average_progress'] ?? 0;
$engagement_overview['total_students'] = $engagement_overview['total_students'] ?? 0;
$engagement_overview['dropout_rate'] = $engagement_overview['dropout_rate'] ?? 0;

// Modified: Calculate student activity metrics - Now exclude assignments with future due dates
$current_date = date('Y-m-d');
$stmt = $conn->prepare("
    SELECT 
        u.user_id,
        u.name,
        COALESCE((
            SELECT COUNT(DISTINCT s.submission_id) 
            FROM Submissions s 
            JOIN Assignments a ON s.assignment_id = a.assignment_id 
            WHERE s.student_id = u.user_id 
            AND s.date_submitted BETWEEN ? AND ? 
            AND a.due_date <= ?
        ), 0) as submitted_assignments,
        COALESCE((
            SELECT COUNT(DISTINCT student_quiz_id) 
            FROM StudentQuizzes 
            WHERE student_id = u.user_id 
            AND started_at BETWEEN ? AND ?
        ), 0) as attempted_quizzes,
        COALESCE((
            SELECT COUNT(DISTINCT student_quiz_id) 
            FROM StudentQuizzes 
            WHERE student_id = u.user_id 
            AND completed_at BETWEEN ? AND ? 
            AND is_completed = 1
        ), 0) as completed_quizzes,
        (
            COALESCE((
                SELECT COUNT(DISTINCT s.submission_id) 
                FROM Submissions s 
                JOIN Assignments a ON s.assignment_id = a.assignment_id 
                WHERE s.student_id = u.user_id 
                AND s.date_submitted BETWEEN ? AND ? 
                AND a.due_date <= ?
            ), 0) +
            COALESCE((
                SELECT COUNT(DISTINCT student_quiz_id) 
                FROM StudentQuizzes 
                WHERE student_id = u.user_id 
                AND completed_at BETWEEN ? AND ? 
                AND is_completed = 1
            ), 0)
        ) as total_activities_completed,
        /* New: Get dashboard activity time for students */
        COALESCE((
            SELECT SUM(TIMESTAMPDIFF(MINUTE, login_time, IFNULL(logout_time, last_activity))) 
            FROM UserSessions 
            WHERE user_id = u.user_id 
            AND login_time BETWEEN ? AND ?
        ), 0) as dashboard_activity_minutes
    FROM 
        Users u
    WHERE 
        u.role = 'Student'
    ORDER BY 
        total_activities_completed DESC, u.name ASC
    LIMIT 10
");


$stmt->bind_param("ssssssssssssss", 
    $start_date, $end_date, $current_date,  // 3 for submitted assignments
    $start_date, $end_date,                 // 2 for attempted quizzes
    $start_date, $end_date,                 // 2 for completed quizzes
    $start_date, $end_date, $current_date,  // 3 for activities completed (assignments)
    $start_date, $end_date,                 // 2 for activities completed (quizzes)
    $start_date, $end_date                  // 2 for dashboard activity
);
$stmt->execute();
$student_completion = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Modified: Calculate total activity counts for all students - exclude future assignments
$stmt = $conn->prepare("
    SELECT 
        COALESCE(SUM(sub_count), 0) as total_submissions,
        COALESCE(SUM(quiz_count), 0) as total_quiz_completions,
        COALESCE(SUM(sub_count + quiz_count), 0) as total_activities_completed,
        COALESCE(SUM(dashboard_minutes), 0) as total_dashboard_minutes
    FROM (
        SELECT
            u.user_id,
            COALESCE((
                SELECT COUNT(DISTINCT s.submission_id) 
                FROM Submissions s 
                JOIN Assignments a ON s.assignment_id = a.assignment_id 
                WHERE s.student_id = u.user_id 
                AND s.date_submitted BETWEEN ? AND ? 
                AND a.due_date <= ?
            ), 0) as sub_count,
            COALESCE((
                SELECT COUNT(DISTINCT student_quiz_id) 
                FROM StudentQuizzes 
                WHERE student_id = u.user_id 
                AND completed_at BETWEEN ? AND ? 
                AND is_completed = 1
            ), 0) as quiz_count,
            COALESCE((
                SELECT SUM(TIMESTAMPDIFF(MINUTE, login_time, IFNULL(logout_time, last_activity))) 
                FROM UserSessions 
                WHERE user_id = u.user_id 
                AND login_time BETWEEN ? AND ?
            ), 0) as dashboard_minutes
        FROM
            Users u
        WHERE
            u.role = 'Student'
    ) as student_activity
");

$stmt->bind_param("sssssss", $start_date, $end_date, $current_date, $start_date, $end_date, $start_date, $end_date);
$stmt->execute();
$activity_counts = $stmt->get_result()->fetch_assoc();

// Initialize with default values to prevent undefined index errors
$activity_counts['total_submissions'] = $activity_counts['total_submissions'] ?? 0;
$activity_counts['total_quiz_completions'] = $activity_counts['total_quiz_completions'] ?? 0;
$activity_counts['total_activities_completed'] = $activity_counts['total_activities_completed'] ?? 0;
$activity_counts['total_dashboard_minutes'] = $activity_counts['total_dashboard_minutes'] ?? 0;

// Get the number of current (not future) assignments
$stmt = $conn->prepare("
    SELECT COUNT(*) as current_assignments
    FROM Assignments
    WHERE due_date <= ?
");
$stmt->bind_param("s", $current_date);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$current_assignments = $result['current_assignments'] ?? 0;

// Recalculate total activities to exclude future assignments
$total_current_activities = $current_assignments + $engagement_overview['total_quizzes']; 

// Calculate the theoretical maximum possible activities (now using only current assignments)
$total_possible_activities = $total_current_activities * $engagement_overview['total_students'];

// Modified: Calculate completion rate (50% based on completion, 50% based on dashboard activity)
// First, calculate activity completion rate component (50%)
$activity_completion_rate = ($total_possible_activities > 0) 
    ? ($activity_counts['total_activities_completed'] / $total_possible_activities) * 50
    : 0;

// Get average expected dashboard activity time per student (in minutes)
// Assuming 30 minutes per week per course is a reasonable expectation
$stmt = $conn->prepare("
    SELECT 
        AVG(course_count) as avg_course_per_student,
        DATEDIFF(?, ?) as period_weeks
    FROM (
        SELECT 
            student_id, 
            COUNT(DISTINCT course_id) as course_count
        FROM 
            Enrollments
        WHERE 
            enrollment_date BETWEEN ? AND ?
        GROUP BY 
            student_id
    ) as student_courses
");

$stmt->bind_param("ssss", $end_date, $start_date, $start_date, $end_date);
$stmt->execute();
$course_data = $stmt->get_result()->fetch_assoc();

$avg_courses_per_student = $course_data['avg_course_per_student'] ?? 1;
$period_weeks = max($course_data['period_weeks'] / 7, 1); // Convert days to weeks, minimum 1 week

// Calculate expected dashboard time (30 min/week/course * courses * weeks)
$expected_dashboard_minutes = 30 * $avg_courses_per_student * $period_weeks * $engagement_overview['total_students'];

// Calculate dashboard activity rate component (50%)
$dashboard_activity_rate = ($expected_dashboard_minutes > 0)
    ? min(($activity_counts['total_dashboard_minutes'] / $expected_dashboard_minutes) * 50, 50)
    : 0;

// Calculate the combined engagement score (50% completion + 50% dashboard time)
$combined_engagement_score = round($activity_completion_rate + $dashboard_activity_rate, 1);

// Recalculate individual student engagement scores for the table
foreach ($student_completion as &$student) {
    // Calculate maximum possible activities for this student
    $max_activities = $total_current_activities;
    
    // Calculate activity completion component (50%)
    $student_activity_rate = ($max_activities > 0) 
        ? ($student['total_activities_completed'] / $max_activities) * 50
        : 0;
        
    // Calculate expected dashboard time for this student
    $student_expected_minutes = 30 * $avg_courses_per_student * $period_weeks;
    
    // Calculate dashboard activity component (50%)
    $student_dashboard_rate = ($student_expected_minutes > 0)
        ? min(($student['dashboard_activity_minutes'] / $student_expected_minutes) * 50, 50)
        : 0;
    
    // Calculate combined engagement score
    $student['engagement_score'] = round($student_activity_rate + $student_dashboard_rate, 1);
}

// Fix for the monthly activity query parameter binding error (line ~420)
$stmt = $conn->prepare("
    SELECT 
        DATE_FORMAT(activity_date, '%Y-%m') as month,
        COUNT(DISTINCT student_id) as active_students,
        SUM(attendance_count) as attendance_count,
        SUM(submission_count) as submission_count,
        SUM(quiz_count) as quiz_attempt_count,
        SUM(dashboard_minutes) as dashboard_minutes,
        SUM(attendance_count + submission_count + quiz_count) as total_activity
    FROM (
        -- Attendance activities
        SELECT 
            a.student_id,
            DATE_FORMAT(a.date, '%Y-%m') as activity_date,
            COUNT(*) as attendance_count,
            0 as submission_count,
            0 as quiz_count,
            0 as dashboard_minutes
        FROM 
            Attendance a
        WHERE 
            a.date BETWEEN ? AND ?
        GROUP BY 
            a.student_id, DATE_FORMAT(a.date, '%Y-%m')
            
        UNION ALL
        
        -- Submission activities (exclude future assignments)
        SELECT 
            s.student_id,
            DATE_FORMAT(s.date_submitted, '%Y-%m') as activity_date,
            0 as attendance_count,
            COUNT(*) as submission_count,
            0 as quiz_count,
            0 as dashboard_minutes
        FROM 
            Submissions s
        JOIN
            Assignments a ON s.assignment_id = a.assignment_id
        WHERE 
            s.date_submitted BETWEEN ? AND ?
            AND a.due_date <= ?
        GROUP BY 
            s.student_id, DATE_FORMAT(s.date_submitted, '%Y-%m')
            
        UNION ALL
        
        -- Quiz activities
        SELECT 
            sq.student_id,
            DATE_FORMAT(sq.started_at, '%Y-%m') as activity_date,
            0 as attendance_count,
            0 as submission_count,
            COUNT(*) as quiz_count,
            0 as dashboard_minutes
        FROM 
            StudentQuizzes sq
        WHERE 
            sq.started_at BETWEEN ? AND ?
        GROUP BY 
            sq.student_id, DATE_FORMAT(sq.started_at, '%Y-%m')
            
        UNION ALL
        
        -- Dashboard activity time
        SELECT 
            us.user_id as student_id,
            DATE_FORMAT(us.login_time, '%Y-%m') as activity_date,
            0 as attendance_count,
            0 as submission_count,
            0 as quiz_count,
            SUM(TIMESTAMPDIFF(MINUTE, us.login_time, IFNULL(us.logout_time, us.last_activity))) as dashboard_minutes
        FROM 
            UserSessions us
        JOIN
            Users u ON us.user_id = u.user_id
        WHERE 
            us.login_time BETWEEN ? AND ?
            AND u.role = 'Student'
        GROUP BY 
            us.user_id, DATE_FORMAT(us.login_time, '%Y-%m')
    ) AS combined_activity
    GROUP BY 
        month
    ORDER BY 
        month
");

// Count the parameters: 
// 2 for attendance + 3 for submissions + 2 for quizzes + 2 for dashboard = 9 parameters
$stmt->bind_param("sssssssss", 
    $start_date, $end_date,           // 2 for attendance activities
    $start_date, $end_date, $current_date,  // 3 for submission activities
    $start_date, $end_date,           // 2 for quiz activities
    $start_date, $end_date            // 2 for dashboard activities
);
$stmt->execute();
$monthly_activity = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// 4. Top 5 Most Completed Courses
$stmt = $conn->prepare("
    SELECT 
        c.course_id,
        c.title,
        c.category,
        COUNT(DISTINCT e.enrollment_id) as total_enrollments,
        SUM(CASE WHEN e.status = 'Completed' THEN 1 ELSE 0 END) as completed_enrollments,
        ROUND(SUM(CASE WHEN e.status = 'Completed' THEN 1 ELSE 0 END) / COUNT(DISTINCT e.enrollment_id) * 100, 2) as completion_rate
    FROM 
        Courses c
    JOIN 
        Enrollments e ON c.course_id = e.course_id
    WHERE 
        e.enrollment_date BETWEEN ? AND ?
    GROUP BY 
        c.course_id, c.title, c.category
    HAVING 
        COUNT(DISTINCT e.enrollment_id) >= 5
    ORDER BY 
        completion_rate DESC, total_enrollments DESC
    LIMIT 5
");

$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$top_courses = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// 5. Courses with Low Completion Rates (Potential Concerns)
$stmt = $conn->prepare("
    SELECT 
        c.course_id,
        c.title,
        c.category,
        COUNT(DISTINCT e.enrollment_id) as total_enrollments,
        SUM(CASE WHEN e.status = 'Completed' THEN 1 ELSE 0 END) as completed_enrollments,
        ROUND(SUM(CASE WHEN e.status = 'Completed' THEN 1 ELSE 0 END) / COUNT(DISTINCT e.enrollment_id) * 100, 2) as completion_rate
    FROM 
        Courses c
    JOIN 
        Enrollments e ON c.course_id = e.course_id
    WHERE 
        e.enrollment_date BETWEEN ? AND ?
    GROUP BY 
        c.course_id, c.title, c.category
    HAVING 
        COUNT(DISTINCT e.enrollment_id) >= 5
        AND completion_rate < 50
    ORDER BY 
        completion_rate ASC
    LIMIT 5
");

$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$concern_courses = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Prepare data for charts
$categories_labels = [];
$completion_rates = [];
if (!empty($completion_by_category)) {
    foreach ($completion_by_category as $category_data) {
        $categories_labels[] = $category_data['category'];
        $completion_rates[] = $category_data['completion_rate'];
    }
}

$months_labels = [];
$activity_counts_array = [];
$dashboard_time_array = []; // New array for dashboard time
if (!empty($monthly_activity)) {
    foreach ($monthly_activity as $month_data) {
        $months_labels[] = date('M Y', strtotime($month_data['month'] . '-01'));
        $activity_counts_array[] = $month_data['total_activity'];
        $dashboard_time_array[] = round($month_data['dashboard_minutes'] / 60, 1); // Convert to hours
    }
}

// Initialize the overview stats with default values
$stmt = $conn->prepare("SELECT COUNT(DISTINCT course_id) as total_courses FROM Courses");
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$total_courses = $result['total_courses'] ?? 0;

$stmt = $conn->prepare("SELECT COUNT(DISTINCT enrollment_id) as total_enrollments FROM Enrollments");
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$total_enrollments = $result['total_enrollments'] ?? 0;

$stmt = $conn->prepare("SELECT COUNT(DISTINCT enrollment_id) as completed_enrollments FROM Enrollments WHERE status = 'Completed'");
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$total_completed_enrollments = $result['completed_enrollments'] ?? 0;

$overall_completion_rate = ($total_enrollments > 0) ? 
    round(($total_completed_enrollments / $total_enrollments) * 100, 1) : 0;

// Handle report download requests
if (isset($_GET['download'])) {
    $download_type = $_GET['download'];
    $filename = "admin_report_{$report_period}.csv";
    
    // Start output buffering
    ob_start();
    
    // Create a file pointer
    $output = fopen('php://output', 'w');
    
    // Output headers based on report type
    if ($download_type == 'completion') {
        fputcsv($output, ['Category', 'Total Courses', 'Total Enrollments', 'Completed Enrollments', 'Completion Rate (%)']);
        foreach ($completion_by_category as $row) {
            fputcsv($output, $row);
        }
    } elseif ($download_type == 'engagement') {
        fputcsv($output, ['Month', 'Active Students', 'Attendance Count', 'Submission Count', 'Quiz Attempt Count', 'Dashboard Hours', 'Total Activity']);
        foreach ($monthly_activity as $row) {
            // Convert dashboard minutes to hours for CSV export
            $dashboard_hours = round($row['dashboard_minutes'] / 60, 2);
            $csv_row = [
                $row['month'],
                $row['active_students'],
                $row['attendance_count'],
                $row['submission_count'],
                $row['quiz_attempt_count'],
                $dashboard_hours,
                $row['total_activity']
            ];
            fputcsv($output, $csv_row);
        }
    }
    
    // Get the content from the buffer
    $csv = ob_get_clean();
    
    // Set headers for download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    echo $csv;
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Admin Reports - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Admin Reports</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: white;
        }
        #reports {
            padding: 50px 0;
        }
        .report-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        .report-box {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            margin: 0 auto;
        }
        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .report-filters {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .chart-container {
            position: relative;
            height: 40vh;
            margin: 30px 0;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .report-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .btn-download {
            margin-left: 10px;
        }
        .stat-box {
            text-align: center;
            padding: 20px;
            border-radius: 10px;
            background-color: #f8f9fa;
            box-shadow: 0px 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #007bff;
        }
        .stat-label {
            font-size: 1rem;
            color: #6c757d;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0px 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid rgba(0,0,0,0.125);
            font-weight: bold;
        }
        .progress {
            margin-top: 5px;
            height: 20px;
        }
        .report-section {
            display: none; /* Hide all sections by default */
        }
        .section-active {
            display: block; /* Show only the active section */
        }
        .section-nav {
            margin-bottom: 30px;
            text-align: center;
        }
        .section-nav .btn {
            margin: 0 5px;
        }
        .active-section-btn {
            background-color: #007bff;
            color: white;
        }
        /* New styles for engagement components */
        .engagement-components {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin: 20px 0;
        }
        .engagement-component {
            flex: 1;
            min-width: 280px;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        .component-title {
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
        }
        .component-value {
            font-size: 24px;
            color: #007bff;
        }
        .component-desc {
            font-size: 12px;
            color: #6c757d;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="admin-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Reports Section -->
    <section id="reports">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center">LMS Analytics and Reports</h2>
                    <p class="text-center">Comprehensive insights into course completion rates and student engagement patterns.</p>
                </div>
            </div>
            
            <!-- Report Filters -->
            <div class="report-filters">
                <form id="reportForm" method="get" action="admin_reports.php">
                    <input type="hidden" name="section" id="sectionInput" value="<?php echo $active_section; ?>">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="report_type">Report Type:</label>
                                <select class="form-control" id="report_type" name="report_type" onchange="togglePeriodSelector()">
                                    <option value="semesterly" <?php echo ($report_type == 'semesterly') ? 'selected' : ''; ?>>Semesterly</option>
                                    <option value="yearly" <?php echo ($report_type == 'yearly') ? 'selected' : ''; ?>>Yearly</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4" id="semesterSelector" <?php echo ($report_type == 'yearly') ? 'style="display:none;"' : ''; ?>>
                            <div class="form-group">
                                <label for="semesterly_period">Select Semester:</label>
                                <select class="form-control" id="semesterly_period" name="report_period">
                                    <?php
                                    $current_year = date('Y');
                                    for ($year = $current_year; $year >= $current_year - 3; $year--) {
                                        $sem1 = "$year-1";
                                        $sem2 = "$year-2";
                                        echo "<option value='$sem1'" . ($report_period == $sem1 ? ' selected' : '') . ">Spring $year</option>";
                                        echo "<option value='$sem2'" . ($report_period == $sem2 ? ' selected' : '') . ">Fall $year</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4" id="yearSelector" <?php echo ($report_type == 'semesterly') ? 'style="display:none;"' : ''; ?>>
                            <div class="form-group">
                                <label for="yearly_period">Select Year:</label>
                                <select class="form-control" id="yearly_period" name="report_period">
                                    <?php
                                    $current_year = date('Y');
                                    for ($year = $current_year; $year >= $current_year - 5; $year--) {
                                        echo "<option value='$year'" . ($report_period == $year ? ' selected' : '') . ">$year</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="category">Course Category:</label>
                                <select class="form-control" id="category" name="category">
                                    <option value="all" <?php echo ($course_category == 'all') ? 'selected' : ''; ?>>All Categories</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?php echo htmlspecialchars($cat['category']); ?>" <?php echo ($course_category == $cat['category']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($cat['category']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Generate Report</button>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Section Navigation -->
            <div class="section-nav">
                <button class="btn <?php echo ($active_section == 'completion' || $active_section == 'all') ? 'btn-primary active-section-btn' : 'btn-default'; ?>" onclick="changeSection('completion')">
                    Course Completion Analysis
                </button>
                <button class="btn <?php echo ($active_section == 'engagement' || $active_section == 'all') ? 'btn-primary active-section-btn' : 'btn-default'; ?>" onclick="changeSection('engagement')">
                    Student Engagement & Retention
                </button>
                <button class="btn <?php echo ($active_section == 'all') ? 'btn-primary active-section-btn' : 'btn-default'; ?>" onclick="changeSection('all')">
                    Complete Analytics Dashboard
                </button>
            </div>
            
            <!-- Report Header -->
            <div class="report-header">
                <h3>Report for <?php echo htmlspecialchars($period_display); ?></h3>
                <div>
                    <a href="admin_reports.php?download=completion&report_type=<?php echo $report_type; ?>&report_period=<?php echo $report_period; ?>&category=<?php echo $course_category; ?>&section=<?php echo $active_section; ?>" class="btn btn-success">
                        <i class="fa fa-download"></i> Export Completion Data
                    </a>
                    <a href="admin_reports.php?download=engagement&report_type=<?php echo $report_type; ?>&report_period=<?php echo $report_period; ?>&category=<?php echo $course_category; ?>&section=<?php echo $active_section; ?>" class="btn btn-info">
                        <i class="fa fa-download"></i> Export Engagement Data
                    </a>
                </div>
            </div>
            <!-- Overview Stats - Only show in "all" mode -->
            <div class="row report-section <?php echo ($active_section == 'all') ? 'section-active' : ''; ?>" id="overview-section">
                <div class="col-md-3">
                    <div class="stat-box">
                        <div class="stat-number"><?php echo $total_courses; ?></div>
                        <div class="stat-label">Total Courses</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-box">
                        <div class="stat-number"><?php echo $total_enrollments; ?></div>
                        <div class="stat-label">Total Enrollments</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-box">
                        <div class="stat-number"><?php echo $engagement_overview['total_students']; ?></div>
                        <div class="stat-label">Active Students</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-box">
                        <div class="stat-number"><?php echo $overall_completion_rate; ?>%</div>
                        <div class="stat-label">Overall Completion Rate</div>
                    </div>
                </div>
            </div>
            
            <!-- Course Completion Section -->
            <div class="row report-section <?php echo ($active_section == 'completion' || $active_section == 'all') ? 'section-active' : ''; ?>" id="completion-section">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Course Completion Rates by Category</h4>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="completionChart"></canvas>
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Total Courses</th>
                                            <th>Total Enrollments</th>
                                            <th>Completed</th>
                                            <th>Completion Rate</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if (!empty($completion_by_category)): ?>
                                            <?php foreach ($completion_by_category as $category): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($category['category']); ?></td>
                                                    <td><?php echo $category['total_courses']; ?></td>
                                                    <td><?php echo $category['total_enrollments']; ?></td>
                                                    <td><?php echo $category['completed_enrollments']; ?></td>
                                                    <td>
                                                        <div class="progress">
                                                            <?php 
                                                            $completion_rate = $category['completion_rate'];
                                                            $class = 'progress-bar-success';
                                                            if ($completion_rate < 50) {
                                                                $class = 'progress-bar-danger';
                                                            } else if ($completion_rate < 75) {
                                                                $class = 'progress-bar-warning';
                                                            }
                                                            ?>
                                                            <div class="progress-bar <?php echo $class; ?>" role="progressbar" 
                                                                 style="width: <?php echo $completion_rate; ?>%;" 
                                                                 aria-valuenow="<?php echo $completion_rate; ?>" 
                                                                 aria-valuemin="0" aria-valuemax="100">
                                                                <?php echo $completion_rate; ?>%
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="5" class="text-center">No data available for this period</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Course Highlights - Only show in completion section -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h4>Top 5 Most Completed Courses</h4>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($top_courses)): ?>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Course Title</th>
                                                <th>Category</th>
                                                <th>Enrollments</th>
                                                <th>Completion Rate</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($top_courses as $course): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($course['title']); ?></td>
                                                    <td><?php echo htmlspecialchars($course['category']); ?></td>
                                                    <td><?php echo $course['total_enrollments']; ?></td>
                                                    <td>
                                                        <div class="progress">
                                                            <div class="progress-bar progress-bar-success" role="progressbar" 
                                                                 style="width: <?php echo $course['completion_rate']; ?>%;" 
                                                                 aria-valuenow="<?php echo $course['completion_rate']; ?>" 
                                                                 aria-valuemin="0" aria-valuemax="100">
                                                                <?php echo $course['completion_rate']; ?>%
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">No courses with sufficient enrollments found in the selected period.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h4>Courses with Low Completion Rates</h4>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($concern_courses)): ?>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Course Title</th>
                                                <th>Category</th>
                                                <th>Enrollments</th>
                                                <th>Completion Rate</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($concern_courses as $course): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($course['title']); ?></td>
                                                    <td><?php echo htmlspecialchars($course['category']); ?></td>
                                                    <td><?php echo $course['total_enrollments']; ?></td>
                                                    <td>
                                                        <div class="progress">
                                                            <div class="progress-bar progress-bar-danger" role="progressbar" 
                                                                 style="width: <?php echo $course['completion_rate']; ?>%;" 
                                                                 aria-valuenow="<?php echo $course['completion_rate']; ?>" 
                                                                 aria-valuemin="0" aria-valuemax="100">
                                                                <?php echo $course['completion_rate']; ?>%
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="alert alert-warning mt-3">
                                    <i class="fa fa-exclamation-triangle"></i> These courses may need additional support or curriculum review.
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">No courses with low completion rates found in the selected period.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Student Engagement Section -->
            <div class="row report-section <?php echo ($active_section == 'engagement' || $active_section == 'all') ? 'section-active' : ''; ?>" id="engagement-section">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Student Engagement and Retention</h4>
                        </div>
                        <div class="card-body">
                            <!-- New engagement score components display -->
                            <div class="engagement-components">
                                <div class="engagement-component">
                                    <div class="component-title">Overall Engagement Score</div>
                                    <div class="component-value"><?php echo $combined_engagement_score; ?>%</div>
                                    <div class="component-desc">Combined score based on activity completion and dashboard time</div>
                                </div>
                                <div class="engagement-component">
                                    <div class="component-title">Activity Completion</div>
                                    <div class="component-value"><?php echo round($activity_completion_rate, 1); ?>%</div>
                                    <div class="component-desc">50% of engagement score: Based on assignments and quizzes completed</div>
                                </div>
                                <div class="engagement-component">
                                    <div class="component-title">Dashboard Activity</div>
                                    <div class="component-value"><?php echo round($dashboard_activity_rate, 1); ?>%</div>
                                    <div class="component-desc">50% of engagement score: Based on time spent on dashboard</div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5>Engagement Overview</h5>
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Total Students
                                                    <span class="badge badge-primary badge-pill"><?php echo $engagement_overview['total_students']; ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Dropout Rate
                                                    <span class="badge badge-danger badge-pill"><?php echo $engagement_overview['dropout_rate']; ?>%</span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Average Course Progress
                                                    <span class="badge badge-info badge-pill"><?php echo round($engagement_overview['average_progress'] ?? 0, 1); ?>%</span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Current Activities Available
                                                    <span class="badge badge-secondary badge-pill"><?php echo $total_current_activities; ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Activities Completed
                                                    <span class="badge badge-secondary badge-pill"><?php echo $activity_counts['total_activities_completed']; ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Total Dashboard Time
                                                    <span class="badge badge-info badge-pill">
                                                        <?php echo round($activity_counts['total_dashboard_minutes'] / 60, 1); ?> hours
                                                    </span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="chart-container">
                                        <canvas id="engagementChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Monthly activity chart -->
                            <div class="chart-container mt-4">
                                <canvas id="monthlyActivityChart"></canvas>
                            </div>
                            
                            <!-- Top students by engagement -->
                            <h5 class="mt-4">Top Student Engagement</h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Student Name</th>
                                            <th>Engagement Score</th>
                                            <th>Activities Completed</th>
                                            <th>Dashboard Time</th>
                                            <th>Assignments</th>
                                            <th>Quizzes</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($student_completion)): ?>
                                            <?php foreach ($student_completion as $student): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($student['name']); ?></td>
                                                    <td>
                                                        <div class="progress">
                                                            <?php 
                                                            $engagement_score = $student['engagement_score'];
                                                            $class = 'progress-bar-success';
                                                            if ($engagement_score < 50) {
                                                                $class = 'progress-bar-danger';
                                                            } else if ($engagement_score < 75) {
                                                                $class = 'progress-bar-warning';
                                                            }
                                                            ?>
                                                            <div class="progress-bar <?php echo $class; ?>" role="progressbar" 
                                                                 style="width: <?php echo $engagement_score; ?>%;" 
                                                                 aria-valuenow="<?php echo $engagement_score; ?>" 
                                                                 aria-valuemin="0" aria-valuemax="100">
                                                                <?php echo $engagement_score; ?>%
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td><?php echo $student['total_activities_completed']; ?></td>
                                                    <td><?php echo round($student['dashboard_activity_minutes'] / 60, 1); ?> hrs</td>
                                                    <td><?php echo $student['submitted_assignments']; ?></td>
                                                    <td><?php echo $student['completed_quizzes']; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="6" class="text-center">No student activity data available for this period</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <h5 class="mt-4">Monthly Student Activity</h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Month</th>
                                            <th>Active Students</th>
                                            <th>Attendance Count</th>
                                            <th>Assignment Submissions</th>
                                            <th>Quiz Attempts</th>
                                            <th>Dashboard Hours</th>
                                            <th>Total Activity</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($monthly_activity)): ?>
                                            <?php foreach ($monthly_activity as $month): ?>
                                                <tr>
                                                    <td><?php echo date('M Y', strtotime($month['month'] . '-01')); ?></td>
                                                    <td><?php echo $month['active_students']; ?></td>
                                                    <td><?php echo $month['attendance_count']; ?></td>
                                                    <td><?php echo $month['submission_count']; ?></td>
                                                    <td><?php echo $month['quiz_attempt_count']; ?></td>
                                                    <td><?php echo round($month['dashboard_minutes'] / 60, 1); ?></td>
                                                    <td><?php echo $month['total_activity']; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No monthly activity data available for this period</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recommendations Section - Only show in "all" mode -->
            <div class="row report-section <?php echo ($active_section == 'all') ? 'section-active' : ''; ?>" id="recommendations-section">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>System Recommendations</h4>
                        </div>
                        <div class="card-body">
                            <div class="alert alert-info">
                                <h5><i class="fa fa-lightbulb"></i> Insights based on current data</h5>
                                <ul>
                                    <?php if (!empty($concern_courses)): ?>
                                    <li>Consider reviewing the curriculum or teaching methods for courses with low completion rates, especially <?php echo htmlspecialchars($concern_courses[0]['title']); ?> (<?php echo $concern_courses[0]['completion_rate']; ?>% completion).</li>
                                    <?php endif; ?>
                                    
                                    <?php if ($engagement_overview['dropout_rate'] > 20): ?>
                                    <li>Student dropout rate of <?php echo $engagement_overview['dropout_rate']; ?>% is higher than the recommended threshold (20%). Consider implementing retention strategies.</li>
                                    <?php endif; ?>
                                    
                                    <?php if ($combined_engagement_score < 60): ?>
                                    <li>Overall student engagement score is below target at <?php echo $combined_engagement_score; ?>%. Consider implementing more interactive activities and encouraging dashboard usage.</li>
                                    <?php endif; ?>
                                    
                                    <?php if ($dashboard_activity_rate < 25): ?>
                                    <li>Dashboard activity is lower than expected (<?php echo round($dashboard_activity_rate, 1); ?>% of target). Consider adding more engaging dashboard features or reminders.</li>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($monthly_activity) && count($monthly_activity) > 1):
                                        $current = end($monthly_activity);
                                        reset($monthly_activity);
                                        $prev = prev($monthly_activity);
                                        $activity_change = isset($current['total_activity']) && isset($prev['total_activity']) ? 
                                            $current['total_activity'] - $prev['total_activity'] : 0;
                                        if ($activity_change < 0): 
                                    ?>
                                    <li>Student activity has decreased by <?php echo abs($activity_change); ?> actions compared to the previous month. Consider introducing engagement initiatives.</li>
                                    <?php endif; endif; ?>
                                    
                                    <?php if (!empty($top_courses)): ?>
                                    <li>The most successful course is <?php echo htmlspecialchars($top_courses[0]['title']); ?> with <?php echo $top_courses[0]['completion_rate']; ?>% completion rate. Consider analyzing its structure as a model for other courses.</li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; <?php echo date('Y'); ?> Learning Management System. All Rights Reserved.
                </div>
                <div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href="home.php">Home</a></li>
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Change section function
        function changeSection(section) {
            // Update hidden input
            document.getElementById('sectionInput').value = section;
            
            // Submit the form
            document.getElementById('reportForm').submit();
        }
        
        // Toggle between period selectors
        function togglePeriodSelector() {
            const reportType = document.getElementById('report_type').value;
            const semesterSelector = document.getElementById('semesterSelector');
            const yearSelector = document.getElementById('yearSelector');
            
            if (reportType === 'semesterly') {
                semesterSelector.style.display = 'block';
                yearSelector.style.display = 'none';
                document.getElementById('reportForm').action = 'admin_reports.php';
                document.getElementById('reportForm').report_period = document.getElementById('semesterly_period').value;
            } else {
                semesterSelector.style.display = 'none';
                yearSelector.style.display = 'block';
                document.getElementById('reportForm').action = 'admin_reports.php';
                document.getElementById('reportForm').report_period = document.getElementById('yearly_period').value;
            }
        }
        
        // Initialize charts when the DOM is fully loaded
        document.addEventListener('DOMContentLoaded', function() {
            // Completion Rate Chart
            var completionChart = null;
            var completionCtx = document.getElementById('completionChart');
            if (completionCtx) {
                completionChart = new Chart(completionCtx.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode($categories_labels); ?>,
                        datasets: [{
                            label: 'Completion Rate (%)',
                            data: <?php echo json_encode($completion_rates); ?>,
                            backgroundColor: function(context) {
                                const value = context.dataset.data[context.dataIndex];
                                return value < 50 ? 'rgba(220, 53, 69, 0.7)' : 
                                    value < 75 ? 'rgba(255, 193, 7, 0.7)' : 
                                    'rgba(40, 167, 69, 0.7)';
                            },
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100,
                                title: {
                                    display: true,
                                    text: 'Completion Rate (%)'
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Course Categories'
                                }
                            }
                        },
                        plugins: {
                            title: {
                                display: true,
                                text: 'Course Completion Rate by Category'
                            },
                            legend: {
                                display: false
                            }
                        }
                    }
                });
            }
            
            // Student Engagement Chart - Modified to show both components
            var engagementChart = null;
            var engagementCtx = document.getElementById('engagementChart');
            if (engagementCtx) {
                // New data format for engagement components
                const engagementData = {
                    labels: ['Engagement Score'],
                    datasets: [
                        {
                            label: 'Activity Completion (50%)',
                            backgroundColor: 'rgba(75, 192, 192, 0.7)',
                            data: [<?php echo round($activity_completion_rate, 1); ?>]
                        },
                        {
                            label: 'Dashboard Activity (50%)',
                            backgroundColor: 'rgba(54, 162, 235, 0.7)',
                            data: [<?php echo round($dashboard_activity_rate, 1); ?>]
                        }
                    ]
                };

                engagementChart = new Chart(engagementCtx.getContext('2d'), {
                    type: 'bar',
                    data: engagementData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100,
                                stacked: true,
                                title: {
                                    display: true,
                                    text: 'Score (%)'
                                }
                            },
                            x: {
                                stacked: true,
                                title: {
                                    display: true,
                                    text: 'Engagement Components'
                                }
                            }
                        },
                        plugins: {
                            title: {
                                display: true,
                                text: 'Student Engagement Score Breakdown'
                            },
                            tooltip: {
                                callbacks: {
                                    footer: function(tooltipItems) {
                                        let sum = 0;
                                        tooltipItems.forEach(function(tooltipItem) {
                                            sum += tooltipItem.parsed.y;
                                        });
                                        return 'Total: ' + sum.toFixed(1) + '%';
                                    }
                                }
                            }
                        }
                    }
                });
            }
            
            // Create monthly activity chart
            var monthlyChart = null;
            var monthlyCtx = document.getElementById('monthlyActivityChart');
            if (monthlyCtx) {
                const monthlyData = {
                    labels: <?php echo json_encode($months_labels); ?>,
                    datasets: [
                        {
                            label: 'Activity Count',
                            backgroundColor: 'rgba(75, 192, 192, 0.5)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1,
                            data: <?php echo json_encode($activity_counts_array); ?>,
                            yAxisID: 'y'
                        },
                        {
                            label: 'Dashboard Hours',
                            backgroundColor: 'rgba(54, 162, 235, 0.5)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 1,
                            data: <?php echo json_encode($dashboard_time_array); ?>,
                            type: 'line',
                            yAxisID: 'y1'
                        }
                    ]
                };
                
                monthlyChart = new Chart(monthlyCtx.getContext('2d'), {
                    type: 'bar',
                    data: monthlyData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                position: 'left',
                                title: {
                                    display: true,
                                    text: 'Activity Count'
                                }
                            },
                            y1: {
                                beginAtZero: true,
                                position: 'right',
                                grid: {
                                    drawOnChartArea: false
                                },
                                title: {
                                    display: true,
                                    text: 'Dashboard Hours'
                                }
                            }
                        },
                        plugins: {
                            title: {
                                display: true,
                                text: 'Monthly Student Activity & Dashboard Usage'
                            }
                        }
                    }
                });
            }
            
        });
        
        // Print the report
        function printReport() {
            window.print();
        }
    </script>
</body>
</html>