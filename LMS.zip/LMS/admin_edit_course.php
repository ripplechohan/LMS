<?php
session_start();
include 'db_connection.php';

$timeout_duration = 1800;

// Check if last activity timestamp exists
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session has expired - destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

$success_message = '';
$error_message = '';
$course_data = null;

// Check if course ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid course ID";
    header("Location: admin-dashboard.php");
    exit();
}

$course_id = $_GET['id'];

// Get course data including instructor information
$stmt = $conn->prepare("
    SELECT c.*, u.name as instructor_name, u.email as instructor_email 
    FROM Courses c
    LEFT JOIN Users u ON c.instructor_id = u.user_id
    WHERE c.course_id = ?
");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error_message'] = "Course not found";
    header("Location: admin-dashboard.php");
    exit();
}

$course_data = $result->fetch_assoc();

// Get available instructors for assignment
$stmt = $conn->query("SELECT user_id, name, email FROM Users WHERE role = 'Instructor' AND active = 1 ORDER BY name");
$instructors = $stmt->fetch_all(MYSQLI_ASSOC);

// Get existing courses for prerequisites (excluding current course)
$stmt = $conn->prepare("SELECT course_id, title FROM Courses WHERE course_id != ? ORDER BY title");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();
$existing_courses = $result->fetch_all(MYSQLI_ASSOC);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $title = trim($_POST['title']);
    $description = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $skill_level = $_POST['skill_level'];
    $prereq_course_id = !empty($_POST['prereq_course_id']) ? $_POST['prereq_course_id'] : null;
    $start_date = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
    $end_date = !empty($_POST['end_date']) ? $_POST['end_date'] : null;
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $instructor_id = !empty($_POST['instructor_id']) ? $_POST['instructor_id'] : null;
    
    // Validate required fields
    $errors = [];
    
    if (empty($title)) {
        $errors[] = "Course title is required";
    }
    
    if (empty($skill_level) || !in_array($skill_level, ['Beginner', 'Intermediate', 'Advanced'])) {
        $errors[] = "Valid skill level is required";
    }
    
    // Now instructor is required
    if (empty($instructor_id)) {
        $errors[] = "An instructor must be assigned to this course";
    }
    
    // Validate dates if provided
    if (!empty($start_date) && !empty($end_date)) {
        $start = new DateTime($start_date);
        $end = new DateTime($end_date);
        
        if ($end < $start) {
            $errors[] = "End date cannot be earlier than start date";
        }
    }
    
    // Prevent circular prerequisites
    if ($prereq_course_id == $course_id) {
        $errors[] = "A course cannot be a prerequisite for itself";
    }
    
    // If no errors, proceed with course update
    if (empty($errors)) {
        try {
            // Start transaction
            $conn->begin_transaction();
            
            // Update course in database - now including instructor_id
            $stmt = $conn->prepare("
                UPDATE Courses SET
                    title = ?, 
                    description = ?, 
                    category = ?, 
                    skill_level = ?, 
                    prereq_course_id = ?, 
                    start_date = ?, 
                    end_date = ?, 
                    is_active = ?,
                    instructor_id = ?
                WHERE course_id = ?
            ");
            
            $stmt->bind_param(
                "sssssssiis", 
                $title, $description, $category, $skill_level,
                $prereq_course_id, $start_date, $end_date, $is_active,
                $instructor_id, $course_id
            );
            
            if ($stmt->execute()) {                
                // Commit transaction
                $conn->commit();
                
                // Set success message in session for redirect
                $_SESSION['success_message'] = "Course updated successfully!";
                header("Location: admin-dashboard.php");
                exit();
            } else {
                throw new Exception($conn->error);
            }
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $error_message = "Database error: " . $e->getMessage();
        }
    } else {
        $error_message = implode("<br>", $errors);
    }
}

// Get current instructor ID from the course data
$current_instructor_id = $course_data['instructor_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Edit Course - Learning Management System">
    <meta name="author" content="LMS Team">
    <title>Edit Course</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            max-width: 800px;
        }
        .form-title {
            margin-bottom: 30px;
            color: #333;
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .btn-container {
            margin-top: 30px;
            text-align: center;
        }
        .skill-level-info {
            margin-top: 10px;
            font-style: italic;
            color: #6c757d;
        }
        .form-section {
            border-top: 1px solid #e9ecef;
            padding-top: 20px;
            margin-top: 20px;
        }
        .form-section-title {
            font-weight: bold;
            margin-bottom: 15px;
            color: #495057;
        }
        .required-field {
            color: #dc3545;
            margin-left: 5px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><img src="images/logo.png" alt="OLMS Logo" width="200" height="74"></a>
            </div>
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="admin-dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a class="btn btn-primary" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Edit Course</h2>
            
            <?php if(!empty($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <?php if(!empty($error_message)): ?>
                <div class="alert alert-danger">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="admin_edit_course.php?id=<?php echo $course_id; ?>">
                <div class="form-section">
                    <h4 class="form-section-title">Course Details</h4>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="title">Course Title <span class="required-field">*</span></label>
                                <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($course_data['title']); ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="description">Course Description</label>
                                <textarea class="form-control" id="description" name="description" rows="4"><?php echo htmlspecialchars($course_data['description'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="category">Category</label>
                                <input type="text" class="form-control" id="category" name="category" value="<?php echo htmlspecialchars($course_data['category'] ?? ''); ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="skill_level">Skill Level <span class="required-field">*</span></label>
                                <select class="form-control" id="skill_level" name="skill_level" required>
                                    <option value="">Select Skill Level</option>
                                    <option value="Beginner" <?php echo ($course_data['skill_level'] == 'Beginner') ? 'selected' : ''; ?>>Beginner</option>
                                    <option value="Intermediate" <?php echo ($course_data['skill_level'] == 'Intermediate') ? 'selected' : ''; ?>>Intermediate</option>
                                    <option value="Advanced" <?php echo ($course_data['skill_level'] == 'Advanced') ? 'selected' : ''; ?>>Advanced</option>
                                </select>
                                <div id="skillLevelInfo" class="skill-level-info"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h4 class="form-section-title">Course Schedule</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $course_data['start_date'] ?? ''; ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="end_date">End Date</label>
                                <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $course_data['end_date'] ?? ''; ?>">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h4 class="form-section-title">Course Prerequisites & Assignment</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="prereq_course_id">Prerequisite Course (Optional)</label>
                                <select class="form-control" id="prereq_course_id" name="prereq_course_id">
                                    <option value="">None</option>
                                    <?php foreach($existing_courses as $course): ?>
                                        <option value="<?php echo $course['course_id']; ?>" <?php echo ($course_data['prereq_course_id'] == $course['course_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['title']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="instructor_id">Assigned Instructor <span class="required-field">*</span></label>
                                <select class="form-control" id="instructor_id" name="instructor_id" required>
                                    <option value="">Select Instructor</option>
                                    <?php foreach($instructors as $instructor): ?>
                                        <option value="<?php echo $instructor['user_id']; ?>" <?php echo ($current_instructor_id == $instructor['user_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($instructor['name']); ?> (<?php echo htmlspecialchars($instructor['email']); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="text-info" style="margin-top: 5px;">
                                    <i class="fas fa-info-circle"></i> Each course must be assigned to an instructor.
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($current_instructor_id)): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-info">
                                <strong>Current Instructor:</strong> 
                                <?php echo htmlspecialchars($course_data['instructor_name'] ?? 'Unknown'); ?> 
                                (<?php echo htmlspecialchars($course_data['instructor_email'] ?? ''); ?>)
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="form-section">
                    <h4 class="form-section-title">Course Status</h4>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="is_active" <?php echo $course_data['is_active'] ? 'checked' : ''; ?>> 
                                        Make course active (visible to students)
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="btn-container">
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                    <a href="admin-dashboard.php" class="btn btn-secondary btn-lg">
                        <i class="fas fa-arrow-left"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        // Display skill level information based on selection
        document.getElementById('skill_level').addEventListener('change', function() {
            const skillLevelInfo = document.getElementById('skillLevelInfo');
            const selectedLevel = this.value;
            
            if (selectedLevel === 'Beginner') {
                skillLevelInfo.textContent = 'For students with little to no prior knowledge in the subject area.';
            } else if (selectedLevel === 'Intermediate') {
                skillLevelInfo.textContent = 'For students with basic understanding and some experience in the subject.';
            } else if (selectedLevel === 'Advanced') {
                skillLevelInfo.textContent = 'For students with substantial prior knowledge and experience in the subject.';
            } else {
                skillLevelInfo.textContent = '';
            }
        });
        
        // Trigger skill level info display on page load
        document.addEventListener('DOMContentLoaded', function() {
            const skillLevel = document.getElementById('skill_level');
            if (skillLevel.value) {
                const event = new Event('change');
                skillLevel.dispatchEvent(event);
            }
        });
        
        // Date validation
        document.getElementById('end_date').addEventListener('change', function() {
            const startDate = document.getElementById('start_date').value;
            const endDate = this.value;
            
            if (startDate && endDate && new Date(endDate) < new Date(startDate)) {
                alert('End date cannot be earlier than start date');
                this.value = '';
            }
        });
    </script>
</body>
</html>